from __future__ import annotations

import os

import pyglet

from pyglet.util import asstr

from . import ModelDecodeException, ModelDecoder
from .base import SimpleMaterial, Mesh, Primitive, Attribute, Node, Scene
from pyglet.model import Model, MaterialGroup, TexturedMaterialGroup
from pyglet.graphics import AttributeLayout, Batch, Group
from pyglet.enums import GeometryMode
from pyglet.math import Vec3, Quaternion


def _new_mesh(name, material):
    # The pre-defined attributes types used in .obj files:
    attributes = [
        Attribute('POSITION', 'f', 'VEC3', 0, []),
        Attribute('NORMAL', 'f', 'VEC3', 0, []),
        Attribute('TEXCOORD_0', 'f', 'VEC2', 0, []),
        Attribute('COLOR_0', 'f', 'VEC4', 0, [])
    ]

    primitive = Primitive(attributes=attributes, indices=None, material=material, mode=GeometryMode.TRIANGLES)
    return Mesh(primitives=[primitive], name=name)


def load_material_library(filename):
    file = open(filename)

    name = None
    diffuse = [1.0, 1.0, 1.0]
    ambient = [1.0, 1.0, 1.0]
    specular = [1.0, 1.0, 1.0]
    emission = [0.0, 0.0, 0.0]
    shininess = 100.0
    opacity = 1.0
    texture_name = None

    matlib = {}

    for line in file:
        if line.startswith('#'):
            continue
        values = line.split()
        if not values:
            continue

        if values[0] == 'newmtl':
            if name is not None:
                # save previous material
                for item in (diffuse, ambient, specular, emission):
                    item.append(opacity)
                matlib[name] = SimpleMaterial(name, tuple(diffuse), tuple(ambient), tuple(specular), tuple(emission), shininess, texture_name)
            name = values[1]

        elif name is None:
            raise ModelDecodeException(f'Expected "newmtl" in {filename}')

        try:
            if values[0] == 'Kd':
                diffuse = list(map(float, values[1:]))
            elif values[0] == 'Ka':
                ambient = list(map(float, values[1:]))
            elif values[0] == 'Ks':
                specular = list(map(float, values[1:]))
            elif values[0] == 'Ke':
                emission = list(map(float, values[1:]))
            elif values[0] == 'Ns':
                shininess = float(values[1])            # Blender exports 1~1000
                shininess = (shininess * 128) / 1000    # Normalize to 1~128 for OpenGL
            elif values[0] == 'd':
                opacity = float(values[1])

            elif values[0] == 'map_Kd':
                texture_name = values[1]

        except BaseException as ex:
            raise ModelDecodeException(f'Parsing error in {(filename, ex)}.')

    file.close()

    for item in (diffuse, ambient, specular, emission):
        item += [opacity]

    matlib[name] = SimpleMaterial(name, tuple(diffuse), tuple(ambient), tuple(specular), tuple(emission), shininess, texture_name)

    return matlib


def parse_obj_file(filename, file=None) -> list[Mesh]:
    materials = {}
    meshes = []

    location = os.path.dirname(filename)

    try:
        if file is None:
            with open(filename) as f:
                file_contents = f.read()
        else:
            file_contents = asstr(file.read())
    except (UnicodeDecodeError, OSError):
        raise ModelDecodeException

    material = None
    mesh = None

    normals = [[0., 0., 0.]]
    tex_coords = [[0., 0.]]
    positions = [[0., 0., 0.]]

    diffuse = (1.0, 1.0, 1.0, 1.0)
    ambient = (1.0, 1.0, 1.0, 1.0)
    specular = (1.0, 1.0, 1.0, 1.0)
    emission = (0.0, 0.0, 0.0, 1.0)
    shininess = 100.0

    default_material = SimpleMaterial("Default", diffuse, ambient, specular, emission, shininess)

    for line in file_contents.splitlines():

        if line.startswith('#'):
            continue
        values = line.split()
        if not values:
            continue

        if values[0] == 'v':
            positions.append(list(map(float, values[1:4])))
        elif values[0] == 'vn':
            normals.append(list(map(float, values[1:4])))
        elif values[0] == 'vt':
            tex_coords.append(list(map(float, values[1:3])))

        elif values[0] == 'mtllib':
            material_abspath = os.path.join(location, values[1])
            materials = load_material_library(filename=material_abspath)

        elif values[0] in ('usemtl', 'usemat'):
            material = materials.get(values[1])
            if mesh is not None:
                mesh.primitives[0].material = material

        elif values[0] == 'o':
            mesh = _new_mesh(values[1], material=default_material)
            meshes.append(mesh)

        elif values[0] == 'f':
            # --- FACES

            if material is None:
                material = SimpleMaterial()
            if mesh is None:
                mesh = _new_mesh(name='unknown', material=material)
                meshes.append(mesh)

            primitive = mesh.primitives[0]

            pos_attr = primitive.attributes[0]
            normal_attr = primitive.attributes[1]
            tex_uv_attr = primitive.attributes[2]
            color_attr = primitive.attributes[3]

            face_positions = []
            for v in values[1:]:
                parts = v.split('/')

                # vertex index (should not be empty, raise error instead?)
                v_i = int(parts[0]) if parts[0] else 0

                # texcoord index (optional)
                t_i = 0
                if len(parts) >= 2 and parts[1]:
                    t_i = int(parts[1])

                # normal index (optional)
                n_i = 0
                if len(parts) == 3 and parts[2]:
                    n_i = int(parts[2])

                # handle negative indices
                if v_i < 0:
                    v_i = len(positions) + v_i
                if t_i < 0:
                    t_i = len(tex_coords) + t_i
                if n_i < 0:
                    n_i = len(normals) + n_i

                face_positions.append((v_i, t_i, n_i))

            # For fan triangulation, remember first and latest position
            for i in range(2, len(face_positions)):
                for idx in (0, i - 1, i):
                    v_i, t_i, n_i = face_positions[idx]

                    pos_attr.array += positions[v_i]

                    if n_i != 0:
                        primitive.has_normals = True
                        normal_attr.array += normals[n_i]
                    else:
                        normal_attr.array += [0.0, 0.0, 1.0]

                    if t_i != 0:
                        primitive.has_tex_coords = True
                        tex_uv_attr.array += tex_coords[t_i]
                    else:
                        tex_uv_attr.array += [0.0, 0.0]

    for mesh in meshes:
        for primitive in mesh.primitives:
            pos_attr = primitive.attributes[0]
            normal_attr = primitive.attributes[1]
            tex_uv_attr = primitive.attributes[2]
            color_attr = primitive.attributes[3]
            color_attr.array = material.diffuse * (len(pos_attr.array) // 3)

            for attribute in (pos_attr, normal_attr, tex_uv_attr, color_attr):
                count = {'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[attribute.type]
                attribute.count = len(attribute.array) // count

    return meshes


class OBJScene(Scene):

    def create_models(self, batch: Batch, group: Group | None = None) -> list[Model]:
        vertex_lists = []
        groups = []
        for node in self.nodes:
            mesh = node.mesh

            for primitive in mesh.primitives:
                material = primitive.material
                count = primitive.attributes[0].count

                if material.texture_name:
                    _texture = pyglet.resource.texture(material.texture_name, atlas=False)
                    program = pyglet.model.get_default_textured_shader()
                else:
                    program = pyglet.model.get_default_shader()

                formats = {a.name: a.fmt for a in primitive.attributes if a.name in program.attributes}
                layout = program.get_attribute_view(AttributeLayout(**formats)).set_instance_attributes(
                    TRANSLATION=1, ROTATION=1, SCALE=1
                )
                if material.texture_name:
                    matgroup = TexturedMaterialGroup(material, layout, _texture, parent=group)
                else:
                    matgroup = MaterialGroup(material, layout, parent=group)

                data = {a.name: a.array for a in primitive.attributes if a.name in program.attributes}
                data |= {'TRANSLATION': Vec3(), 'ROTATION': Quaternion(), 'SCALE': Vec3(1.0, 1.0, 1.0)}
                vertex_list = layout.vertex_list_instanced(
                    count=count, mode=GeometryMode.TRIANGLES, batch=batch, group=matgroup, **data
                )

                vertex_lists.append(vertex_list)
                groups.append(matgroup)

        return [Model(vertex_lists=vertex_lists, groups=groups, batch=batch)]


###################################################
#   Decoder definitions start here:
###################################################

class OBJModelDecoder(ModelDecoder):
    def get_file_extensions(self):
        return ['.obj']

    def decode(self, filename, file):
        mesh_list = parse_obj_file(filename=filename, file=file)
        return OBJScene(nodes=[Node(mesh=mesh) for mesh in mesh_list])


def get_decoders():
    return [OBJModelDecoder()]


def get_encoders():
    return []
