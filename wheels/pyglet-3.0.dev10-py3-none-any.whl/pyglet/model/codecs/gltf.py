from __future__ import annotations

import json
import struct

from array import array
import io
from urllib.request import urlopen

import pyglet

# The glTF spec uses constants that match those in OpenGL. Imported here for convenience, but they could be localized:
from pyglet.graphics.api.gl import GL_BYTE, GL_UNSIGNED_BYTE, GL_SHORT, GL_UNSIGNED_SHORT, GL_FLOAT, GL_DOUBLE
from pyglet.graphics.api.gl import GL_POINTS, GL_TRIANGLES, GL_LINES, GL_TRIANGLE_STRIP, GL_LINE_STRIP, GL_TRIANGLE_FAN
from pyglet.graphics.api.gl import GL_INT, GL_UNSIGNED_INT, GL_ELEMENT_ARRAY_BUFFER, GL_ARRAY_BUFFER

from pyglet.enums import (
    AddressMode, AnimationChannelTargetPath, AnimationInterpolation,
    GeometryMode
)

from . import ModelDecodeException, ModelDecoder
from .base import PBRMaterial
from .base import Camera as BaseCamera
from .base import Attribute as BaseAttribute
from .base import Primitive as BasePrimitive
from .base import Node as BaseNode
from .base import Mesh as BaseMesh
from .base import Scene as BaseScene
from ...math import Mat4, Quaternion, Vec3

_array_types = {
    GL_BYTE: 'b',
    GL_UNSIGNED_BYTE: 'B',
    GL_SHORT: 'h',
    GL_UNSIGNED_SHORT: 'H',
    GL_INT: 'l',
    GL_UNSIGNED_INT: 'L',
    GL_FLOAT: 'f',
    GL_DOUBLE: 'd',
}

_accessor_type_sizes = {
    GL_BYTE: 1,
    GL_UNSIGNED_BYTE: 1,
    GL_SHORT: 2,
    GL_UNSIGNED_SHORT: 2,
    GL_INT: 4,
    GL_UNSIGNED_INT: 4,
    GL_FLOAT: 4,
    GL_DOUBLE: 8,
}

_accessor_type_counts = {
    "SCALAR": 1,
    "VEC2": 2,
    "VEC3": 3,
    "VEC4": 4,
    "MAT2": 4,
    "MAT3": 9,
    "MAT4": 16
}

_targets = {
    GL_ELEMENT_ARRAY_BUFFER: "ELEMENT_ARRAY_BUFFER",
    GL_ARRAY_BUFFER: "ARRAY_BUFFER",
}

_geometry_modes = {
    GL_POINTS: GeometryMode.POINTS,
    GL_LINES: GeometryMode.LINES,
    GL_LINE_STRIP: GeometryMode.LINE_STRIP,
    GL_TRIANGLES: GeometryMode.TRIANGLES,
    GL_TRIANGLE_STRIP: GeometryMode.TRIANGLE_STRIP,
    GL_TRIANGLE_FAN: GeometryMode.TRIANGLE_FAN,
}


class Buffer:
    """Abstraction over unstructured bytes."""
    def __init__(self, data, binary_buffer=None):
        self.length = data['byteLength']
        if not 'uri' in data:
            self._binary_buffer = binary_buffer
            self._uri = None
            self._file = None
        else:
            self._uri = data['uri']

            if self._uri.startswith('data'):
                self._response = urlopen(self._uri)
                self._file = self._response.file
            else:
                self._file = pyglet.resource.file(self._uri, 'rb')

    def read(self, offset, nbytes) -> bytes:
        if not self._uri:
            return self._binary_buffer[offset:offset+nbytes]

        self._file.seek(offset)
        return self._file.read(nbytes)

    def __del__(self):
        if self._file:
            try:
                self._file.close()
            except AttributeError:
                pass

    def __repr__(self):
        return f"{self.__class__.__name__}(length={self.length})"


class BufferView:
    """View over a section of a Buffer, with optional stride."""
    def __init__(self, data, owner):
        self._buffer_index = data.get('buffer')
        self.buffer = owner.buffers[self._buffer_index]

        self.offset = data.get('byteOffset', 0)
        self.length = data.get('byteLength')
        self.stride = data.get('byteStride', 0)
        self.target = data.get('target')
        self.target_name = _targets.get(self.target)

    def read(self, read_offset: int, byte_length: int, count: int) -> bytes:
        offset = self.offset + read_offset
        bytestring = b""

        for _ in range(count):
            bytestring += self.buffer.read(offset, byte_length)
            offset += self.stride or byte_length

        return bytestring

    def __repr__(self):
        return f"{self.__class__.__name__}(buffer={self._buffer_index}, target={self.target_name})"


class Accessor:
    def __init__(self, data, owner):
        self._buffer_view_index = data.get('bufferView')
        self.buffer_view = owner.buffer_views[self._buffer_view_index]

        self.byte_offset = data.get('byteOffset', 0)
        self.component_type = data.get('componentType')     # GL_FLOAT, GL_INT, etc
        self.type = data.get('type')                        # VEC3, MAT4, etc.
        self.count = data.get('count')                      # count of self.type
        self.max = data.get('max')
        self.min = data.get('min')

        # This is a 'sparse' accessor:
        self.sparse = data.get('sparse')
        if self.sparse:
            raise NotImplementedError("Not yet implemented")

        # The Python format type:
        self.fmt = _array_types[self.component_type]

        # The byte size of the `GL type` multiplied by the length of the GLSL `data type`.
        # For example: a GL_FLOAT is 4 bytes and a VEC3 has 3 values, so 4 * 3 = 12 bytes
        self._byte_length = _accessor_type_sizes[self.component_type] * _accessor_type_counts[self.type]

    def read(self) -> bytes:
        return self.buffer_view.read(self.byte_offset, self._byte_length, self.count)
        # readbytes = self.buffer_view.read(self.byte_offset, self._byte_length, self.count)
        # assert self._byte_length * self.count == len(readbytes), "insufficient bytes read"
        # return readbytes

    def as_array(self):
        return array(self.fmt, self.read())

    def __repr__(self):
        return f"{self.__class__.__name__}(buffer_view={self._buffer_view_index})"


class Attribute(BaseAttribute):
    def __init__(self, name, index, owner):
        accessor = owner.accessors[index]
        self.target = accessor.buffer_view.target
        self.target_name = accessor.buffer_view.target_name
        super().__init__(name, accessor.fmt, accessor.type, accessor.count, accessor.as_array())


class Primitive(BasePrimitive):
    def __init__(self, data, owner):
        attributes = [Attribute(name, index, owner) for name, index in data.get('attributes').items()]
        assert len(set(a.count for a in attributes)) == 1, "All Attributes must have the same count"

        indices_index = data.get('indices')
        indices_accessor = owner.accessors[indices_index] if indices_index is not None else None
        indices = indices_accessor.as_array() if indices_accessor else None

        mode = _geometry_modes[data.get('mode', GL_TRIANGLES)]

        material_index = data.get('material')
        material = owner.materials[material_index] if material_index is not None else None

        super().__init__(attributes, indices, mode, material)


class Material(PBRMaterial):
    def __init__(self, data):
        self._data = data
        self.name = data.get('name')
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

        self.base_color_texture = data.get('baseColorTexture')
        self.normal_texture = data.get('normalTexture')
        self.occlusion_texture = data.get('occlusionTexture')
        self.emissive_texture = data.get('emissiveTexture')

        self.pbr_metallic_roughness = data.get('pbrMetallicRoughness')
        self.base_color_factor = self.pbr_metallic_roughness.get('baseColorFactor', (1.0, 1.0, 1.0, 1.0))
        self.metalic_factor = self.pbr_metallic_roughness.get('metallicFactor', 1.0)
        self.roughness_factor = self.pbr_metallic_roughness.get('roughnessFactor', 1.0)

        self.base_color_texture = self.pbr_metallic_roughness.get('baseColorTexture', self.base_color_texture)
        self.metallic_roughness_texture = self.pbr_metallic_roughness.get('metallicRoughnessTexture')

        self.extensions = self.pbr_metallic_roughness.get('extensions', self.extensions)
        self.extras = self.pbr_metallic_roughness.get('extras', self.extras)

        self.emissive_factor = data.get('emissiveFactor', (0.0, 0.0, 0.0))
        self.alpha_mode = data.get('alphaMode', 'OPAQUE')   # Any of: OPAQUE, MASK, BLEND
        self.alpha_cutoff = data.get('alphaCutoff', 0.5)
        self.double_sided = data.get('doubleSided', False)

        # TODO: finish this once the base class is ready
        # super().__init__(name, )

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name})"


class Texture:
    def __init__(self, data, owner):
        self._data = data
        self.name = data.get('name')
        # self.extensions = data.get('extensions')
        # self.extras = data.get('extras')

        # TODO: verify how this works. Default sampler?
        self._sampler_index = data.get('sampler')
        self.sampler = owner.samplers[self._sampler_index] if self._sampler_index else Sampler(data={})

        self.source = data.get('source')            # technically NOT required
        self.image = owner.images[self.source]

        # Aliases
        self.min_filter = self.sampler.min_filter
        self.mag_filter = self.sampler.mag_filter
        self.wrap_s = self.sampler.wrap_s
        self.wrap_t = self.sampler.wrap_t

    def __repr__(self):
        return f"{self.__class__.__name__}(name={self.name}, image={self.image})"


class Sampler:
    def __init__(self, data):
        # TODO: make objects for min/mag filter objects
        self.name = data.get('name')
        self.min_filter = data.get('minFilter')
        self.mag_filter = data.get('magFilter')
        self.wrap_s = data.get('wrapS', AddressMode.REPEAT)
        self.wrap_t = data.get('wrapT', AddressMode.REPEAT)
        # self.extensions = data.get('extensions')
        # self.extras = data.get('extras')


class Image:
    def __init__(self, data, owner):
        self.uri = data.get('uri')
        self._buffer_view_index = data.get('bufferView')
        self.buffer_view = owner.buffer_views[self._buffer_view_index] if self._buffer_view_index else None
        self.mime_type = data.get('mimeType')
        self.name = data.get('name')
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def read(self):
        if self.uri:
            img = pyglet.resource.image(self.uri)
            return img

        if self.mime_type:
            fmt = self.mime_type.split('/')[-1]
        else:
            # Use png as the default image format
            fmt = 'png'
        if self.buffer_view:
            # In this case we use a buffer view to get the image data
            offset = 0
            length = self.buffer_view.length
            count = 1
            image_data_bytes = self.buffer_view.read(offset, length, count)
            image_stream = io.BytesIO(image_data_bytes)
            # hardcode a filename
            filename = f"image.{fmt}"
            img = pyglet.image.load(filename, file=image_stream)
            return img
        raise NotImplementedError

    def __repr__(self):
        return f"{self.__class__.__name__}(name={self.name}, uri={self.uri})"


class Camera(BaseCamera):
    def __init__(self, camera_type, data):
        aspect_ratio = data.get('aspectRatio')  # Not required
        yfov = data.get('yfov')
        # Orthographic
        xmag = data.get('xmag')
        ymag = data.get('ymag')
        # Shared
        zfar = data.get('zfar')                 # Not required for Perspective
        znear = data.get('znear')
        super().__init__(camera_type, aspect_ratio, yfov, xmag, ymag, zfar, znear)


class Mesh(BaseMesh):
    def __init__(self, data, owner):
        primitives = [Primitive(primitive_data, owner) for primitive_data in data.get('primitives')]
        super().__init__(primitives=primitives, name=data.get('name'))


class Node(BaseNode):
    def __init__(self, data, owner, index):
        self._data = data
        self._owner = owner
        self.index = index

        _mesh_index = data.get('mesh')
        self.mesh = owner.meshes[_mesh_index] if _mesh_index is not None else None

        self.name = data.get('name')
        self.matrix = data.get('matrix')            # Mat4
        self.translation = data.get('translation')  # Vec3
        self.rotation = data.get('rotation')        # Quaternion
        self.scale = data.get('scale')              # Vec3

        # TODO: handle these:
        self.camera = None
        self._child_indices = data.get('children', [])
        self._skin_index = data.get('skin')

    @property
    def children(self):
        return [self._owner.nodes[i] for i in self._child_indices]

    @property
    def parent(self) -> "Node | None":
        for node in self._owner.nodes:
            if self in node.children:
                return node
        return None

    @property
    def local_transform(self) -> Mat4:
        if self.matrix:
            transform = Mat4(*self.matrix)
        else:
            if self.translation:
                t = Mat4.from_translation(Vec3(*self.translation))
            else:
                t = Mat4()

            if self.rotation:
                quat = Quaternion(self.rotation[3], *self.rotation[:3])
                r = quat.to_mat4().transpose()
            else:
                r = Mat4()

            if self.scale:
                s = Mat4.from_scale(Vec3(*self.scale))
            else:
                s = Mat4()
            transform = t @ r @ s

        return transform

    @property
    def global_transform(self) -> Mat4:
        # For this property to work make sure to call it after all nodes have
        # been created. That way you make sure the parent has already been set
        transform = self.local_transform
        if self.parent:
            transform = self.parent.global_transform @ transform
        return transform

    @property
    def skin(self):
        if self._skin_index is None:
            return None
        return self._owner.skins[self._skin_index]

    def __repr__(self):
        return (
            f"{self.__class__.__name__}"
            f"("
            f"index={self.index}, name={self.name}, "
            f"mesh={self.mesh}, skin={self.skin}, "
            f"camera={self.camera}, children={len(self.children)}"
            f")"
        )


class Scene(BaseScene):
    def __init__(self, name:str = "undefined", nodes: list[Node] | None = None):
        super().__init__(nodes=nodes)
        self.name = name

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"name={self.name}, "
            f"nodes={len(self.nodes)}"
            ")"
        )


class Skin:
    def __init__(self, data, owner):
        self.name = data.get('name')
        joints_indices = data.get('joints', [])
        self.joints: list[Node] = [owner.nodes[i] for i in joints_indices]
        self.ibm_idx = data.get('inverseBindMatrices')
        ibm_accessor = owner.accessors[
            self.ibm_idx
        ] if self.ibm_idx is not None else None
        # If inverseBindMatrices is not defined, each matrix is a 4x4 identity
        # https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#_skin_inversebindmatrices
        self.inverse_bind_matrices: list[Mat4] = []
        ibms = ibm_accessor.as_array() if ibm_accessor else None
        for i in range(len(self.joints)):
            if ibms is None:
                new_matrix = Mat4()
            else:
                offset = i * 16
                new_matrix = Mat4(*ibms[offset:offset+16])
            self.inverse_bind_matrices.append(new_matrix)

        self.skeleton_index: int | None = data.get('skeleton')
        self.skeleton: Node | None = owner.nodes[self.skeleton_index] if (
            self.skeleton_index is not None
        ) else None
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"name={self.name}, "
            f"inverse_bind_matrices={self.ibm_idx}, "
            f"skeleton={self.skeleton_index}, "
            f"joints={len(self.joints)}"
            ")"
        )

class Animation:
    def __init__(self, data, owner):
        self.name = data.get('name')
        self.samplers = [
            AnimationSampler(sampler_data, owner) for sampler_data in data.get(
                'samplers'
            )
        ]
        # SAMPLERS NEED TO BE DEFINED FIRST
        self.channels = [
            AnimationChannel(channel_data, owner, self) for channel_data in
            data.get(
                'channels'
            )
        ]

        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"name={self.name}, "
            f"samplers={len(self.samplers)}, "
            f"channels={len(self.channels)}"
            ")"
        )


class AnimationChannel:
    def __init__(self, data, owner, animation):
        self.target = AnimationChannelTarget(data.get('target'), owner)
        self.sampler_id = data.get('sampler')
        sampler = animation.samplers[
            self.sampler_id
        ] if self.sampler_id is not None else None
        self.sampler = sampler
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"target={self.target}, "
            f"sampler={self.sampler_id}"
            ")"
        )


class AnimationChannelTarget:
    def __init__(self, data, owner):
        self.node_idx = data.get('node')
        self.node = owner.nodes[
            self.node_idx
        ] if self.node_idx is not None else None
        self.path = data.get('path', AnimationChannelTargetPath.ROTATION)
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"node={self.node_idx}, "
            f"path={self.path}"
            ")"
        )

class AnimationSampler:
    def __init__(self, data, owner):
        self.input_idx = data.get('input')
        self.input = owner.accessors[self.input_idx] if (
            self.input_idx is not None
        ) else None
        self.output_idx = data.get('output')
        self.output = owner.accessors[self.output_idx] if (
            self.output_idx is not None
        ) else None
        interpolation = data.get('interpolation', 'LINEAR')
        self.interpolation = AnimationInterpolation(interpolation)
        self.extensions = data.get('extensions')
        self.extras = data.get('extras')

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"input={self.input_idx}, "
            f"output={self.output_idx}"
            ")"
        )

class GLTF:
    def __init__(self, gltf_data: dict, binary_buffer: bytes | None = None):
        self._gltf_data = gltf_data
        self.version = gltf_data['asset']['version']
        self.generator = gltf_data['asset'].get('generator', 'unknown')

        if binary_buffer:
            data = gltf_data['buffers'][0]
            self.buffers = [Buffer(data=data, binary_buffer=binary_buffer)]
        else:
            self.buffers = [Buffer(data=data) for data in gltf_data['buffers']]
        self.buffer_views = [BufferView(data=data, owner=self) for data in gltf_data['bufferViews']]
        self.accessors = [Accessor(data=data, owner=self) for data in gltf_data['accessors']]


        self.images = [Image(data=data, owner=self) for data in gltf_data.get('images', [])]
        self.samplers = [Sampler(data=data) for data in gltf_data.get('samplers', [])]
        self.textures = [Texture(data=data, owner=self) for data in gltf_data.get('textures', [])]
        self.materials = [Material(data) for data in gltf_data.get('materials', [])]

        self.cameras = [Camera(cam['type'], cam[cam['type']]) for cam in gltf_data.get('cameras', [])]

        self.meshes: list[Mesh] = [
            Mesh(data=data, owner=self) for data in gltf_data['meshes']
        ]
        self.nodes: list[Node] = [
            Node(data=data, owner=self, index=idx) for idx, data in
            enumerate(gltf_data['nodes'])
        ]

        self.skins: list[Skin] = [
            Skin(data=data, owner=self) for data in gltf_data.get('skins', [])
        ]
        self.animations: list[Animation] = [
            Animation(data=data, owner=self) for data in
            gltf_data.get('animations', [])
        ]

        self.scenes: list[Scene] = [
            Scene(
                name=scene_data.get('name', "undefined"),
                nodes=[self.nodes[i] for i in scene_data['nodes']]
            )  for scene_data in gltf_data['scenes']
        ]
        self.default_scene: Scene = self.scenes[gltf_data.get('scene', 0)]

    def __repr__(self):
        return f"{self.__class__.__name__}(scenes={len(self.scenes)}, meshes={len(self.meshes)})"


def load_gltf(filename, file=None) -> GLTF:

    try:
        if file is None:
            file = pyglet.resource.file(filename, 'r')
    except pyglet.resource.ResourceNotFoundException:
        raise ModelDecodeException

    if filename.endswith('glb'):
        file.close()
        file = pyglet.resource.file(filename, 'rb')
        # Check header
        magic = file.read(4)
        if magic != b"glTF":
            raise ModelDecodeException(f"Invalid header for .glb file: {magic}")

        version = struct.unpack("<I", file.read(4))[0]
        if version != 2:
            raise ModelDecodeException(f"Unsupported glTF version: {version}")

        # Total file size including headers
        _ = struct.unpack("<I", file.read(4))[0]  # noqa

        # Chunk 0 - json
        chunk_0_length = struct.unpack("<I", file.read(4))[0]
        chunk_0_type = file.read(4)
        if chunk_0_type != b"JSON":
            raise ModelDecodeException(f"glTF 'chunk 0 type' is not 'JSON': {chunk_0_type}")

        json_meta = file.read(chunk_0_length).decode()

        # chunk 1 - binary buffer
        chunk_1_length = struct.unpack("<I", file.read(4))[0]
        chunk_1_type = file.read(4)
        if chunk_1_type != b"BIN\x00":
            raise ModelDecodeException(f"glTF 'chunk 1 type' is not 'BIN': {chunk_0_type}")

        binary_buffer = file.read(chunk_1_length)

    else:
        json_meta = file.read()
        binary_buffer = None

    try:
        gltf_data = json.loads(json_meta)
    except json.JSONDecodeError as e:
        raise ModelDecodeException(f"Json error. Does not appear to be a valid glTF file. {e}")
    finally:
        file.close()

    if 'asset' not in gltf_data:
        raise ModelDecodeException("Not a valid glTF file: 'asset' property not found.")
    else:
        if float(gltf_data['asset'].get('version', 0)) < 2.0:
            raise ModelDecodeException('Only glTF 2.0+ models are supported')

    return GLTF(gltf_data=gltf_data, binary_buffer=binary_buffer)


###################################################
#   Decoder definitions start here:
###################################################

class GLTFModelDecoder(ModelDecoder):
    def get_file_extensions(self):
        return ['.gltf', '.glb']

    def decode(self, filename, file):
        gltf = load_gltf(filename, file)
        return gltf.scenes[0]


def get_decoders():
    return [GLTFModelDecoder()]


def get_encoders():
    return []
