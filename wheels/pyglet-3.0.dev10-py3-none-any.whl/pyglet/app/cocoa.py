from __future__ import annotations

import signal
import time
from typing import TYPE_CHECKING

import pyglet
from pyglet import app
from pyglet.app.base import EventLoop, PlatformEventLoop, WindowDrawSource
from pyglet.libs.darwin import cocoapy, AutoReleasePool, PyObjectEncoding, ObjCInstance, send_super, \
    ObjCClass, get_selector, objc_method, set_realtime_thread_policy

NSApplication = cocoapy.ObjCClass('NSApplication')
NSObject = cocoapy.ObjCClass('NSObject')
NSMenu = cocoapy.ObjCClass('NSMenu')
NSMenuItem = cocoapy.ObjCClass('NSMenuItem')
NSDate = cocoapy.ObjCClass('NSDate')
NSEvent = cocoapy.ObjCClass('NSEvent')
NSUserDefaults = cocoapy.ObjCClass('NSUserDefaults')
NSTimer = cocoapy.ObjCClass('NSTimer')
NSRunningApplication = cocoapy.ObjCClass('NSRunningApplication')

if TYPE_CHECKING:
    from pyglet.window.apple.cocoa import CocoaWindow

def add_menu_item(menu, title, action, key):
    with AutoReleasePool():
        title = cocoapy.CFSTR(title)
        action = cocoapy.get_selector(action)
        key = cocoapy.CFSTR(key)
        menuItem = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
            title, action, key)
        menu.addItem_(menuItem)

        # cleanup
        menuItem.release()
        cocoapy.cf.CFRelease(title)
        cocoapy.cf.CFRelease(key)


def create_menu():
    with AutoReleasePool():
        appMenu = NSMenu.alloc().init()

        # Hide still doesn't work!?
        add_menu_item(appMenu, 'Hide!', 'hide:', 'h')
        appMenu.addItem_(NSMenuItem.separatorItem())
        add_menu_item(appMenu, 'Quit!', 'terminate:', 'q')

        menubar = NSMenu.alloc().init()
        appMenuItem = NSMenuItem.alloc().init()
        appMenuItem.setSubmenu_(appMenu)
        menubar.addItem_(appMenuItem)
        NSApp = NSApplication.sharedApplication()
        NSApp.setMainMenu_(menubar)

        # cleanup
        appMenu.release()
        menubar.release()
        appMenuItem.release()


class _AppDelegate(NSObject):

    @objc_method(b'@' + PyObjectEncoding)
    def init(self, pyglet_loop):
        objc = ObjCInstance(send_super(self, 'init'))
        self._pyglet_loop = pyglet_loop
        return objc  # objc is self

    @objc_method('v')
    def updatePyglet_(self):
        self._pyglet_loop.nsapp_step()

    @objc_method('v@')
    def applicationWillTerminate_(self, notification):
        self._pyglet_loop.is_running = False
        self._pyglet_loop.has_exit = True

    @objc_method('v@')
    def applicationDidFinishLaunching_(self, notification):
        self._pyglet_loop._finished_launching = True

        # Force App to activate to the foreground due to being an unbundled CLI program.
        # This prevents an issue where if you move the mouse when launching the program, it's focus can be stolen
        # by an app under/behind it leading to a weird state of input and the menu bar being greyed out until
        # reactivating it.
        NSApp = NSApplication.sharedApplication()

        # Activate dock to ensure all other apps are deactivated.
        dock_str = cocoapy.get_NSString("com.apple.dock")
        running_apps = NSRunningApplication.runningApplicationsWithBundleIdentifier_(dock_str)
        app_count = running_apps.count()
        for i in range(app_count):
            running_app = running_apps.objectAtIndex_(i)
            running_app.activateWithOptions_(cocoapy.NSApplicationActivateIgnoringOtherApps)
            break

        # Doesn't seem to work unless we add a small sleep for some reason...
        time.sleep(0.01)

        NSApp.activateIgnoringOtherApps_(True)

    @objc_method('v@')
    def applicationWillFinishLaunching_(self, notification):
        pass

    @objc_method('B')
    def applicationSupportsSecureRestorableState_(self):
        return True

class CocoaAlternateEventLoop(EventLoop):
    """This is an alternate loop developed mainly for ARM64 variants of macOS.

    nextEventMatchingMask_untilDate_inMode_dequeue_ is very broken with ctypes calls on M1.

    Events eventually stop working properly after X returns. This event loop
    differs in that it uses the built-in NSApplication event
    loop. We tie our schedule into it via timer.
    """
    def __init__(self):
        super().__init__()
        self.platform_event_loop = None

    def run(self, interval: float | None = 1/60) -> None:
        self.has_exit = False

        from pyglet.window import Window  # noqa: PLC0415
        Window._enable_event_queue = False  # noqa: SLF001

        # Dispatch pending events
        for window in app.windows:
            window.switch_to()
            window.dispatch_pending_events()

        self.platform_event_loop = app.platform_event_loop
        self._schedule_window_draw(interval)

        self.dispatch_event('on_enter')
        self.is_running = True

        try:
            self.platform_event_loop.nsapp_start(interval or 0)
        finally:
            self._unschedule_window_draw()
        self._raise_window_draw_exception()

    def exit(self) -> None:
        """Safely exit the event loop at the end of the current iteration.

        This method is a thread-safe equivalent for setting
        :py:attr:`has_exit` to ``True``.  All waiting threads will be
        interrupted (see :py:meth:`sleep`).
        """
        self.has_exit = True
        if self.platform_event_loop is not None:
            self.platform_event_loop.notify()

        self.is_running = False
        self.dispatch_event('on_exit')

        if self.platform_event_loop is not None:
            self.platform_event_loop.nsapp_stop()


class CocoaWindowDrawSource(WindowDrawSource):
    """Display driven drawing backed by one CADisplayLink."""

    def __init__(self) -> None:
        self._active = False
        self._interval = None

    def start(self, interval: float) -> bool:
        started_windows = []
        for window in app.windows:
            if not window._start_display_link(interval):  # noqa: SLF001
                for started_window in started_windows:
                    started_window._stop_display_link()  # noqa: SLF001
                return False
            started_windows.append(window)

        self._interval = interval
        self._active = True
        return True

    def stop(self) -> None:
        if not self._active:
            return

        self._active = False
        self._interval = None
        for window in app.windows:
            window._stop_display_link()  # noqa: SLF001

    def add_window(self, window: CocoaWindow) -> bool:
        return not self._active or window._start_display_link(self._interval)  # noqa: SLF001

    def remove_window(self, window: CocoaWindow) -> None:
        window._stop_display_link()  # noqa: SLF001


class CocoaPlatformEventLoop(PlatformEventLoop):

    def __init__(self):
        super().__init__()
        set_realtime_thread_policy()
        self._timer = None
        nsview = ObjCClass('NSView')
        self._display_link_supported = bool(
            nsview.instancesRespondToSelector_(get_selector('displayLinkWithTarget:selector:'))
        )

        with AutoReleasePool():
            # Prepare the default application.
            self.NSApp = NSApplication.sharedApplication()
            if self.NSApp.isRunning():
                # Application was already started by GUI library (e.g. wxPython).
                return
            if not self.NSApp.mainMenu():
                create_menu()
            self.NSApp.setActivationPolicy_(cocoapy.NSApplicationActivationPolicyRegular)
            defaults = NSUserDefaults.standardUserDefaults()
            holdEnabled = cocoapy.CFSTR("ApplePressAndHoldEnabled")
            if not defaults.objectForKey_(holdEnabled):
                defaults.setBool_forKey_(False, holdEnabled)
            cocoapy.cf.CFRelease(holdEnabled)

            self.appdelegate = _AppDelegate.alloc().init(self)
            self.NSApp.setDelegate_(self.appdelegate)

            self._finished_launching = False

        def term_received(*args):
            if self._timer:
                self._timer.invalidate()
                self._timer = None

            if self.NSApp:
                self.NSApp.terminate_(None)

        # Force NSApp to close if Python receives sig events.
        signal.signal(signal.SIGINT, term_received)
        signal.signal(signal.SIGTERM, term_received)

    def start(self) -> None:
        with AutoReleasePool():
            if not self.NSApp.isRunning() and not self._finished_launching:
                # finishLaunching should be called only once. However isRunning will not
                # guard this, as we are not using the normal event loop.
                self.NSApp.finishLaunching()
                self.NSApp.activateIgnoringOtherApps_(True)
                self._finished_launching = True

    def create_window_draw_source(self, _event_loop: EventLoop) -> WindowDrawSource | None:
        if pyglet.options.osx_displaylink and self._display_link_supported:
            return CocoaWindowDrawSource()
        return None

    def nsapp_start(self, interval: float) -> None:
        """Used only for CocoaAlternateEventLoop."""
        from pyglet.app import event_loop  # noqa: PLC0415
        self._event_loop = event_loop

        assert self._timer is None

        self._timer = NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(
            interval,  # Clamped internally to 0.0001 (including 0)
            self.appdelegate,
            get_selector('updatePyglet:'),
            False,
            True,
        )

        self.NSApp.run()

    def nsapp_step(self) -> None:
        """Used only for CocoaAlternateEventLoop."""
        self._event_loop.idle()
        with AutoReleasePool():
            self.dispatch_posted_events()

    def nsapp_stop(self) -> None:
        """Used only for CocoaAlternateEventLoop."""
        self.NSApp.stop_(None)

        if self._timer:
            self._timer.invalidate()
            self._timer = None

    def step(self, timeout: float | None=None) -> bool:  # noqa: ANN201
        with AutoReleasePool():
            self.dispatch_posted_events()

            # Determine the timeout date.
            if timeout is None:
                # Using distantFuture as untilDate means that nextEventMatchingMask
                # will wait until the next event comes along.
                timeout_date = NSDate.distantFuture()
            elif timeout == 0.0:
                timeout_date = None
            else:
                timeout_date = NSDate.dateWithTimeIntervalSinceNow_(timeout)

            # Retrieve the next event (if any).  We wait for an event to show up
            # and then process it, or if timeout_date expires we simply return.
            # We only process one event per call of step().
            self._is_running.set()
            event = self.NSApp.nextEventMatchingMask_untilDate_inMode_dequeue_(
                cocoapy.NSAnyEventMask, timeout_date, cocoapy.NSDefaultRunLoopMode, True)

            # Dispatch the event (if any).
            if event is not None:
                event_type = event.type()
                if event_type != cocoapy.NSApplicationDefined:
                    self.NSApp.sendEvent_(event)

                self.NSApp.updateWindows()
                did_time_out = False
            else:
                did_time_out = True

            self._is_running.clear()

            return did_time_out

    def stop(self) -> None:
        pass

    def notify(self) -> None:
        with AutoReleasePool():
            notifyEvent = NSEvent.otherEventWithType_location_modifierFlags_timestamp_windowNumber_context_subtype_data1_data2_(
                cocoapy.NSApplicationDefined, # type
                cocoapy.NSPoint(0.0, 0.0),    # location
                0,                            # modifierFlags
                0,                            # timestamp
                0,                            # windowNumber
                None,                         # graphicsContext
                0,                            # subtype
                0,                            # data1
                0,                            # data2
                )

            self.NSApp.postEvent_atStart_(notifyEvent, False)
