"""Display positioned, scaled and rotated images.

A sprite is an instance of an image displayed on-screen.  Multiple sprites can
display the same image at different positions on the screen.  Sprites can also
be scaled larger or smaller, rotated at any angle and drawn at a fractional
opacity.

The following complete example loads a ``"ball.png"`` image and creates a
sprite for that image.  The sprite is then drawn in the window's
draw event handler::

    import pyglet

    ball_image = pyglet.image.load('ball.png')
    ball = pyglet.sprite.Sprite(ball_image, x=50, y=50)

    window = pyglet.window.Window()

    @window.event
    def on_draw():
        ball.draw()

    pyglet.app.run()

The sprite can be moved by modifying the :py:attr:`~pyglet.sprite.Sprite.x` and
:py:attr:`~pyglet.sprite.Sprite.y` properties.  Other
properties determine the sprite's :py:attr:`~pyglet.sprite.Sprite.rotation`,
:py:attr:`~pyglet.sprite.Sprite.scale` and
:py:attr:`~pyglet.sprite.Sprite.opacity`.

By default, sprite coordinates are restricted to integer values to avoid
sub-pixel artifacts.  If you require to use floats, for example for smoother
animations, you can set the ``subpixel`` parameter to ``True`` when creating
the sprite (:since: pyglet 1.2).

The sprite's positioning, rotation and scaling honor its
:py:attr:`~pyglet.sprite.Sprite.anchor_position`.


Drawing multiple sprites
========================

Sprites can be "batched" together and drawn at once more quickly than if each
of their ``draw`` methods were called individually.  The following example
creates one hundred ball sprites and adds each of them to a :py:class:`~pyglet.graphics.Batch`.  The
entire batch of sprites is then drawn in one call::

    batch = pyglet.graphics.Batch()

    ball_sprites = []
    for i in range(100):
        x, y = i * 10, 50
        ball_sprites.append(pyglet.sprite.Sprite(ball_image, x, y, batch=batch))

    @window.event
    def on_draw():
        batch.draw()

Sprites can be freely modified in any way even after being added to a batch,
however a sprite can belong to at most one batch.  See the documentation for
:py:mod:`pyglet.graphics` for more details on batched rendering, and grouping of
sprites within batches.

.. versionadded:: 1.1
"""
from __future__ import annotations

from dataclasses import dataclass
import sys
from typing import TYPE_CHECKING, ClassVar

import pyglet
from pyglet import event, clock
from pyglet.graphics.draw import DrawContext, BatchDrawOptions

if TYPE_CHECKING:
    from typing import Literal
    from pyglet.graphics.texture import Texture
    from pyglet.graphics.draw import Batch
    from pyglet.graphics.shader import ShaderProgram

from pyglet.graphics import Group
from pyglet.enums import Anchor, BlendFactor, GeometryMode, GraphicsAPI
from pyglet.image.base import Animation, ImageData
from pyglet.graphics.texture import TextureArrayRegion


if pyglet.options.backend in (GraphicsAPI.OPENGL, GraphicsAPI.OPENGL_ES_3):
    from pyglet.graphics.api.gl.sprite import (
        get_default_array_shader,
        get_default_multitexture_shader,
        get_default_shader,
    )
elif pyglet.options.backend in (GraphicsAPI.OPENGL_2, GraphicsAPI.OPENGL_ES_2):
    from pyglet.graphics.api.gl2.sprite import (
        get_default_array_shader,
        get_default_multitexture_shader,
        get_default_shader,
    )
elif pyglet.options.backend == GraphicsAPI.WEBGL:
    from pyglet.graphics.api.webgl.sprite import (
        get_default_array_shader,
        get_default_multitexture_shader,
        get_default_shader,
    )
elif pyglet.options.backend == GraphicsAPI.VULKAN:
    from pyglet.graphics.api.vulkan.sprite import get_default_array_shader, get_default_shader, SpriteGroup

    def get_default_multitexture_shader(_layers) -> ShaderProgram:  # noqa: ANN001
        """Vulkan placeholder for API parity."""
        msg = "MultiTextureSprite is unsupported on the Vulkan backend."
        raise NotImplementedError(msg)

_is_pyglet_doc_run = hasattr(sys, "is_pyglet_doc_run") and sys.is_pyglet_doc_run


class SpriteGroup(Group):
    """Shared Sprite rendering Group."""

    def __init__(self, texture: Texture, blend_src: BlendFactor, blend_dest: BlendFactor,
                 program: ShaderProgram, parent: Group | None = None) -> None:
        """Create a sprite group.

        The group is created internally when a :py:class:`~pyglet.sprite.Sprite`
        is created; applications usually do not need to explicitly create it.

        Args:
            texture:
                The (top-level) texture containing the sprite image.
            blend_src:
                Blend factor source mode; for example: ``SRC_ALPHA``.
            blend_dest:
                Blend factor source mode; for example: ``_ONE_MINUS_SRC_ALPHA``.
            program:
                A custom ShaderProgram.
            parent:
                Optional parent group.
        """
        super().__init__(parent=parent)
        self.texture = texture
        self.set_shader_program(program)
        self.set_blend(blend_src, blend_dest)
        self.set_texture(self.texture, 0)


class Sprite(event.EventDispatcher):
    """Manipulate an on-screen image.

    See the module documentation for usage.
    """

    _batch = None
    _animation = None
    _anchor_x = 0.0
    _anchor_y = 0.0
    _anchor: Anchor | None = None
    _frame_index = 0
    _paused = False
    _rotation = 0
    _rgba: tuple[int, int, int, int] = (255, 255, 255, 255)
    _scale = 1.0
    _scale_x = 1.0
    _scale_y = 1.0
    _visible = True
    _vertex_list = None

    #: Default class used to create the rendering group.
    group_class: ClassVar[type[SpriteGroup | Group]] = SpriteGroup

    def __init__(self,
                 img: ImageData | Texture | Animation,
                 x: float = 0, y: float = 0, z: float = 0,
                 anchor: Anchor | str | tuple[float, float] | None = None,
                 blend_src: BlendFactor = BlendFactor.SRC_ALPHA,
                 blend_dest: BlendFactor = BlendFactor.ONE_MINUS_SRC_ALPHA,
                 batch: Batch | None = None,
                 group: Group | None = None,
                 subpixel: bool = False,
                 program: ShaderProgram | None = None) -> None:
        """Create a Sprite instance.

        Args:
            img:
                Image or Animation to display.
            x:
                X coordinate of the sprite.
            y:
                Y coordinate of the sprite.
            z:
                Z coordinate of the sprite.
            anchor:
                Anchor offset relative to the image's lower-left corner. Pass
                a numeric ``(x, y)`` tuple for an explicit offset, or a named
                anchor such as ``"bottom_center"`` or
                :attr:`~pyglet.enums.Anchor.TOP`. Named anchors are
                recalculated when the image or animation frame changes.
            blend_src:
                Blend source factor. The default is suitable for
                compositing sprites drawn from back-to-front.
            blend_dest:
                Blend destination factor. The default is suitable for
                compositing sprites drawn from back-to-front.
            batch:
                Optional batch to add the sprite to.
            group:
                Optional parent group of the sprite.
            subpixel:
                Allow floating-point coordinates for the sprite. By default,
                coordinates are restricted to integer values.
            program:
                A specific shader program to initialize the sprite with. By default, a pre-made shader will be chosen
                based on the texture type passed. Sprite colors are uploaded as four unsigned bytes; custom programs
                must use ``attribute_layout=pyglet.graphics.AttributeLayout(colors="Bn")`` so the values are normalized
                for the shader.
        .. versionchanged:: 2.0.16
           Added *program* parameter.
        .. versionchanged:: 3.0
           Added *anchor* parameter.
        """
        self._x = x
        self._y = y
        self._z = z
        self._anchor_x = 0.0
        self._anchor_y = 0.0
        self._anchor = None
        if isinstance(anchor, tuple):
            self._anchor_x, self._anchor_y = anchor
        elif anchor is not None:
            self._anchor = Anchor(anchor)

        if isinstance(img, Animation):
            self._animation = img
            self._texture = img.frames[0].image.get_texture()
            self._next_dt = img.frames[0].duration
            if self._next_dt:
                clock.schedule_once(self._animate, self._next_dt)
        else:
            self._texture = img.get_texture()

        self._resolve_anchor()

        if not program:
            if isinstance(img, TextureArrayRegion):
                program = get_default_array_shader()
            else:
                program = get_default_shader()

        self._program = program
        self._batch = batch
        self._blend_src = blend_src
        self._blend_dest = blend_dest
        self._user_group = group
        self._group = self.get_sprite_group()
        self._subpixel = subpixel
        self._create_vertex_list()

    def __del__(self) -> None:
        try:
            if self._vertex_list is not None:
                self._vertex_list.delete()
        except Exception:  # noqa: BLE001, S110
            pass

    def delete(self) -> None:
        """Force immediate removal of the sprite from video memory.

        It is recommended to call this whenever you delete a sprite,
        as the Python garbage collector will not necessarily call the
        finalizer as soon as the sprite falls out of scope.
        """
        if self._animation:
            clock.unschedule(self._animate)
        self._vertex_list.delete()
        self._vertex_list = None
        self._texture = None

        # Easy way to break circular reference, speeds up GC
        self._group = None

    def _animate(self, dt: float) -> None:
        self._frame_index += 1
        if self._frame_index >= len(self._animation.frames):
            self._frame_index = 0
            self.dispatch_event('on_animation_end')
            if self._vertex_list is None:
                return  # Deleted in event handler.

        frame = self._animation.frames[self._frame_index]
        self._set_texture(frame.image.get_texture())

        if frame.duration is not None:
            duration = frame.duration - (self._next_dt - dt)
            duration = min(max(0.0, duration), frame.duration)
            clock.schedule_once(self._animate, duration)
            self._next_dt = duration
        else:
            self.dispatch_event('on_animation_end')

    @property
    def blend_mode(self) -> tuple[BlendFactor, BlendFactor]:
        """The current blend mode applied to this sprite.

        .. note:: Changing this can be an expensive operation as it involves a group creation and transfer.
        """
        return self._blend_src, self._blend_dest

    @blend_mode.setter
    def blend_mode(self, modes: tuple[int, int]) -> None:
        src, dst = modes
        if src == self._blend_src and dst == self._blend_dest:
            return

        self._blend_src = src
        self._blend_dest = dst

        self._group = self.get_sprite_group()
        if self._batch is not None:
            self._batch.migrate(self._vertex_list, GeometryMode.TRIANGLES, self._group, self._batch)

    @property
    def program(self) -> ShaderProgram:
        """The current shader program.

        .. note:: Changing this can be an expensive operation as it involves a group creation and transfer.
        """
        return self._program

    @program.setter
    def program(self, program: ShaderProgram) -> None:
        if self._program == program:
            return
        self._program = program
        self._group = self.get_sprite_group()

        if (self._batch and
                self._batch.update_shader(self._vertex_list, GeometryMode.TRIANGLES, self._group, program)):
            # Exit early if changing domain is not needed.
            return

        # Recreate vertex list.
        self._vertex_list.delete()
        self._create_vertex_list()

    @property
    def batch(self) -> Batch | None:
        """Graphics batch.

        The sprite can be migrated from one batch to another, or removed from
        its batch (for individual drawing).

        .. note:: Changing this can be an expensive operation as it involves deleting the vertex list and recreating it.
        """
        return self._batch

    @batch.setter
    def batch(self, batch: Batch) -> None:
        if self._batch == batch:
            return

        if batch is not None and self._batch is not None:
            self._batch.migrate(self._vertex_list, GeometryMode.TRIANGLES, self._group, batch)
            self._batch = batch
        else:
            self._vertex_list.delete()
            self._batch = batch
            self._create_vertex_list()

    @property
    def group(self) -> Group:
        """Parent graphics group specified by the user.

        This group will always be the parent of the internal sprite group.

        .. note:: Changing this can be an expensive operation as it involves a group creation and transfer.
        """
        return self._user_group

    @group.setter
    def group(self, group: Group) -> None:
        if self._user_group == group:
            return
        self._user_group = group
        self._group = self.get_sprite_group()
        if self._batch is not None:
            self._batch.migrate(self._vertex_list, GeometryMode.TRIANGLES, self._group, self._batch)

    @property
    def image(self) -> Texture | Animation:
        """The Sprite's Image or Animation to display.

        .. note:: Changing this can be an expensive operation if the texture is not part of the same texture or atlas.
        """
        if self._animation:
            return self._animation
        return self._texture

    @image.setter
    def image(self, img: Texture | Animation) -> None:
        if self._animation is not None:
            clock.unschedule(self._animate)
            self._animation = None

        if isinstance(img, Animation):
            self._animation = img
            self._frame_index = 0
            self._set_texture(img.frames[0].image.get_texture())
            self._next_dt = img.frames[0].duration
            if self._next_dt:
                clock.schedule_once(self._animate, self._next_dt)
        else:
            self._set_texture(img.get_texture())

    def _set_texture(self, texture: Texture) -> None:
        previous_size = self._texture.width, self._texture.height
        texture_changed = texture.key != self._texture.key
        self._texture = texture
        self._resolve_anchor()

        if texture_changed:
            self._group = self.get_sprite_group()
            if self._batch is not None:
                self._batch.migrate(self._vertex_list, GeometryMode.TRIANGLES, self._group, self._batch)
            else:
                self._vertex_list.delete()
                self._create_vertex_list()
                return

        self._vertex_list.tex_coords[:] = texture.tex_coords

        # Vertices need to be updated when texture size or anchor differs.
        if self._anchor is not None or (texture.width, texture.height) != previous_size:
            self._update_position()

    def _create_vertex_list(self) -> None:
        self._vertex_list = self.program.vertex_list_indexed(
            4, GeometryMode.TRIANGLES, [0, 1, 2, 0, 2, 3], self._batch, self._group,
            position=self._get_vertices(),
            colors=self._rgba * 4,
            translate=(self._x, self._y, self._z) * 4,
            scale=(self._scale * self._scale_x, self._scale * self._scale_y) * 4,
            rotation=(self._rotation,) * 4,
            tex_coords=self._texture.tex_coords)

    def _get_vertices(self) -> tuple:
        if not self._visible:
            return 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

        img = self._texture
        x1 = -self._anchor_x
        y1 = -self._anchor_y
        x2 = x1 + img.width
        y2 = y1 + img.height

        if not self._subpixel:
            return (int(x1), int(y1), 0, int(x2), int(y1), 0,
                    int(x2), int(y2), 0, int(x1), int(y2), 0)

        return x1, y1, 0, x2, y1, 0, x2, y2, 0, x1, y2, 0

    def _update_position(self) -> None:
        self._vertex_list.position[:] = self._get_vertices()

    def _resolve_anchor(self) -> None:
        if self._anchor is None:
            return

        self._anchor_x, self._anchor_y = self._anchor.get_position(self._texture.width, self._texture.height)

    @property
    def anchor(self) -> Anchor | None:
        """The named anchor position, or ``None`` when using a numeric anchor."""
        return self._anchor

    @anchor.setter
    def anchor(self, anchor: Anchor | str | None) -> None:
        self._anchor = Anchor(anchor) if anchor is not None else None
        self._resolve_anchor()
        self._update_position()

    @property
    def anchor_x(self) -> float:
        """X coordinate of the anchor, relative to the image's left edge."""
        return self._anchor_x

    @anchor_x.setter
    def anchor_x(self, anchor_x: float) -> None:
        self._anchor = None
        self._anchor_x = anchor_x
        self._update_position()

    @property
    def anchor_y(self) -> float:
        """Y coordinate of the anchor, relative to the image's bottom edge."""
        return self._anchor_y

    @anchor_y.setter
    def anchor_y(self, anchor_y: float) -> None:
        self._anchor = None
        self._anchor_y = anchor_y
        self._update_position()

    @property
    def anchor_position(self) -> tuple[float, float]:
        """The anchor's ``(x, y)`` offset from the sprite's lower-left corner."""
        return self._anchor_x, self._anchor_y

    @anchor_position.setter
    def anchor_position(self, position: tuple[float, float]) -> None:
        self._anchor = None
        self._anchor_x, self._anchor_y = position
        self._update_position()

    def get_sprite_group(self) -> SpriteGroup | Group:
        """Creates and returns a group to be used to render the sprite.

        This is used internally to create a consolidated group for rendering.

        .. note:: This is for advanced usage. This is a group automatically created internally as a child of ``group``,
                  and does not need to be modified unless the parameters of your custom group changes.

        .. versionadded:: 2.0.16
        """
        return self.group_class(self._texture, self._blend_src, self._blend_dest, self._program, self._user_group)

    @property
    def position(self) -> tuple[float, float, float]:
        """The (x, y, z) coordinates of the sprite, as a tuple."""
        return self._x, self._y, self._z

    @position.setter
    def position(self, position: tuple[float, float, float]) -> None:
        self._x, self._y, self._z = position
        self._vertex_list.translate[:] = position * 4

    @property
    def x(self) -> float:
        """X coordinate of the sprite."""
        return self._x

    @x.setter
    def x(self, x: float) -> None:
        self._x = x
        self._vertex_list.translate[:] = (x, self._y, self._z) * 4

    @property
    def y(self) -> float:
        """Y coordinate of the sprite."""
        return self._y

    @y.setter
    def y(self, y: float) -> None:
        self._y = y
        self._vertex_list.translate[:] = (self._x, y, self._z) * 4

    @property
    def z(self) -> float:
        """Z coordinate of the sprite."""
        return self._z

    @z.setter
    def z(self, z: float) -> None:
        self._z = z
        self._vertex_list.translate[:] = (self._x, self._y, z) * 4

    @property
    def rotation(self) -> float:
        """Clockwise rotation of the sprite, in degrees.

        The sprite is rotated about its :attr:`anchor_position`.
        """
        return self._rotation

    @rotation.setter
    def rotation(self, rotation: float) -> None:
        self._rotation = rotation
        self._vertex_list.rotation[:] = (self._rotation,) * 4

    @property
    def scale(self) -> float:
        """Base Scaling factor.

        A scaling factor of 1.0 (the default) has no effect. A scale of
        2.0 will draw the sprite at twice the native size of its image.
        """
        return self._scale

    @scale.setter
    def scale(self, scale: float) -> None:
        self._scale = scale
        self._vertex_list.scale[:] = (scale * self._scale_x, scale * self._scale_y) * 4

    @property
    def scale_x(self) -> float:
        """Horizontal scaling factor.

        A scaling factor of 1.0 (the default) has no effect. A scale of
        2.0 will draw the sprite at twice the native width of its image.
        """
        return self._scale_x

    @scale_x.setter
    def scale_x(self, scale_x: float) -> None:
        self._scale_x = scale_x
        self._vertex_list.scale[:] = (self._scale * scale_x, self._scale * self._scale_y) * 4

    @property
    def scale_y(self) -> float:
        """Vertical scaling factor.

        A scaling factor of 1.0 (the default) has no effect. A scale of
        2.0 will draw the sprite at twice the native height of its image.
        """
        return self._scale_y

    @scale_y.setter
    def scale_y(self, scale_y: float) -> None:
        self._scale_y = scale_y
        self._vertex_list.scale[:] = (self._scale * self._scale_x, self._scale * scale_y) * 4

    def update(self, x: float | None = None, y: float | None = None, z: float | None = None,
               rotation: float | None = None, scale: float | None = None,
               scale_x: float | None = None, scale_y: float | None = None) -> None:
        """Simultaneously change the position, rotation or scale.

        This method is provided for convenience. There is not much
        performance benefit to updating multiple Sprite attributes at once.

        Args:
            x:
                X coordinate of the sprite.
            y:
                Y coordinate of the sprite.
            z:
                Z coordinate of the sprite.
            rotation:
                Clockwise rotation of the sprite, in degrees.
            scale:
                Scaling factor.
            scale_x:
                Horizontal scaling factor.
            scale_y:
                Vertical scaling factor.

        .. deprecated:: 2.0.x
           No longer calculated with the vertices on the CPU. Now calculated within a shader.

           * Use ``x``, ``y``, ``z``, or ``position`` to update position.
           * Use ``rotation`` to update rotation.
           * Use ``scale_x``, ``scale_y``, or ``scale`` to update scale.
        """
        translations_outdated = False

        # only bother updating if the translation actually changed
        if x is not None:
            self._x = x
            translations_outdated = True
        if y is not None:
            self._y = y
            translations_outdated = True
        if z is not None:
            self._z = z
            translations_outdated = True

        if translations_outdated:
            self._vertex_list.translate[:] = (self._x, self._y, self._z) * 4

        if rotation is not None and rotation != self._rotation:
            self._rotation = rotation
            self._vertex_list.rotation[:] = (rotation,) * 4

        scales_outdated = False

        # only bother updating if the scale actually changed
        if scale is not None:
            self._scale = scale
            scales_outdated = True
        if scale_x is not None:
            self._scale_x = scale_x
            scales_outdated = True
        if scale_y is not None:
            self._scale_y = scale_y
            scales_outdated = True

        if scales_outdated:
            self._vertex_list.scale[:] = (self._scale * self._scale_x, self._scale * self._scale_y) * 4

    @property
    def width(self) -> float:
        """Scaled width of the sprite.

        Invariant under rotation.
        """
        w = self._texture.width * abs(self._scale_x) * abs(self._scale)
        return w if self._subpixel else int(w)

    @width.setter
    def width(self, width: float) -> None:
        self.scale_x = width / (self._texture.width * abs(self._scale))

    @property
    def height(self) -> float:
        """Scaled height of the sprite.

        Invariant under rotation.
        """
        h = self._texture.height * abs(self._scale_y) * abs(self._scale)
        return h if self._subpixel else int(h)

    @height.setter
    def height(self, height: float) -> None:
        self.scale_y = height / (self._texture.height * abs(self._scale))

    @property
    def opacity(self) -> int:
        """Blend opacity.

        This property sets the alpha component of the colour of the sprite's
        vertices.  With the default blend mode (see the constructor), this
        allows the sprite to be drawn with fractional opacity, blending with the
        background.

        An opacity of 255 (the default) has no effect.  An opacity of 128 will
        make the sprite appear translucent.
        """
        return self._rgba[3]

    @opacity.setter
    def opacity(self, opacity: int):
        r, g, b, _ = self._rgba
        self._rgba = r, g, b, opacity
        self._vertex_list.colors[:] = self._rgba * 4

    @property
    def color(self) -> tuple[int, int, int, int]:
        """Blend color.

        This property sets the color of the sprite's vertices. This allows the
        sprite to be drawn with a color tint.

        The color is specified as either an RGBA tuple of integers
        '(red, green, blue, opacity)' or an RGB tuple of integers
        `(red, blue, green)`.

        If there are fewer than three components, a :py:func`ValueError`
        will be raised. Each color component must be an int in the range
        0 (dark) to 255 (saturated). If any component is not an int, a
        :py:class:`TypeError` will be raised.
        """
        return self._rgba

    @color.setter
    def color(self, rgba: tuple[int, int, int, int] | tuple[int, int, int]):
        # ValueError raised by unpacking if len(rgba) < 3
        r, g, b, *a = rgba
        new_color = r, g, b, a[0] if a else 255

        # Only update if we actually have to
        if new_color != self._rgba:
            self._rgba = new_color
            self._vertex_list.colors[:] = new_color * 4

    @property
    def visible(self) -> bool:
        """True if the sprite will be drawn."""
        return self._visible

    @visible.setter
    def visible(self, visible: bool) -> None:
        self._visible = visible
        self._update_position()

    @property
    def paused(self) -> bool:
        """Pause/resume the Sprite's Animation.

        If ``Sprite.image`` is an Animation, you can pause or resume
        the animation by setting this property to True or False.
        If not an Animation, this has no effect.
        """
        return self._paused

    @paused.setter
    def paused(self, pause: bool) -> None:
        if not hasattr(self, '_animation') or pause == self._paused:
            return
        if pause is True:
            clock.unschedule(self._animate)
        else:
            frame = self._animation.frames[self._frame_index]
            self._next_dt = frame.duration
            if self._next_dt:
                clock.schedule_once(self._animate, self._next_dt)
        self._paused = pause

    @property
    def frame_index(self) -> int:
        """The current Animation frame.

        If the ``Sprite.image`` is an ``Animation``, you can query or set
        the current frame. If not an Animation, this will always be 0.
        """
        return self._frame_index

    @frame_index.setter
    def frame_index(self, index: int) -> None:
        """Set the current Animation frame.

        Args:
            index:
                The desired frame index.

        Updates the currently displayed frame of an animation immediately even if
        the animation is paused.  If not an Animation, this has no effect.
        """
        # Bound to available number of frames
        if self._animation is None:
            return
        self._frame_index = max(0, min(index, len(self._animation.frames) - 1))
        frame = self._animation.frames[self._frame_index]
        self._set_texture(frame.image.get_texture())

    def draw(self) -> None:
        """Draw the sprite at its current position.

        See the module documentation for hints on drawing multiple sprites
        efficiently.
        """
        ctx = pyglet.graphics.api.core.current_context

        draw_ctx = DrawContext(
            surface_ctx=ctx,
            backend_ctx=None,
            draw_pass=BatchDrawOptions().resolve(ctx),
            renderer=ctx.renderer,
        )
        draw_ctx.begin()
        self._group.set_state_recursive(draw_ctx)
        self._vertex_list.draw(GeometryMode.TRIANGLES)
        self._group.unset_state_recursive(draw_ctx)

    if _is_pyglet_doc_run:
        # Events

        def on_animation_end(self) -> None | Literal[True]:
            """The sprite animation reached the final frame.

            The event is triggered only if the sprite has an animation, not an
            image.  For looping animations, the event is triggered each time
            the animation loops.

            :event:
            """


class MultiTextureSpriteGroup(Group):
    """Shared Multi-texture Sprite rendering Group."""

    def __init__(self, textures: dict[str, Texture], blend_src: BlendFactor, blend_dest: BlendFactor,
                 program: ShaderProgram, parent: Group | None = None) -> None:
        """Create a sprite group that binds multiple textures and sampler uniforms."""
        super().__init__(parent=parent)
        self.set_shader_program(program)
        self.set_blend(blend_src, blend_dest)
        self.set_textures(textures, program)


@dataclass
class _LayerAnimationState:
    animation: Animation
    frame_idx: int = 0
    next_dt: float | None = None


class MultiTextureSprite(Sprite):
    """Sprite variant that renders and animates multiple texture layers."""

    group_class: ClassVar[type[MultiTextureSpriteGroup]] = MultiTextureSpriteGroup

    def __init__(self,
                 images: dict[str, ImageData | Texture | Animation],
                 x: float = 0, y: float = 0, z: float = 0,
                 anchor: Anchor | str | tuple[float, float] | None = None,
                 blend_src: BlendFactor = BlendFactor.SRC_ALPHA,
                 blend_dest: BlendFactor = BlendFactor.ONE_MINUS_SRC_ALPHA,
                 batch: Batch | None = None,
                 group: Group | None = None,
                 subpixel: bool = False,
                 program: ShaderProgram | None = None) -> None:
        """Create a MultiTextureSprite instance.

        Args:
            images:
                Dictionary of named Image, Texture, or Animation layers to display.
                Keys are used as sampler names in the shader.
            x:
                X coordinate of the sprite.
            y:
                Y coordinate of the sprite.
            z:
                Z coordinate of the sprite.
            anchor:
                Anchor offset relative to the largest layer's lower-left
                corner. Pass a numeric ``(x, y)`` tuple for an explicit
                offset, or a named anchor that is recalculated when the
                anchor texture changes.
            blend_src:
                Blend source factor. The default is suitable for
                compositing sprites drawn from back-to-front.
            blend_dest:
                Blend destination factor. The default is suitable for
                compositing sprites drawn from back-to-front.
            batch:
                Optional batch to add the sprite to.
            group:
                Optional parent group of the sprite.
            subpixel:
                Allow floating-point coordinates for the sprite. By default,
                coordinates are restricted to integer values.
            program:
                A specific shader program to initialize the sprite with. By default,
                a generated multi-texture shader will be chosen based on the layer types passed.

        .. versionadded:: 3.0
        """
        if not images:
            msg = "MultiTextureSprite requires at least one layer."
            raise ValueError(msg)

        self._textures: dict[str, Texture] = {}
        self._layers: dict[str, ImageData | Texture | Animation] = {}
        self._animations: dict[str, _LayerAnimationState] = {}
        self._texture: Texture | None = None

        for name, img in images.items():
            self._layers[name] = img
            if isinstance(img, Animation):
                texture = img.frames[0].image.get_texture()
                self._animations[name] = _LayerAnimationState(img, 0, img.frames[0].duration)
            else:
                texture = img.get_texture()

            self._textures[name] = texture

            if self._texture is None or (texture.width * texture.height) > (self._texture.width * self._texture.height):
                self._texture = texture

        assert self._texture is not None

        if program is None:
            program = get_default_multitexture_shader(self._textures)

        super().__init__(self._texture, x, y, z, anchor, blend_src, blend_dest, batch, group, subpixel, program)
        self._schedule_all_animations()

    def _schedule_all_animations(self) -> None:
        clock.unschedule(self._animate)
        if self._paused:
            return

        for name, layer_animation in self._animations.items():
            frame = layer_animation.animation.frames[layer_animation.frame_idx]
            layer_animation.next_dt = frame.duration
            if layer_animation.next_dt:
                clock.schedule_once(self._animate, layer_animation.next_dt, name)

    def delete(self) -> None:
        clock.unschedule(self._animate)
        super().delete()

    def get_sprite_group(self) -> MultiTextureSpriteGroup:
        return self.group_class(self._textures, self._blend_src, self._blend_dest, self._program, self._user_group)

    def _animate(self, dt: float, key: str) -> None:
        layer_animation = self._animations.get(key)
        if layer_animation is None:
            return

        frames = layer_animation.animation.frames
        layer_animation.frame_idx += 1

        if layer_animation.frame_idx >= len(frames):
            layer_animation.frame_idx = 0
            self.dispatch_event('on_animation_end')
            if self._vertex_list is None:
                return  # deleted in event handler

        frame = frames[layer_animation.frame_idx]
        self._set_multi_texture(key, frame.image.get_texture())

        if frame.duration is not None:
            duration = frame.duration - ((layer_animation.next_dt or 0.0) - dt)
            duration = min(max(0.0, duration), frame.duration)
            layer_animation.next_dt = duration
            clock.schedule_once(self._animate, duration, key)
        else:
            self.dispatch_event('on_animation_end')

    def _set_multi_texture(self, key: str, new_tex: Texture) -> None:
        if new_tex.key != self._textures[key].key:
            # Copy so this instance can diverge from grouped peers on migration.
            self._textures = self._textures.copy()
            self._textures[key] = new_tex
            self._group = self.get_sprite_group()
            if self._batch is not None:
                self._batch.migrate(self._vertex_list, GeometryMode.TRIANGLES, self._group, self._batch)
            else:
                self._vertex_list.delete()
                self._create_vertex_list()
                return
        else:
            self._textures[key] = new_tex

        getattr(self._vertex_list, f"{key}_coords")[:] = self._textures[key].tex_coords

    def _create_vertex_list(self) -> None:
        tex_coords = {}
        for name, tex in self._textures.items():
            tex_coords[f"{name}_coords"] = tex.tex_coords

        self._vertex_list = self._program.vertex_list_indexed(
            4, GeometryMode.TRIANGLES, [0, 1, 2, 0, 2, 3], self._batch, self._group,
            position=self._get_vertices(),
            colors=self._rgba * 4,
            translate=(self._x, self._y, self._z) * 4,
            scale=(self._scale * self._scale_x, self._scale * self._scale_y) * 4,
            rotation=(self._rotation,) * 4,
            **tex_coords)

    def _get_base_texture(self) -> Texture:
        return max(self._textures.values(), key=lambda tex: tex.width * tex.height)

    def set_frame_index(self, name: str, frame_idx: int) -> None:
        """Set the current animation frame for a single layer."""
        layer_animation = self._animations.get(name)
        if layer_animation is None:
            return

        layer_animation.frame_idx = max(0, min(frame_idx, len(layer_animation.animation.frames) - 1))
        frame = layer_animation.animation.frames[layer_animation.frame_idx]
        self._set_multi_texture(name, frame.image.get_texture())
        self._schedule_all_animations()

    def get_frame_index(self, name: str) -> int:
        """Get the current animation frame for a single layer."""
        layer_animation = self._animations.get(name)
        return layer_animation.frame_idx if layer_animation else 0

    def get_layer(self, name: str) -> ImageData | Texture | Animation | None:
        """Return the source image or animation for a layer."""
        return self._layers.get(name)

    def set_layer(self, name: str, img: ImageData | Texture | Animation) -> None:
        """Replace an existing layer image or animation."""
        if name not in self._textures:
            return

        self._layers[name] = img
        self._animations.pop(name, None)

        if isinstance(img, Animation):
            self._animations[name] = _LayerAnimationState(img, 0, img.frames[0].duration)
            texture = img.frames[0].image.get_texture()
        else:
            texture = img.get_texture()

        self._set_multi_texture(name, texture)

        base_texture = self._get_base_texture()
        if base_texture.key != self._texture.key:
            self._texture = base_texture
            self._update_position()

        self._schedule_all_animations()

    @property
    def frame_index(self) -> None:
        raise NotImplementedError("MultiTextureSprite does not support frame_index. Use get_frame_index instead.")

    @frame_index.setter
    def frame_index(self, _index: int) -> None:
        raise NotImplementedError("MultiTextureSprite does not support frame_index. Use set_frame_index instead.")

    @property
    def image(self) -> None:
        raise NotImplementedError("MultiTextureSprite does not support image. Use get_layer instead.")

    @image.setter
    def image(self, _img: ImageData | Texture | Animation) -> None:
        raise NotImplementedError("MultiTextureSprite does not support image. Use set_layer instead.")

    @property
    def paused(self) -> bool:
        return self._paused

    @paused.setter
    def paused(self, pause: bool) -> None:
        if pause == self._paused:
            return
        self._paused = pause
        self._schedule_all_animations()


Sprite.register_event_type('on_animation_end')

