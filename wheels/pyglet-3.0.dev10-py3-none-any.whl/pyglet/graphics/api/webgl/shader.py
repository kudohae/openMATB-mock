from __future__ import annotations

import warnings
from ctypes import (
    POINTER,
    Array,
    Structure,
    c_buffer,
    c_byte,
    c_double,
    c_float,
    c_int,
    c_short,
    c_ubyte,
    c_uint,
    c_ushort,
    cast,
    sizeof,
)
from typing import TYPE_CHECKING, Callable, Sequence, Type, Union

import pyglet

from pyglet.graphics.api.base import NullContext
from pyglet.graphics.api.webgl import gl
from pyglet.graphics.api.webgl.buffer import WebGLUniformBufferObject
from pyglet.graphics.api.webgl.gl import (
    GL_FALSE,
    GL_INFO_LOG_LENGTH,
    GL_LINK_STATUS,
    GL_TRUE,
    GL_UNIFORM_BUFFER,
)
from pyglet.graphics.shader import (
    _AbstractShader,
    _AbstractShaderProgram,
    Attribute,
    AttributeLayout,
    Shader,
    ShaderException,
    UnsupportedShaderType,
    UBOBindingManager,
    UniformBlock as BaseUniformBlock,
    UniformArrayBase,
    UniformBase,
    _build_uniform_struct_from_uniforms,
    ShaderProgram,
    ShaderSource,
    ShaderType,
    AttributeView,
    GraphicsAttribute,
)

try:
    import js  # noqa: F821
except ImportError:
    pass


class GLException(Exception):
    pass


if TYPE_CHECKING:
    from pyglet.customtypes import CTypesPointer, DataTypes, CType
    from pyglet.graphics import UnsupportedBackendError
    from pyglet.graphics.api.webgl.context import OpenGLSurfaceContext
    from pyglet.graphics.api.webgl.webgl_js import WebGL2RenderingContext, WebGLProgram, WebGLRenderingContext

_debug_api_shaders = pyglet.options.debug_api_shaders


GLDataType = Union[Type[gl.GLint], Type[gl.GLfloat], Type[gl.GLboolean], int]
GLFunc = Callable

_c_types: dict[int, CType] = {
    gl.GL_BYTE: c_byte,
    gl.GL_UNSIGNED_BYTE: c_ubyte,
    gl.GL_SHORT: c_short,
    gl.GL_UNSIGNED_SHORT: c_ushort,
    gl.GL_INT: c_int,
    gl.GL_UNSIGNED_INT: c_uint,
    gl.GL_FLOAT: c_float,
    gl.GL_DOUBLE: c_double,
}

_data_type_to_gl_type: dict[DataTypes, int] = {
    'b': gl.GL_BYTE,  # signed byte
    'B': gl.GL_UNSIGNED_BYTE,  # unsigned byte
    'h': gl.GL_SHORT,  # signed short
    'H': gl.GL_UNSIGNED_SHORT,  # unsigned short
    'i': gl.GL_INT,  # signed int
    'I': gl.GL_UNSIGNED_INT,  # unsigned int
    'f': gl.GL_FLOAT,  # float
    'q': gl.GL_INT,  # signed long long (Requires GL_INT64_NV if available. Just use int.)
    'Q': gl.GL_UNSIGNED_INT,  # unsigned long long (Requires GL_UNSIGNED_INT64_NV if available. Just use uint.)
}

_shader_types: dict[ShaderType, int] = {
    'compute': gl.GL_COMPUTE_SHADER,
    'fragment': gl.GL_FRAGMENT_SHADER,
    'geometry': gl.GL_GEOMETRY_SHADER,
    'tesscontrol': gl.GL_TESS_CONTROL_SHADER,
    'tessevaluation': gl.GL_TESS_EVALUATION_SHADER,
    'vertex': gl.GL_VERTEX_SHADER,
}

_attribute_types: dict[int, tuple[int, DataTypes]] = {
    gl.GL_BOOL: (1, '?'),
    gl.GL_BOOL_VEC2: (2, '?'),
    gl.GL_BOOL_VEC3: (3, '?'),
    gl.GL_BOOL_VEC4: (4, '?'),
    gl.GL_INT: (1, 'i'),
    gl.GL_INT_VEC2: (2, 'i'),
    gl.GL_INT_VEC3: (3, 'i'),
    gl.GL_INT_VEC4: (4, 'i'),
    gl.GL_UNSIGNED_INT: (1, 'I'),
    gl.GL_UNSIGNED_INT_VEC2: (2, 'I'),
    gl.GL_UNSIGNED_INT_VEC3: (3, 'I'),
    gl.GL_UNSIGNED_INT_VEC4: (4, 'I'),
    gl.GL_FLOAT: (1, 'f'),
    gl.GL_FLOAT_VEC2: (2, 'f'),
    gl.GL_FLOAT_VEC3: (3, 'f'),
    gl.GL_FLOAT_VEC4: (4, 'f'),
    gl.GL_DOUBLE: (1, 'd'),
    gl.GL_DOUBLE_VEC2: (2, 'd'),
    gl.GL_DOUBLE_VEC3: (3, 'd'),
    gl.GL_DOUBLE_VEC4: (4, 'd'),
}


# Accessor classes:

class GLAttribute(GraphicsAttribute):
    """Abstract accessor for an attribute in a mapped buffer."""
    gl_type: int
    """OpenGL type enumerant; for example, ``GL_FLOAT``"""

    def __init__(self, attribute: Attribute, view: AttributeView) -> None:
        """Create the attribute accessor.

        Args:
            attribute: The base shader Attribute object.
            view: The view intended for the buffer of this Attribute.
        """
        self._gl = pyglet.graphics.api.core.current_context.gl
        super().__init__(attribute, view)
        data_type = self.attribute.fmt.data_type
        self.gl_type = _data_type_to_gl_type[data_type]

        # If the data type is not normalized and is not a float, consider it an int pointer.
        self._is_int = data_type != "f" and self.attribute.fmt.normalized is False

    def enable(self) -> None:
        """Enable the attribute."""
        self._gl.enableVertexAttribArray(self.attribute.location)

    def disable(self) -> None:
        self._gl.disableVertexAttribArray(self.attribute.location)

    def set_pointer(self) -> None:
        """Setup this attribute to point to the currently bound buffer at the given offset."""
        if self._is_int:
            self._gl.vertexAttribIPointer(
                self.attribute.location,
                self.attribute.fmt.components,
                self.gl_type,
                self.view.stride,
                self.view.offset,
            )
        else:
            self._gl.vertexAttribPointer(
                self.attribute.location,
                self.attribute.fmt.components,
                self.gl_type,
                self.attribute.fmt.normalized,
                self.view.stride,
                self.view.offset,
            )

    def set_divisor(self) -> None:
        self._gl.vertexAttribDivisor(self.attribute.location, self.attribute.fmt.divisor)



class _UniformArray(UniformArrayBase):
    """Wrapper of the GLSL array data inside a Uniform.

    Allows access to get and set items for a more Pythonic implementation.
    Types with a length longer than 1 will be returned as tuples as an inner list would not support individual value
    reassignment. Array data must either be set in full, or by indexing.
    """

    _gl: WebGLRenderingContext
    __slots__ = ("_gl",)

    def __init__(
        self, uniform: _Uniform, gl_getter: GLFunc, gl_setter: GLFunc, gl_type: GLDataType, is_matrix: bool,
    ) -> None:
        self._gl = pyglet.graphics.api.core.current_context.gl
        super().__init__(uniform, gl_getter, gl_setter, gl_type, is_matrix)

    def _get_location_for_index(self, index: int) -> int:
        """Get the location for the array name.

        It is not guaranteed that the location ID's of the uniform in the shader program will be a contiguous offset.

        On MacOS, the location ID of index 0 may be 1, and then index 2 might be 5. Whereas on Windows it may be a 1:1
        offset from 0 to index. Here, we store the location ID's of each index to ensure we are setting data on the
        right location.
        """
        return self._gl.getUniformLocation(self._uniform.program, f"{self._uniform.name}[{index}]")

    def _apply_uniform_update(self, location: int, size: int, data: Sequence) -> None:
        self._gl.useProgram(self._uniform.program)
        if self._is_matrix:
            self._gl_setter(location, GL_FALSE, data)
        else:
            self._gl_setter(location, data)


_gl_matrices: tuple[int, ...] = (
    gl.GL_FLOAT_MAT2,
    gl.GL_FLOAT_MAT2x3,
    gl.GL_FLOAT_MAT2x4,
    gl.GL_FLOAT_MAT3,
    gl.GL_FLOAT_MAT3x2,
    gl.GL_FLOAT_MAT3x4,
    gl.GL_FLOAT_MAT4,
    gl.GL_FLOAT_MAT4x2,
    gl.GL_FLOAT_MAT4x3,
)


class _Uniform(UniformBase):
    _ctx: OpenGLSurfaceContext | NullContext
    __slots__ = ("_ctx",)

    def __init__(self, program: int | WebGLProgram, name: str, uniform_type: int, size: int, location: int) -> None:
        self._ctx = pyglet.graphics.api.core.current_context
        super().__init__(
            name=name,
            uniform_type=uniform_type,
            size=size,
            location=location,
            program=program,
            matrix_types=_gl_matrices,
            array_wrapper_factory=lambda uniform, gl_getter, gl_setter, gl_type, is_matrix:
                _UniformArray(uniform, gl_getter, gl_setter, gl_type, is_matrix),
        )

    def _get_uniform_accessors(self, uniform_type: int) -> tuple[GLDataType, GLFunc, GLFunc, int]:
        gl_type, gl_setter, length = self._ctx._uniform_setters[uniform_type]
        gl_getter = self._ctx.gl.getUniform
        return gl_type, gl_getter, gl_setter, length

    def _create_scalar_get_set(
        self,
        *,
        program: int | WebGLProgram,
        location: int,
        gl_getter: GLFunc,
        gl_setter: GLFunc,
        gl_type: GLDataType,
        length: int,
        is_matrix: bool,
    ) -> tuple[Callable, Callable]:
        c_array: Array[GLDataType] = (gl_type * length)()
        ptr = cast(c_array, POINTER(gl_type))
        getter = self._create_getter_func(program, location, gl_getter, length)
        setter = self._create_setter_func(
            self._ctx.gl, program, location, gl_setter, c_array, length, ptr, is_matrix,
        )
        return getter, setter

    @staticmethod
    def _create_getter_func(
        program_id: int | WebGLRenderingContext,
        location: int,
        gl_getter: GLFunc,
        length: int,
    ) -> Callable[[], Array[GLDataType] | GLDataType]:
        """Factory function for creating simplified Uniform getters."""
        def getter_func() -> GLDataType:
            return gl_getter(program_id, location)

        return getter_func

    @staticmethod
    def _create_setter_func(
        gl_ctx: WebGLRenderingContext,
        program_id: int | WebGLProgram,
        location: int,
        gl_setter: GLFunc,
        c_array: Array[GLDataType],
        length: int,
        ptr: CTypesPointer[GLDataType],
        is_matrix: bool,
    ) -> Callable[[float], None]:
        """Factory function for creating simplified Uniform setters."""
        if is_matrix:

            def setter_func(value: float) -> None:
                gl_ctx.useProgram(program_id)
                gl_setter(location, GL_FALSE, value)
        elif length == 1:

            def setter_func(value: float) -> None:
                gl_ctx.useProgram(program_id)
                gl_setter(location, value)
        elif length > 1:

            def setter_func(values: float) -> None:
                gl_ctx.useProgram(program_id)
                gl_setter(location, values)
        else:
            msg = "Uniform type not yet supported."
            raise ShaderException(msg)

        return setter_func

    def __repr__(self) -> str:
        return f"Uniform(type={self.type}, size={self.size}, location={self.location}, length={self.length})"


def get_maximum_binding_count() -> int:
    """The maximum binding value that can be used for this hardware."""
    return gl.glGetParameter(gl.GL_MAX_UNIFORM_BUFFER_BINDINGS)


class _UBOBindingManager(UBOBindingManager):
    """WebGL-backed Uniform Block binding manager."""

    def __init__(self) -> None:
        super().__init__(5)  # get_maximum_binding_count()


def get_std140_size_and_alignment(gl_type):
    """Returns (size, alignment) for a given WebGL uniform type."""
    std140_layout = {
        c_float: (4, 4),
        c_int: (4, 4),
        c_uint: (4, 4),
        gl.FLOAT_VEC2: (8, 8),
        gl.FLOAT_VEC3: (12, 16),  # Vec3 is padded to 16
        gl.FLOAT_VEC4: (16, 16),
        gl.INT_VEC2: (8, 8),
        gl.INT_VEC3: (12, 16),
        gl.INT_VEC4: (16, 16),
        gl.UNSIGNED_INT_VEC2: (8, 8),
        gl.UNSIGNED_INT_VEC3: (12, 16),
        gl.UNSIGNED_INT_VEC4: (16, 16),
        gl.FLOAT_MAT2: (32, 16),  # 2 * vec4
        gl.FLOAT_MAT3: (48, 16),  # 3 * vec4
        gl.FLOAT_MAT4: (64, 16),  # 4 * vec4
    }
    return std140_layout.get(gl_type, (0, 0))


def compute_std140_offsets(uniforms):
    """Manually computes std140-compliant offsets for uniforms in a UBO."""
    offset = 0
    offsets = {}

    for name, c_type, length, size in uniforms.values():
        type_size = sizeof(c_type * length)
        align_size = min(16, type_size)  # Align to std140

        # Align offset
        if offset % align_size != 0:
            offset += align_size - (offset % align_size)

        # Store computed offset
        offsets[name] = offset
        offset += type_size * size  # Account for array sizes

    return offsets


class WebGLUniformBlock(BaseUniformBlock):  # noqa: D101
    ctx: OpenGLSurfaceContext | NullContext
    __slots__ = ('ctx',)

    def __init__(
        self,
        program: WebGLShaderProgram,
        name: str,
        index: int,
        size: int,
        binding: int,
        uniforms: dict[int, tuple[str, GLDataType, int, int]],
        uniform_count: int,
    ) -> None:
        """Initialize a uniform block for a ShaderProgram."""
        self.ctx = pyglet.graphics.api.core.current_context
        assert self.ctx
        super().__init__(program, name, index, size, binding, uniforms, uniform_count)

    def _bind_buffer_base(self, binding: int, buffer_id: int) -> None:
        self.ctx.gl.bindBufferBase(GL_UNIFORM_BUFFER, binding, buffer_id)

    def _create_backend_ubo(
        self,
        view_class: type[Structure],
        buffer_size: int,
        binding: int,
        alignment: int | None,
        copies_per_resource: int,
        strict: bool,
    ) -> WebGLUniformBufferObject:
        return WebGLUniformBufferObject(
            self.ctx,
            view_class,
            buffer_size,
            binding,
            alignment=alignment,
            copies_per_resource=copies_per_resource,
            strict=strict,
        )

    def _set_block_binding(self) -> None:
        self.ctx.gl.uniformBlockBinding(self.program.handle, self.index, self.binding)

    def _introspect_uniforms(self) -> type[Structure]:
        """Introspect the block's structure and return a ctypes struct for manipulating the uniform block's members."""
        p_id = self.program.handle
        index = self.index

        active_count = self.uniform_count

        # Query the uniform index order and each uniform's offset:
        # indices = gl.glGetActiveUniformBlockiv(p_id, index, gl.GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES, indices_ptr)
        # offsets = gl.glGetActiveUniformsiv(p_id, active_count, indices, gl.GL_UNIFORM_OFFSET, offsets_ptr)

        # Offsets may be returned in non-ascending order, sort them with the corresponding index:
        # _oi = sorted(zip(offsets, indices), key=lambda x: x[0])
        # offsets = [x[0] for x in _oi] + [self.size]
        # indices = (gl.GLuint * active_count)(*(x[1] for x in _oi))

        # # Query other uniform information:
        # gl_types = (gl.GLint * active_count)()
        # mat_stride = (gl.GLint * active_count)()
        # gl_types_ptr = cast(addressof(gl_types), POINTER(gl.GLint))
        # stride_ptr = cast(addressof(mat_stride), POINTER(gl.GLint))
        # gl.glGetActiveUniformsiv(p_id, active_count, indices, gl.GL_UNIFORM_TYPE, gl_types_ptr)
        # gl.glGetActiveUniformsiv(p_id, active_count, indices, gl.GL_UNIFORM_MATRIX_STRIDE, stride_ptr)

        uniform_offsets = compute_std140_offsets(self.uniforms)
        sorted_uniforms = sorted(self.uniforms.values(), key=lambda uniform: uniform_offsets[uniform[0]])
        offsets = [uniform_offsets[uniform[0]] for uniform in sorted_uniforms] + [self.size]
        return _build_uniform_struct_from_uniforms("View", sorted_uniforms, offsets)

    def _actual_binding_point(self) -> int:
        """Queries OpenGL to find what the bind point currently is."""
        return self.ctx.gl.getActiveUniformBlockParameter(self.program.handle, self.index, gl.GL_UNIFORM_BLOCK_BINDING)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(program={self.program.handle}, location={self.index}, size={self.size}, "
            f"binding={self.binding})"
        )


# Utility functions:
def _get_number(gl_ctx: WebGLRenderingContext, program_id: WebGLProgram, variable_type: int) -> int:
    """Get the number of active variables of the passed GL type."""
    return gl_ctx.getProgramParameter(program_id, variable_type)


def _introspect_attributes(program_id: WebGLProgram) -> dict[str, Attribute]:
    """Introspect a Program's Attributes, and return a dict of accessors."""
    _gl = pyglet.graphics.api.core.current_context.gl
    attributes = {}

    if not _gl.getProgramParameter(program_id, gl.GL_LINK_STATUS):
        print("Shader program not linked!")
        return {}

    count = _get_number(_gl, program_id, gl.GL_ACTIVE_ATTRIBUTES)
    for index in range(count):
        idx_attribs = _gl.getActiveAttrib(program_id, index)
        if not idx_attribs:
            raise ShaderException(f"Attribute Index {index} not found in Program.")

        a_name, a_type, a_size = idx_attribs.name, idx_attribs.type, idx_attribs.size
        loc = _gl.getAttribLocation(program_id, a_name)
        if loc == -1:  # not a user defined attribute
            continue
        count, fmt = _attribute_types[a_type]
        attributes[a_name] = Attribute(a_name, loc, count, fmt)

    if _debug_api_shaders:
        for attribute in attributes.values():
            print(f" Found attribute: {attribute}")

    return attributes


def _create_program(gl: WebGLRenderingContext, *shaders: Shader) -> WebGLProgram:
    """Create a program and attach one or more Shader objects."""
    program_id = gl.createProgram()
    if not program_id:
        raise ShaderException("Shader program could not be created.")
    for shader in shaders:
        gl.attachShader(program_id, shader.handle)
    return program_id


def _link_program(gl: WebGLRenderingContext, program_id: WebGLProgram) -> None:
    """Link an existing program object and validate link status."""
    gl.linkProgram(program_id)

    # Check the link status of program
    status = gl.getProgramParameter(program_id, GL_LINK_STATUS)
    if not status:
        log = gl.getProgramInfoLog(program_id)
        msg = f"Error linking shader program:\n{log}"
        raise ShaderException(msg)


def _detach_program_shaders(gl: WebGLRenderingContext, program_id: WebGLProgram, *shaders: Shader) -> None:
    """Detach Shader objects from an already linked program."""
    for shader in shaders:
        gl.detachShader(program_id, shader.handle)


def _build_program(gl: WebGLRenderingContext, *shaders: Shader) -> WebGLProgram:
    """Create, link, and detach one or more Shaders into a ShaderProgram."""
    program_id = _create_program(gl, *shaders)
    _link_program(gl, program_id)
    _detach_program_shaders(gl, program_id, *shaders)
    return program_id


def _query_uniform(gl_ctx, program_id: WebGLProgram, index: int) -> tuple[str, int, int]:
    """Query the name, type, and size of a Uniform by index."""
    try:
        info = gl_ctx.getActiveUniform(program_id, index)
        return info.name, info.type, info.size

    except GLException as exc:
        raise ShaderException from exc


def _introspect_uniforms(gl_ctx: WebGLRenderingContext, program_id: WebGLProgram) -> dict[str, _Uniform]:
    """Introspect a Program's uniforms, and return a dict of accessors."""
    uniforms = {}

    for index in range(_get_number(gl_ctx, program_id, gl.GL_ACTIVE_UNIFORMS)):
        u_name, u_type, u_size = _query_uniform(gl_ctx, program_id, index)

        # Multidimensional arrays cannot be fully inspected via OpenGL calls and compile errors with 3.3.
        array_count = u_name.count("[0]")
        if array_count > 1 and u_name.count("[0][0]") != 0:
            msg = "Multidimensional arrays are not currently supported."
            raise ShaderException(msg)

        loc = gl_ctx.getUniformLocation(program_id, u_name)
        if not loc or loc == -1:  # Skip uniforms that may be inside a Uniform Block
            continue

        # Strip [0] from array name for a more user-friendly name.
        if array_count != 0:
            u_name = u_name.strip('[0]')

        assert u_name not in uniforms, f"{u_name} exists twice in the shader. Possible name clash with an array."
        uniforms[u_name] = _Uniform(program_id, u_name, u_type, u_size, loc)

    if _debug_api_shaders:
        for uniform in uniforms.values():
            print(f" Found uniform: {uniform}")

    return uniforms


def _introspect_uniform_blocks(
    ctx: OpenGLSurfaceContext, program: WebGLShaderProgram | WebGLComputeShaderProgram,
) -> dict[str, WebGLUniformBlock]:
    uniform_blocks = {}
    gl_ctx: WebGL2RenderingContext = ctx.gl
    program_id: WebGLProgram = program.handle

    for index in range(_get_number(gl_ctx, program_id, gl.GL_ACTIVE_UNIFORM_BLOCKS)):
        name = gl_ctx.getActiveUniformBlockName(program_id, index)
        if not name:
            msg = f"Unable to query UniformBlock name at index: {index}"
            raise ShaderException(msg)

        # num_active = gl.glGetActiveUniformBlockParameter(program_id, index, gl.GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS)
        block_data_size = gl_ctx.getActiveUniformBlockParameter(program_id, index, gl.GL_UNIFORM_BLOCK_DATA_SIZE)
        binding = gl_ctx.getActiveUniformBlockParameter(program_id, index, gl.GL_UNIFORM_BLOCK_BINDING)
        indices = gl_ctx.getActiveUniformBlockParameter(program_id, index, gl.GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES)

        uniforms: dict[int, tuple[str, GLDataType, int, int]] = {}

        if not hasattr(ctx, "ubo_manager"):
            ctx.ubo_manager = _UBOBindingManager()

        manager = ctx.ubo_manager

        for block_uniform_index in indices:
            uniform_name, u_type, u_size = _query_uniform(gl_ctx, program_id, block_uniform_index)

            # Remove block name.
            if uniform_name.startswith(f"{name}."):
                uniform_name = uniform_name[len(name) + 1 :]  # Strip 'block_name.' part

            if uniform_name.count("[0][0]") > 0:
                msg = "Multidimensional arrays are not currently supported."
                raise ShaderException(msg)

            gl_type, _, length = ctx._uniform_setters[u_type]
            uniforms[block_uniform_index] = (uniform_name, gl_type, length, u_size)

        binding_index = binding
        if pyglet.options.shader_bind_management:
            # If no binding is specified in GLSL, then assign it internally.
            if binding == 0:
                binding_index = manager.get_binding(program, name)

                # This might cause an error if index > GL_MAX_UNIFORM_BUFFER_BINDINGS, but surely no
                # one would be crazy enough to use more than 36 uniform blocks, right?
                gl_ctx.uniformBlockBinding(program_id, index, binding_index)
            else:
                # If a binding was manually set in GLSL, just check if the values collide to warn the user.
                _block_name = manager.get_name(binding)
                if _block_name and _block_name != name:
                    msg = (
                        f"{program} explicitly set '{name}' to {binding} in the shader. '{_block_name}' has "
                        f"been overridden."
                    )
                    warnings.warn(msg)
                manager.add_explicit_binding(program, name, binding)

        uniform_blocks[name] = WebGLUniformBlock(
            program, name, index, block_data_size, binding_index, uniforms, len(indices),
        )

        if _debug_api_shaders:
            for block in uniform_blocks.values():
                print(f" Found uniform block: {block}")

    return uniform_blocks


# Shader & program classes:


class GLShaderSource(ShaderSource):
    """GLSL source container for making source parsing simpler.

    We support locating out attributes and applying #defines values.

    .. note:: We do assume the source is neat enough to be parsed this way and doesn't contain several statements in
              one line.
    """

    _type: gl.GLenum
    _lines: list[str]

    def __init__(self, source: str, source_type: gl.GLenum | int) -> None:
        """Create a shader source wrapper."""
        self._lines = source.strip().splitlines()
        self._type = source_type

        if not self._lines:
            msg = "Shader source is empty"
            raise ShaderException(msg)

        self._version = self._find_glsl_version()

        self._lines[0] = "#version 300 es"
        self._lines.insert(1, "precision mediump float;")

        if self._type == gl.GL_GEOMETRY_SHADER:
            self._lines.insert(1, "#extension GL_EXT_geometry_shader : require")

        if self._type == gl.GL_COMPUTE_SHADER:
            self._lines.insert(1, "precision mediump image2D;")

        self._version = self._find_glsl_version()

    def validate(self) -> str:
        """Return the validated shader source."""
        return "\n".join(self._lines)

    def _find_glsl_version(self) -> int:
        if self._lines[0].strip().startswith("#version"):
            try:
                return int(self._lines[0].split()[1])
            except (ValueError, IndexError):
                pass

        source = "\n".join(f"{str(i + 1).zfill(3)}: {line} " for i, line in enumerate(self._lines))

        msg = (
            "Cannot find #version flag in shader source. "
            "A #version statement is required on the first line.\n"
            "------------------------------------\n"
            f"{source}"
        )
        raise ShaderException(msg)


class WebGLShader(_AbstractShader):
    """OpenGL shader.

    Shader objects are compiled on instantiation.
    You can reuse a Shader object in multiple ShaderPrograms.
    """

    _context: OpenGLSurfaceContext | NullContext
    _id: WebGLShader | None
    type: ShaderType

    def __init__(self, source_string: str, shader_type: ShaderType) -> None:
        """Initialize a shader type.

        Args:
            source_string:
                A string containing the source of your shader program.

            shader_type:
                A string containing the type of shader program:

                * ``'vertex'``
                * ``'fragment'``
                * ``'geometry'``
                * ``'compute'``
                * ``'tesscontrol'``
                * ``'tessevaluation'``
        """
        super().__init__(source_string, shader_type)
        self._context = pyglet.graphics.api.core.current_context
        self._gl = self._context.gl
        self._id = None
        self.type = shader_type

        shader_gl_type = _shader_types[shader_type]
        source_string = self.get_string_class()(source_string, shader_gl_type).validate()
        # shader_source_utf8 = source_string.encode("utf8")
        # source_buffer_pointer = cast(c_char_p(shader_source_utf8), POINTER(c_char))
        # source_length = c_int(len(shader_source_utf8))

        shader_id = self._gl.createShader(shader_gl_type)
        if not shader_id:
            raise ShaderException("Could not create shader.")
        self._id = shader_id
        self._handle = shader_id
        self._gl.shaderSource(shader_id, source_string)
        self._gl.compileShader(shader_id)

        status = self._gl.getShaderParameter(shader_id, gl.GL_COMPILE_STATUS)

        if status != GL_TRUE:
            source = source_string
            source_lines = "{0}".format(
                "\n".join(f"{str(i + 1).zfill(3)}: {line} " for i, line in enumerate(source.split("\n"))),
            )

            msg = (
                f"\n------------------------------------------------------------\n"
                f"{source_lines}"
                f"\n------------------------------------------------------------\n"
                f"Shader compilation failed. Please review the error on the specified line.\n"
                f"{self._get_shader_log(shader_id)}"
            )

            raise ShaderException(msg)

        if _debug_api_shaders:
            print(self._get_shader_log(shader_id))

    @staticmethod
    def get_string_class() -> type[GLShaderSource]:
        return GLShaderSource

    @classmethod
    def supported_shaders(cls) -> tuple[ShaderType, ...]:
        return 'vertex', 'fragment', 'compute', 'geometry', 'tesscontrol', 'tessevaluation'

    def _get_shader_log(self, shader_id: WebGLShader) -> str:
        info_log = self._gl.getShaderInfoLog(shader_id)
        if info_log:
            return f"OpenGL returned the following message when compiling the '{self.type}' shader: \n{info_log}"

        return f"{self.type.capitalize()} Shader '{shader_id}' compiled successfully."

    def delete(self) -> None:
        """Deletes the shader.

        This cannot be undone.
        """
        self._gl.deleteShader(self._id)
        self._id = None
        self._handle = None

    def __del__(self) -> None:
        if self._id is not None:
            try:
                if not isinstance(self._context, NullContext):
                    self._context.delete_shader(self._id)
                if _debug_api_shaders:
                    print(f"Destroyed {self.type} Shader '{self._id}'")
                self._id = None
                self._handle = None
            except (AttributeError, ImportError):
                pass  # Interpreter is shutting down

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(handle={self._handle}, type={self.type})"


class WebGLShaderProgram(ShaderProgram):
    """OpenGL shader program."""

    _id: WebGLProgram | None
    _context: OpenGLSurfaceContext | NullContext
    _uniforms: dict[str, _Uniform]
    _uniform_blocks: dict[str, WebGLUniformBlock]

    __slots__ = '_attributes', '_context', '_id', '_uniform_blocks', '_uniforms'

    def __init__(self, *shaders: WebGLShader, attribute_layout: AttributeLayout | None) -> None:
        """Initialize the ShaderProgram using at least two Shader instances."""
        super().__init__(*shaders, attribute_layout=attribute_layout)
        self._context = pyglet.graphics.api.core.current_context
        self._gl = self._context.gl
        self._id = _build_program(self._gl, *shaders)
        self._handle = self._id

        self._initialize_program_state()

    def _initialize_program_state(self) -> None:
        assert self._id is not None

        if _debug_api_shaders:
            """Query a ShaderProgram link logs."""
            result = self._gl.getProgramInfoLog(self._id)
            if result:
                print(f"OpenGL returned the following message when linking the program: \n{result}")
            else:
                js.console.log(f"Program '{self._id}' linked successfully.")

        # Query if Direct State Access is available:
        self.use()

        self._attributes = _introspect_attributes(self._id)
        self.apply_attribute_layout()
        self._update_attribute_key()
        self._uniforms = _introspect_uniforms(self._gl, self._id)
        self._uniform_blocks = self._get_uniform_blocks()
        self.stop()

    def _get_uniform_blocks(self) -> dict[str, WebGLUniformBlock]:
        """Return Uniform Block information."""
        return _introspect_uniform_blocks(self._context, self)

    def use(self) -> None:
        self._gl.useProgram(self._id)

    def stop(self) -> None:
        self._gl.useProgram(None)

    def delete(self) -> None:
        self._gl.deleteProgram(self._id)
        self._id = None
        self._handle = None

    def __del__(self) -> None:
        if self._id is not None:
            try:
                if not isinstance(self._context, NullContext):
                    self._context.delete_shader_program(self._id)
                self._id = None
                self._handle = None
            except (AttributeError, ImportError):
                pass  # Interpreter is shutting down



class WebGLTransformFeedbackShaderProgram(WebGLShaderProgram):
    """WebGL shader program configured for transform feedback capture."""

    __slots__ = "_varying_buffer_type", "_varyings"

    def __init__(self, *shaders: WebGLShader, varyings: Sequence[str],
                 varying_buffer_type: str = "separate", attribute_layout: AttributeLayout | None) -> None:
        ShaderProgram.__init__(self, *shaders, attribute_layout=attribute_layout)
        self._context = pyglet.graphics.api.core.current_context
        self._gl = self._context.gl

        self._varyings = tuple(varyings)
        self._varying_buffer_type = varying_buffer_type

        if not self._varyings:
            msg = "At least one transform feedback varying is required."
            raise ShaderException(msg)

        self._id = _create_program(self._gl, *shaders)
        self._handle = self._id
        self._set_transform_feedback_varyings()
        _link_program(self._gl, self._id)
        _detach_program_shaders(self._gl, self._id, *shaders)

        self._initialize_program_state()

    def _set_transform_feedback_varyings(self) -> None:
        mode = gl.GL_INTERLEAVED_ATTRIBS if self._varying_buffer_type == "interleaved" else gl.GL_SEPARATE_ATTRIBS
        self._gl.transformFeedbackVaryings(self._id, list(self._varyings), mode)


class WebGLComputeShaderProgram(_AbstractShaderProgram):
    """OpenGL Compute Shader Program."""

    def __init__(self, source: str) -> None:
        """Create an OpenGL ComputeShaderProgram from source."""
        super().__init__()
        raise UnsupportedBackendError("Compute Shaders are not supported in WebGL.")


_default_vertex_source: str = """#version 330 core
    in vec3 position;
    in vec4 colors;

    out vec4 vertex_colors;

    uniform WindowBlock
    {
        mat4 projection;
        mat4 view;
    } window;

    void main()
    {
        gl_Position = window.projection * window.view * vec4(position, 1.0);

        vertex_colors = colors;
    }
"""

_default_fragment_source: str = """#version 330 core
    in vec4 vertex_colors;
    out vec4 final_colors;

    void main()
    {
        final_colors = vertex_colors;
    }
"""


def get_default_shader() -> WebGLShaderProgram:
    """A default basic shader for default batches."""
    program = pyglet.graphics.api.get_cached_shader(
        "default_graphics",
        (_default_vertex_source, 'vertex'),
        (_default_fragment_source, 'fragment'),
        attribute_layout=None,
    )
    return program
