# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

from pyglet.window import key as winkey

from core import timing, validation
from core.constants import BFLIM, HEADLESS_MODE, PLUGIN_TITLE_HEIGHT_PROPORTION, REPLAY_MODE
from core.constants import COLORS as C
from core.constants import FONT_SIZES as F
from core.container import Container
from core.logger import get_logger
from core.widgets import Frame, SimpleHTML, Simpletext
from core.window import Window

# Plugin steps later than this (seconds) are skipped instead of caught up (see compute_next_plugin_state)
MAX_STEP_CATCH_UP: float = 0.25
# Safety limit of the steps run by one update (see update)
MAX_STEPS_PER_UPDATE: int = 50


class AbstractPlugin:
    """Any plugin (or task) depends on this meta-class"""

    def __init__(self, label: str | None = "", taskplacement: str = "fullscreen", taskupdatetime: int = -1) -> None:
        self.label: str | None = label  #   The name as displayed on the interface
        self.alias: str = self.__class__.__name__.lower()  #   A lower version of the plugin class name
        self.widgets: dict[str, Any] = dict()  #   To store the widget objects of a plugin
        self.container: Container | None = None  #   The visual area of the plugin (object)
        self.logger: Any = get_logger()

        self.can_receive_keys: bool = False
        self.can_execute_keys: bool = False
        self.can_receive_mouse: bool = False
        self.keys: set[str] = set()  #   Handle the keys that are allowed
        self.display_title: bool = taskplacement != "invisible"
        self.automode_string: str = ""
        self.agent: Any = None

        self.next_refresh_time: float = 0
        self.scenario_time: float = 0

        #  If True
        self.blocking: bool = False  # :blocks all other plugins when alive
        self.alive: bool = False  # :is started and not yet stopped
        self.paused: bool = True  # :is not updated and cannot receive inputs
        self.visible: bool = False  # :all the plugins widgets are shown
        self.verbose: bool = False

        self.parameters: dict[str, Any] = dict(
            title=self.label,
            taskplacement=taskplacement,
            taskupdatetime=taskupdatetime,
            taskfeedback=dict(overdue=dict(active=False, color=C["RED"], delayms=2000, blinkdurationms=1000)),
        )

        # Private parameters
        self.parameters["taskfeedback"]["overdue"].update({"_nexttoggletime": 0, "_is_visible": False})

        # Define minimal draw order depending on task placement
        self.m_draw: int = BFLIM if self.parameters["taskplacement"] == "fullscreen" else 0

    def on_scenario_loaded(self, scenario: Any) -> None:
        pass

    def update(self, scenario_time: float) -> None:
        self.scenario_time = scenario_time
        self.compute_next_plugin_state()
        # Run every step due since the last update: several when updates are slower than taskupdatetime
        # (e.g. 20 ms tracking steps with ~30 ms browser timers). taskupdatetime <= 0: one step per update.
        if self.parameters["taskupdatetime"] > 0:
            for _ in range(MAX_STEPS_PER_UPDATE - 1):
                if self.scenario_time < self.next_refresh_time or self.is_paused():
                    break
                self.compute_next_plugin_state()
        self.refresh_widgets()
        self.update_can_receive_key()

    # State handling
    def show(self) -> None:
        """
        Showing means display widgets, but also removing a potential masking foreground.
        """
        if self.is_visible():
            return

        if self.verbose:
            print("Show ", self.alias)

        self.visible = True
        self.update_can_receive_key()

        if self.parameters["taskplacement"] == "fullscreen":
            for _name, widget in self.widgets.items():
                widget.show()
            Window.MainWindow.set_bg_bands_visible(False)

        elif self.parameters["taskplacement"] != "invisible":
            for _name, widget in self.widgets.items():
                widget.show()

            if self.get_widget("foreground") is not None:
                self.get_widget("foreground").hide()

            if self.get_widget("overdue") is not None:
                self.get_widget("overdue").set_visibility(False)

            if self.get_widget("attention") is not None:
                self.get_widget("attention").set_visibility(False)

            if self.get_widget("fault_icon") is not None:
                self.get_widget("fault_icon").set_text("")

    def hide(self) -> None:
        """
        Hiding means showing a neutral foreground before the plugin for non-blocking plugins
        and destroying the title.
        It can mean, also, hiding (destroy) widgets for a fullscreen (blocking) plugin
        """
        if not self.is_visible():
            return

        if self.verbose:
            print("Hide ", self.alias)

        self.visible = False
        self.update_can_receive_key()

        if self.parameters["taskplacement"] == "fullscreen":
            for _name, widget in self.widgets.items():
                widget.hide()
            Window.MainWindow.set_bg_bands_visible(True)

        elif self.parameters["taskplacement"] != "invisible":
            self.get_widget("task_title").hide()

            # Resman case (manage status if relevant)
            if self.get_widget("status_title") is not None:
                self.get_widget("status_title").hide()

            if self.get_widget("foreground") is not None:
                self.get_widget("foreground").show()

    def pause(self) -> None:
        if self.verbose:
            print("Pause ", self.alias)
        self.paused = True
        self.update_can_receive_key()

    def resume(self) -> None:
        if self.verbose:
            print("Resume ", self.alias)
        self.paused = False
        self.update_can_receive_key()

    def start(self) -> None:
        if self.verbose:
            print("Start ", self.alias)
            print("with keys ", self.keys)
        self.alive = True
        self.create_widgets()
        self.log_all_parameters(self.parameters)
        self.show()
        self.resume()

    def stop(self) -> None:
        if self.verbose:
            print("Stop ", self.alias)
        self.alive = False
        self.pause()
        self.hide()

    def is_a_widget_name(self, name: str) -> bool:
        return self.get_widget_fullname(name) in self.widgets

    def is_visible(self) -> bool:
        return self.visible is True

    def is_paused(self) -> bool:
        return self.paused is True

    def get_widget_fullname(self, name: str) -> str:
        return f"{self.alias}_{name}"

    def get_widget(self, name: str) -> Any | None:
        if not self.is_a_widget_name(name):
            return
        return self.widgets[self.get_widget_fullname(name)]

    def get_response_timers(self) -> list[float] | None:
        """Return the time since which responses are expected (list of int)"""
        pass

    def has_active_fault(self) -> bool:
        """Return True if this plugin has an unresolved problem requiring action."""
        return False

    def update_can_receive_key(self) -> None:
        """Update the ability of the plugin to receive either material or emulated inputs"""

        if self.paused or not self.is_visible():
            self.can_receive_keys = False
        else:
            if "automaticsolver" in self.parameters:
                self.can_receive_keys = not self.parameters["automaticsolver"]
            else:
                self.can_receive_keys = True

        if REPLAY_MODE:
            # Replay always blocks human input but allows emulated keys
            self.can_receive_keys = False
            self.can_execute_keys = True
        elif self.parameters.get("automaticsolver", False):
            # Agent is active — allow emulated keys always
            self.can_execute_keys = True
            # Allow human input if agent explicitly permits it
            agent = getattr(self, "agent", None)
            if agent is not None and agent.allows_human_input:
                self.can_receive_keys = not self.paused and self.is_visible()
            else:
                self.can_receive_keys = False
        else:
            self.can_execute_keys = self.can_receive_keys

        self.update_can_receive_mouse()

    def update_can_receive_mouse(self) -> None:
        """Update the ability of the plugin to receive mouse inputs"""
        if self.paused or not self.is_visible() or REPLAY_MODE or self.parameters.get("automaticsolver", False):
            self.can_receive_mouse = False
        else:
            self.can_receive_mouse = True

    def compute_next_plugin_state(self) -> bool:
        if not self.scenario_time >= self.next_refresh_time or self.is_paused():
            return False

        if self.verbose:
            print(self.alias, "Compute next state")

        # Plugins count taskupdatetime per step (response times, failure timers, flows...): schedule the next
        # step from the previous deadline, not from now, so that the lateness of the update (up to one
        # clock tick, ~10 ms in the browser) does not accumulate and slow the task down. Missed steps are
        # caught up (by update()); when too late (start, resume, long stall), restart from now instead.
        period: float = self.parameters["taskupdatetime"] / 1000
        if self.next_refresh_time == 0:  # First step: the deadlines start now, not at the scenario start
            self.next_refresh_time = self.scenario_time
        self.next_refresh_time += period
        if self.next_refresh_time < self.scenario_time - MAX_STEP_CATCH_UP:
            self.next_refresh_time = self.scenario_time + period

        # Let the agent act on this plugin if automaticsolver is enabled
        # (not in replay: its inputs are replayed from the session file)
        if self.agent is not None and self.parameters.get("automaticsolver") and not REPLAY_MODE:
            self.agent.on_plugin_update(self, self.scenario_time)

        # Should an automation state (string) be displayed ?
        if self.parameters.get("displayautomationstate"):
            if "automaticsolver" in self.parameters:
                if self.parameters["automaticsolver"] and self.agent is not None:
                    self.automode_string = _(self.agent.get_automode_string())
                else:
                    self.automode_string = _("MANUAL")
            else:
                self.automode_string = _("MANUAL")
        else:
            self.automode_string = ""
        return True

    def refresh_widgets(self) -> bool:
        if not self.is_visible():
            return False

        if self.verbose:
            print(self.alias, "Refreshing widgets")

        if self.get_widget("foreground") is not None:
            self.get_widget("foreground").set_visibility(False)

        # Refresh some visual information if need be
        if self.get_widget("automode") is not None:
            self.get_widget("automode").set_text(self.automode_string)

        if self.display_title:
            self.get_widget("task_title").set_text(self.parameters["title"].upper())

        # Update the overdue feedback state if relevant
        # Overdue state computing is here to unmerge its temporal
        # logic from the taskupdatetime parameter (so the alarm
        # does not have to wait for plugin update to blink)
        overdue: dict[str, Any] = self.parameters["taskfeedback"]["overdue"]
        if overdue["active"] and self.get_response_timers() is not None:
            # Should an alarm be displayed ?
            if any([rt > overdue["delayms"] for rt in self.get_response_timers()]):
                if overdue["blinkdurationms"] == 0:  # No blink case
                    # overdue['widget'].set_visibility(True)
                    overdue["_is_visible"] = True
                else:  # Blink case
                    if overdue["_nexttoggletime"] == 0:  # First toggle
                        overdue["_nexttoggletime"] = self.scenario_time

                    if self.scenario_time >= overdue["_nexttoggletime"]:
                        overdue["_nexttoggletime"] += overdue["blinkdurationms"] / 1000
                        overdue["_is_visible"] = not overdue["_is_visible"]
            else:
                overdue["_nexttoggletime"] = 0  # The next alarm blinks from its own start
                overdue["_is_visible"] = False
        else:
            overdue["_is_visible"] = False

        if "widget" in overdue:
            overdue["widget"].set_visibility(overdue["_is_visible"])
            overdue["widget"].set_border_color(overdue["color"])

        if self.get_widget("attention") is not None:
            show = (
                self.agent is not None
                and getattr(self.agent, "show_attention", False)
                and getattr(self.agent, "_attended_task", None) == self.alias
            )
            self.get_widget("attention").set_visibility(show)

        fault_w = self.get_widget("fault_icon")
        if fault_w is not None:
            show_fault = (
                self.agent is not None and getattr(self.agent, "show_attention", False) and self.has_active_fault()
            )
            fault_w.set_text("!" if show_fault else "")

        return True

    def filter_key(self, keystr: str) -> str | None:
        if not self.can_execute_keys:
            return

        if Window.MainWindow.modal_dialog is None:
            keystr = keystr if keystr in self.keys else None
            return keystr

        return

    def on_joy_key_press(self, keystr: str) -> None:
        if not self.can_receive_keys:
            return
        self.do_on_key(keystr, "press", False)

    def on_joy_key_release(self, keystr: str) -> None:
        if not self.can_receive_keys:
            return
        self.do_on_key(keystr, "release", False)

    def on_key_press(self, symbol: int, modifiers: int) -> None:
        if not self.can_receive_keys:
            return
        keystr: str = winkey.symbol_string(symbol)
        self.do_on_key(keystr, "press", False)

    def on_key_release(self, symbol: int, modifiers: int) -> None:
        if not self.can_receive_keys:
            return
        keystr: str = winkey.symbol_string(symbol)
        self.do_on_key(keystr, "release", False)

    def on_mouse_press(self, x: int, y: int, button: int, modifiers: int) -> None:
        if not self.can_receive_mouse:
            return
        if Window.MainWindow.modal_dialog is not None:
            return
        self.do_on_mouse_press(x, y, button)

    def on_mouse_release(self, x: int, y: int, button: int, modifiers: int) -> None:
        if not self.can_receive_mouse:
            return
        if Window.MainWindow.modal_dialog is not None:
            return
        self.do_on_mouse_release(x, y, button)

    def on_mouse_drag(self, x: int, y: int, dx: int, dy: int, buttons: int, modifiers: int) -> None:
        if not self.can_receive_mouse:
            return
        if Window.MainWindow.modal_dialog is not None:
            return
        self.do_on_mouse_drag(x, y, dx, dy, buttons)

    def do_on_mouse_press(self, x: int, y: int, button: int) -> None:
        pass

    def do_on_mouse_release(self, x: int, y: int, button: int) -> None:
        pass

    def do_on_mouse_drag(self, x: int, y: int, dx: int, dy: int, buttons: int) -> None:
        pass

    def do_on_key(
        self, keystr: str, state: str, emulate: bool = False
    ) -> str | None:  # JC: pour le solver, devrait prendre un parametre is_solver_action
        # pour separer de vraies actions du participant
        if REPLAY_MODE and not emulate:
            return  # During replay, ignore keys that are not emulated
        return self.filter_key(keystr)

    def is_key_state(self, keystr: str, is_pressed: bool) -> bool | None:
        if keystr in Window.MainWindow.keyboard:
            return Window.MainWindow.keyboard[keystr] == is_pressed
        elif self.joystick is not None and keystr in self.joystick.keys:
            return self.joystick.keys[keystr] == is_pressed
        else:
            return

    def create_widgets(self) -> None:
        if self.verbose:
            print(self.alias, "Creating widgets")
        pthp: float = PLUGIN_TITLE_HEIGHT_PROPORTION

        self.container = Window.MainWindow.get_container(self.parameters["taskplacement"])
        self.title_container: Container = self.container.reduce_and_translate(height=pthp, y=1)
        self.task_container: Container = self.container.reduce_and_translate(height=1 - pthp, y=0)

        # A fullscreen plugin must have its proper background to override the MATB black middle band
        if self.parameters["taskplacement"] == "fullscreen":
            self.add_widget("background", Frame, self.container, fill_color=C["BACKGROUND"], draw_order=self.m_draw)

        # Other plugins which are not invisible must have a foreground so they can hide
        # Also : add overdue feedback widget to visible plugins
        elif self.parameters["taskplacement"] != "invisible":
            self.add_widget(
                "foreground", Frame, self.task_container, fill_color=C["BACKGROUND"], draw_order=self.m_draw + 10
            )
            self.parameters["taskfeedback"]["overdue"]["widget"] = self.add_widget(
                "overdue",
                Frame,
                container=self.task_container,
                border_thickness=0.025,
                border_color=C["RED"],
                fill_color=None,
            )
            self.add_widget(
                "attention",
                Frame,
                container=self.task_container,
                border_thickness=0.02,
                border_color=C["CYAN"],
                fill_color=None,
                draw_order=3,
            )

            # Fault indicator — bold red "!" at bottom-right of task area
            fault_cont = self.task_container.reduce_and_translate(width=0.12, height=0.12, x=1, y=0)
            self.add_widget(
                "fault_icon",
                Simpletext,
                container=fault_cont,
                text="!",
                font_size=F["XLARGE"],
                color=C["RED"],
                bold=True,
                draw_order=self.m_draw + 4,
            )

        if self.display_title:
            self.add_widget(
                "task_title",
                Simpletext,
                container=self.title_container,
                text=self.parameters["title"].upper(),
                color=C["WHITE"],
                font_size=F["MEDIUM"],
            )

        if "displayautomationstate" in self.parameters:
            if self.parameters["displayautomationstate"] is True:
                position: tuple[float, float] = (
                    self.automode_position if hasattr(self, "automode_position") else (0.5, 0.5)
                )
                autocont: Container = self.container.reduce_and_translate(
                    width=0.15, height=0.05, x=position[0], y=position[1]
                )
                self.add_widget("automode", Simpletext, container=autocont, text=self.automode_string, x=0.5, y=0.5)

    def add_widget(self, name: str, cls: type, container: Container | None, **kwargs: Any) -> Any:
        fullname: str = self.get_widget_fullname(name)
        self.widgets[fullname] = cls(fullname, container, **kwargs)

        # Record the area coordinates of the widget if it has a container
        if container is not None:
            self.logger.record_aoi(container, fullname)

        return self.widgets[fullname]

    def set_parameter(self, keys_str: str, value: Any) -> dict[str, Any]:
        keys_list: list[str] = keys_str.split("-")
        dic: dict[str, Any] = self.parameters
        for key in keys_list[:-1]:
            dic = dic.setdefault(key, {})
        old_value: Any = dic[keys_list[-1]]
        dic[keys_list[-1]] = value

        # If a key is changed, renew the self.keys list
        if "key" in keys_str:
            self.keys.add(value)
            if old_value in self.keys and old_value != value:
                self.keys.remove(old_value)
        return dic

    def log_all_parameters(self, search_dict: dict[str, Any], key_prefix: str = "") -> None:
        for key, value in search_dict.items():
            new_key_prefix: str = str(key) if len(key_prefix) == 0 else key_prefix + "-" + str(key)
            if isinstance(value, dict):  # Recursion search
                self.log_all_parameters(value, new_key_prefix)
            else:  # Value found
                get_logger().record_parameter(self.alias, new_key_prefix, value)

    def log_performance(self, name: str, value: Any) -> None:
        if not hasattr(self, "performance"):
            self.performance: dict[str, list[Any]] = dict()
        if name not in self.performance:
            self.performance[name] = list()
        self.performance[name].append(value)
        self.logger.log_performance(self.alias, name, value)

    @staticmethod
    def _filter_by(collection: Any, key: str, value: Any) -> list[dict[str, Any]]:
        """Filter a list or dict-of-dicts, returning items where item[key] == value."""
        items = collection.values() if isinstance(collection, dict) else collection
        return [item for item in items if item[key] == value]

    @staticmethod
    def _filter_keys_by(collection: dict[Any, dict[str, Any]], key: str, value: Any) -> list[Any]:
        """Return dict keys where item[key] == value."""
        return [k for k, item in collection.items() if item[key] == value]

    @staticmethod
    def _indexed_validators(prefix: str, indices: Any, validators: dict[str, Any]) -> dict[str, Any]:
        """Generate validation entries for indexed parameters.

        >>> _indexed_validators("pump", range(1, 3), {"flow": v.is_positive_integer})
        {"pump-1-flow": v.is_positive_integer, "pump-2-flow": v.is_positive_integer}
        """
        return {f"{prefix}-{i}-{k}": v for i in indices for k, v in validators.items()}

    def _response_elapsed_ms(self, start: float | None) -> float:
        """Return elapsed milliseconds since *start* (a scenario_time), or 0.0 if None."""
        if start is None:
            return 0.0
        return (self.scenario_time - start) * 1000

    def start_response_timer(self, item: dict[str, Any], on_flip: bool = True) -> None:
        """Start the response timer of item (a gauge, a radio...): item["_response_start"] is the scenario time
        (for the timeouts), item["_onset"] the scenario time of the first frame displaying the stimulus."""
        item["_response_start"] = self.scenario_time
        item["_onset"] = None
        if not on_flip:
            return

        def set_onset(real_time: float) -> None:
            if item["_response_start"] is not None and item["_onset"] is None:
                item["_onset"] = timing.scenario_time_at(real_time)

        timing.call_on_flip(set_onset)

    def response_time_ms(self, item: dict[str, Any], human: bool) -> float:
        """Response time (ms) to item. For a human input: from the stimulus onset (or its start) to the input
        event (see core/timing.py). Otherwise (agent, automatic solver, replay): in scenario time."""
        start: float | None = item["_response_start"]
        response: float | None = timing.scenario_time_at(timing.input_time()) if human else None
        if start is None or response is None:
            return self._response_elapsed_ms(start)
        onset: float | None = item.get("_onset")
        return (response - (onset if onset is not None else start)) * 1000

    def keep_value_between(self, value: float, down: float, up: float) -> float:
        return max(min(value, up), down)

    def grouped(self, iterable: Any, n: int) -> Iterator[tuple[Any, ...]]:
        return zip(*[iter(iterable)] * n)


class BlockingPlugin(AbstractPlugin):
    def __init__(self, taskplacement: str = "fullscreen", taskupdatetime: int = 15) -> None:
        super().__init__(None, taskplacement, taskupdatetime)

        self.keys.update({"SPACE"})
        new_par: dict[str, bool] = dict(boldtitle=False)
        self.parameters.update(new_par)

        self.validation_dict: dict[str, Any] = {
            "boldtitle": validation.is_boolean,
            "filename": validation.is_available_text_file,
            "pointsize": validation.is_natural_integer,
            "maxdurationsec": validation.is_natural_integer,
            "response-text": validation.is_string,
            "response-key": validation.is_keyboard_key,
            "allowkeypress": validation.is_boolean,
        }

        self.blocking: bool = True
        self.display_title: bool = False

        self.slides: list[str] = list()
        self.current_slide: str | None = None
        self.go_to_next_slide: bool | None = None
        self.ignore_empty_lines: bool = False

        self.input_path: Path | None = None
        self.folder: str | None = None  # Depends on the nature of blocking plugin (questionnaire, instruction...)

        # Should we stop the plugin when the are no more slide available
        # (Useful for the LSL plugin, which has a starting instruction, but
        #  should not be stopped)
        self.stop_on_end: bool = True
        # The slides come from a file (filename command required before start). Not for the LSL plugin,
        # whose only slide (pauseatstart) is written by the plugin itself
        self.needs_input_file: bool = True

    def create_widgets(self) -> None:
        super().create_widgets()
        self.go_to_next_slide = True  # So the first slide appears as soon as possible

        # Create an input path if relevant

        if self.parameters["filename"] is not None:
            self.input_path = Path(".", self.folder, self.parameters["filename"])

        # Only if this input path exists, retrieve its content into slides (split with <newpage>)
        if self.input_path is not None and self.input_path.exists():
            self.slides.append("")  # Create the first slide
            # utf-8-sig: a file saved "UTF-8 with BOM" (e.g. by Windows Notepad) must not show the BOM
            lines: list[str] = self.input_path.open(encoding="utf-8-sig").readlines()

            if self.ignore_empty_lines:
                lines = [l for l in lines if len(l.strip()) > 0]

            for line in lines:
                if "#" not in line:
                    if "<newpage>" in line:
                        self.slides.append("")  # New slide
                    else:
                        self.slides[-1] += line
        else:
            pass  # This should not happen (input_path is checked before the scenario is played)

    def update(self, dt: float) -> None:
        super().update(dt)

        # In headless mode, auto-advance through all slides without waiting
        if HEADLESS_MODE:
            self.go_to_next_slide = True

        if self.go_to_next_slide:
            self.go_to_next_slide = False
            if len(self.slides) > 0:  # Are there remaining slides ?
                self.hide()  # If so retrieve the next slide and show it
                self.current_slide = self.slides[0]
                del self.slides[0]
                self.make_slide_graphs()
                self.show()
            else:
                if self.stop_on_end:
                    self.stop()
                else:
                    self.hide()
                    self.blocking = False

    def make_slide_graphs(self) -> None:
        # Extract the title from the slide string if relevant
        slide_content: list[str] = self.current_slide.split("\n")
        title_idx: list[int] = [i for i, t in enumerate(slide_content) if "<h1>" in t]
        if len(title_idx) > 0:
            # In case multiple title tags, take the last one
            title: str = slide_content[title_idx[-1]]

            self.add_widget(
                "title",
                SimpleHTML,
                container=self.container,
                text=title,
                wrap_width=1,
                y=0.9,
                draw_order=self.m_draw + 1,
            )
            del slide_content[title_idx[-1]]

        # Remove a potential previous title
        elif self.is_a_widget_name("title"):
            del self.widgets[self.get_widget_fullname("title")]

        # Renew the current slide content
        self.current_slide = "\n".join(slide_content)

        if self.parameters["allowkeypress"]:
            key_name: str = self.parameters["response"]["key"].lower()
            response_text: str = "<center><p>" + self.parameters["response"]["text"] + "</p></center>"
            self.add_widget(
                f"press_{key_name}",
                SimpleHTML,
                container=self.container,
                draw_order=self.m_draw + 1,
                text=response_text,
                wrap_width=0.5,
                x=0.5,
                y=0.1,
            )

    def on_key_press(self, symbol: int, modifiers: int) -> None:
        if self.parameters["allowkeypress"]:
            super().on_key_press(symbol, modifiers)

    def on_key_release(self, symbol: int, modifiers: int) -> None:
        # Slides advance on the SPACE release: filter it too
        if self.parameters["allowkeypress"]:
            super().on_key_release(symbol, modifiers)

    def do_on_key(self, keystr: str, state: str, emulate: bool = False) -> str | None:
        keystr = super().do_on_key(keystr, state, emulate)
        if keystr is None:
            return

        # Waiting for the key release to advance one slide at the time
        if keystr.lower() == "space" and state == "release":
            self.go_to_next_slide = True

        return keystr


# TODO : Include a Solver class like
# ~ """
# ~ class Solver():
# ~ def __init__(name: str, block_input: bool, solvermode_string=_('AUTO')):
# ~ self.name = name
# ~ self.block_input = block_input
# ~ self.solvermode_string = display

# ~ def get_solvermode_string():
# ~ return self.solvermode_string

# ~ def on_plugin_update(plugin, *param):
# ~ if plugin is RESMAN:
# ~ ...
# ~ plugin.do_on_key(...)

# ~ def on_plugin_failure(plugin, *param):
# ~ if plugin is SYSMON or plugin is communications:
# ~ ...
# ~ plugin.do_on_key(...)

# ~ """
