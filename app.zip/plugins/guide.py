# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): a guide box that explains a task while the real task screen stays visible.

"""Guide: instruction slides shown in a box over part of the screen, the tasks staying visible (paused).

Like Instructions (same slide files, SPACE to continue), but the slides are not fullscreen:
- area: where the box goes, "right" (right 62 % of the screen), "top", "bottom" (half of the screen)
  or "center" (a centered box)
- highlight: a task location to frame (topleft, topmid, bottomleft, bottommid, topright, bottomright) or "none"
"""

from __future__ import annotations

from typing import Any

from core import validation
from core.constants import COLORS as C
from core.container import Container
from core.widgets import Frame
from core.window import Window
from plugins.instructions import Instructions

AREAS: list[str] = ["right", "top", "bottom", "center"]
HIGHLIGHTS: list[str] = ["none", "topleft", "topmid", "topright", "bottomleft", "bottommid", "bottomright"]
HIGHLIGHT_COLOR: tuple[int, int, int, int] = (230, 120, 0, 255)


class Guide(Instructions):
    def __init__(self) -> None:
        super().__init__()
        self.parameters.update(dict(area="right", highlight="none"))
        self.keep_tasks_visible: bool = True  # Read by the scheduler
        self.validation_dict.update(
            {
                "area": (validation.is_in_list, AREAS),
                "highlight": (validation.is_in_list, HIGHLIGHTS),
            }
        )

    def guide_container(self) -> Container:
        w: float = Window.MainWindow.width
        h: float = Window.MainWindow.height
        area: str = self.parameters["area"]
        m: float = 0.015 * min(w, h)  # Margin
        if area == "right":
            return Container("guide", 0.37 * w + m, m, 0.63 * w - 2 * m, h - 2 * m)
        if area == "top":
            return Container("guide", m, h / 2 + m, w - 2 * m, h / 2 - 2 * m)
        if area == "bottom":
            return Container("guide", m, m, w - 2 * m, h / 2 - 2 * m)
        return Container("guide", 0.15 * w, 0.12 * h, 0.7 * w, 0.76 * h)

    def create_widgets(self) -> None:
        super().create_widgets()
        # No fullscreen background: the tasks stay visible around the box
        background: str = self.get_widget_fullname("background")
        if background in self.widgets:
            self.widgets[background].hide()
            del self.widgets[background]

        # The plugin is reused from one guide to the next: drop the frame of a previous guide
        previous: str = self.get_widget_fullname("highlight")
        if previous in self.widgets:
            self.widgets[previous].hide()
            del self.widgets[previous]

        if self.parameters["highlight"] != "none":
            target: Container | None = Window.MainWindow.get_container(self.parameters["highlight"])
            if target is not None:
                self.add_widget(
                    "highlight",
                    Frame,
                    container=target,
                    fill_color=None,
                    border_color=HIGHLIGHT_COLOR,
                    border_thickness=0.03,
                    draw_order=self.m_draw,
                )

        self.container = self.guide_container()
        self.add_widget(
            "box",
            Frame,
            container=self.container,
            fill_color=(255, 255, 255, 245),
            border_color=HIGHLIGHT_COLOR,
            border_thickness=0.008,
            draw_order=self.m_draw,
        )

    def make_slide_graphs(self) -> None:
        super().make_slide_graphs()
        # The slide widgets are recreated at each slide: keep the box and the highlight below them
        for name in ("box", "highlight"):
            widget: Any = self.get_widget(name)
            if widget is not None:
                widget.show()

    # Not fullscreen: don't hide the black bands of the task titles
    def show(self) -> None:
        if self.is_visible():
            return
        self.visible = True
        self.update_can_receive_key()
        for _name, widget in self.widgets.items():
            widget.show()

    def hide(self) -> None:
        if not self.is_visible():
            return
        self.visible = False
        self.update_can_receive_key()
        for _name, widget in self.widgets.items():
            widget.hide()
