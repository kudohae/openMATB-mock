# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

from collections.abc import Generator
from math import isnan, pi, sin
from typing import Any, Callable

from pyglet.window import mouse as winmouse

from core import validation
from core.constants import COLORS as C
from core.constants import REPLAY_MODE
from core.container import Container
from core.utils import clamp
from core.widgets import Reticle
from plugins.abstractplugin import AbstractPlugin


class Track(AbstractPlugin):
    def __init__(
        self, label: str = "", taskplacement: str = "topmid", taskupdatetime: int = 20, silent: bool = False
    ) -> None:
        super().__init__(_("Tracking"), taskplacement, taskupdatetime)

        self.validation_dict: dict[str, Callable[..., Any]] = {
            "automaticsolver": validation.is_boolean,
            "displayautomationstate": validation.is_boolean,
            "taskfeedback-overdue-active": validation.is_boolean,
            "taskfeedback-overdue-color": validation.is_color,
            "taskfeedback-overdue-delayms": validation.is_natural_integer,
            "taskfeedback-overdue-blinkdurationms": validation.is_natural_integer,
            "cursorcolor": validation.is_color,
            "cursorcoloroutside": validation.is_color,
            "targetproportion": validation.is_in_unit_interval,
            "joystickforce": validation.is_natural_integer,
            "inverseaxis": validation.is_boolean,
        }

        new_par: dict[str, Any] = dict(
            cursorcolor=C["BLACK"],
            cursorcoloroutside=C["RED"],
            automaticsolver=False,
            displayautomationstate=True,
            targetproportion=0.25,
            joystickforce=1,
            inverseaxis=False,
        )
        self.parameters.update(new_par)

        self.automode_position: tuple[float, float] = (0.35, 0.1)
        self.cursor_path_gen: Generator[tuple[float, float], None, None] = iter(self.compute_next_cursor_position())
        self.cursor_position: tuple[float, float] | None = None
        self.cursor_color_key: str = "cursorcolor"
        self.gain_ratio: float = 0.8  # The proportion of the reticle area the cursor should cover
        self._response_start: float | None = None
        self.x_input: float = 0
        self.y_input: float = 0
        self._mouse_dragging: bool = False
        self._drag_origin_x: int = 0
        self._drag_origin_y: int = 0

    def get_response_timers(self) -> list[float]:
        return [self._response_elapsed_ms(self._response_start)]

    def has_active_fault(self) -> bool:
        return self._response_start is not None

    def create_widgets(self) -> None:
        super().create_widgets()

        # Compute the reticle widget coordinates (left, bottom, width, height)
        b: float = self.task_container.b + self.task_container.h * 0.1
        h: float = self.task_container.h * 0.8
        w: float = h
        l: float = self.task_container.l + self.task_container.w / 2 - w / 2

        self.add_widget(
            "reticle",
            Reticle,
            container=Container("reticle", l, b, w, h),
            target_proportion=self.parameters["targetproportion"],
            cursorcolor=self.parameters["cursorcolor"],
        )
        self.reticle: Any = self.widgets["track_reticle"]

        # Compute cursor movement constraints as soon as the reticle is created
        self.reticle_container: Container = self.reticle.container
        self.xgain: float = (self.reticle_container.w * self.gain_ratio) / 2
        self.ygain: float = (self.reticle_container.h * self.gain_ratio) / 2
        self.cursor_position = next(self.cursor_path_gen)

    def get_joystick_inputs(self, x: float, y: float) -> None:
        # Called by the scheduler (which distribute joystick inputs to plugins) at each update
        # Skip joystick overwrite while mouse is actively dragging
        if self._mouse_dragging:
            return
        self.x_input = x
        self.y_input = y

    def compute_next_plugin_state(self) -> None:
        # Reset agent joystick inputs so stale values don't persist across frames.
        # Real joystick: scheduler refreshes x_input/y_input every frame via
        # update_joystick() before this method is called — no reset needed.
        # Agent: only writes when attending track; reset prevents stale force.
        # Skip reset when agent allows human input (cooperative/assisted modes).
        if self.parameters["automaticsolver"]:
            if self.agent is None or not self.agent.allows_human_input:
                self.x_input = 0
                self.y_input = 0

        if not super().compute_next_plugin_state():
            return

        # In case of replay, do not compute cursor position.
        # : the ReplayScheduler will master it.
        if not REPLAY_MODE:
            self.cursor_position = next(self.cursor_path_gen)

        # NaN when no target is defined: logged as such, but treated as in target
        # (normal cursor color, no response needed)
        in_target: bool | float = self.reticle.is_cursor_in_target()
        on_target: bool = isnan(in_target) or bool(in_target)
        self.cursor_color_key = "cursorcolor" if on_target else "cursorcoloroutside"
        self.log_performance("cursor_in_target", in_target)
        self.log_performance("center_deviation", self.reticle.return_deviation())

        if not on_target:  # A response is needed
            if self._response_start is None:
                self._response_start = self.scenario_time
        else:
            if self._response_start is not None:  # The cursor drift has been recovered
                self.log_performance("response_time", self._response_elapsed_ms(self._response_start))
                self._response_start = None

    def refresh_widgets(self) -> None:
        if not super().refresh_widgets():
            return
        self.reticle.set_cursor_position(*self.cursor_position)
        self.reticle.set_cursor_color(self.parameters[self.cursor_color_key])
        self.reticle.set_target_proportion(self.parameters["targetproportion"])

    def do_on_mouse_press(self, x: int, y: int, button: int) -> None:
        if button != winmouse.LEFT:
            return
        if self.reticle_container.contains_xy(x, y):
            self._mouse_dragging = True
            self._drag_origin_x = x
            self._drag_origin_y = y
            self.x_input = 0
            self.y_input = 0

    def do_on_mouse_release(self, x: int, y: int, button: int) -> None:
        if self._mouse_dragging:
            self._mouse_dragging = False
            self.x_input = 0
            self.y_input = 0

    def do_on_mouse_drag(self, x: int, y: int, dx: int, dy: int, buttons: int) -> None:
        if self._mouse_dragging:
            self._apply_mouse_as_joystick(x, y)

    def _apply_mouse_as_joystick(self, x: int, y: int) -> None:
        # Force is proportional to drag delta from click origin, not reticle center.
        # Dragging right from click point → push cursor right. Intuitive.
        half_w = self.reticle_container.w / 2
        half_h = self.reticle_container.h / 2
        dx = clamp((x - self._drag_origin_x) / half_w, -1.0, 1.0)
        dy = clamp((y - self._drag_origin_y) / half_h, -1.0, 1.0)
        mouse_force = 3
        self.x_input = dx * mouse_force
        # Negate dy: the generator does compy = -y_input (joystick convention),
        # but screen Y already matches cursor Y direction (both go up).
        self.y_input = -dy * mouse_force

    def compute_next_cursor_position(self) -> Generator[tuple[float, float], None, None]:
        # Adapted from Comstock et al., (1992) : the first MATB documentation
        xsin: float = 0
        ysin: float = 0
        xincr: float = 0.005
        yincr: float = 0.006  # Cursor (x, y) asynchroneous speeds

        cursorx: float = 0
        cursory: float = 0
        moffx: float = 0
        moffy: float = 0

        while True:
            # Must wait the drawing of the reticle to evaluate x & y gain
            if f"{self.alias}_reticle" in self.widgets:
                xsin = xsin + xincr if xsin < 2 * pi else 0
                ysin = ysin + yincr if ysin < 2 * pi else 0

                cursorx = sin(xsin) * self.xgain
                cursory = sin(ysin) * self.ygain

                compx: float = 0
                compy: float = 0
                # Apply joystick/agent input offset to the cursor, scaled by joystickforce.
                # When automaticsolver is active, the agent writes x_input/y_input
                # via get_joystick_inputs(), using the same code path as a real joystick.
                if not self.parameters["inverseaxis"]:
                    compx, compy = self.x_input, -self.y_input
                else:
                    compx, compy = -self.x_input, self.y_input

                compx = compx * self.parameters["joystickforce"]
                compy = compy * self.parameters["joystickforce"]

                moffx = moffx + compx
                moffy = moffy + compy

                sin_x = sin(xsin) * self.xgain
                sin_y = sin(ysin) * self.ygain
                cursorx = sin_x + moffx
                cursory = sin_y + moffy

                limitx: float = clamp(cursorx, -self.reticle.container.w / 2, self.reticle.container.w / 2)
                limity: float = clamp(cursory, -self.reticle.container.h / 2, self.reticle.container.h / 2)

                clamp_x = limitx != cursorx
                clamp_y = limity != cursory

                # If outside reticle limits, compensate cursor position
                # Neutralize the joystick only if it does not go toward the center
                if clamp_x:
                    diff: float = cursorx - limitx
                    cursorx -= diff
                    if compx != 0 and diff / compx > 0:  # Same sign
                        moffx -= diff + compx  # compx already includes joystickforce

                if clamp_y:
                    diff = cursory - limity
                    cursory -= diff
                    if compy != 0 and diff / compy > 0:  # Same sign
                        moffy -= diff + compy  # compy already includes joystickforce

                yield (cursorx, cursory)
            else:
                yield (0, 0)
