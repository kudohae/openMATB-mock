# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

from typing import Any, Callable

from pyglet.window import mouse as winmouse

from core import validation
from core.constants import COLORS as C
from core.container import Container
from core.pseudorandom import choice, sample
from core.widgets import Light, Scale
from plugins.abstractplugin import AbstractPlugin


class Sysmon(AbstractPlugin):
    def __init__(self, label: str = "", taskplacement: str = "topleft", taskupdatetime: int = 200) -> None:
        super().__init__(_("System monitoring"), taskplacement, taskupdatetime)

        self.validation_dict: dict[str, Callable[..., Any] | tuple[Callable[..., Any], list[str]]] = {
            "automaticsolver": validation.is_boolean,
            "displayautomationstate": validation.is_boolean,
            "taskfeedback-overdue-active": validation.is_boolean,
            "taskfeedback-overdue-color": validation.is_color,
            "taskfeedback-overdue-delayms": validation.is_natural_integer,
            "taskfeedback-overdue-blinkdurationms": validation.is_natural_integer,
            "feedbackduration": validation.is_positive_integer,
            "feedbacks-positive-active": validation.is_boolean,
            "feedbacks-positive-color": validation.is_color,
            "feedbacks-negative-active": validation.is_boolean,
            "feedbacks-negative-color": validation.is_color,
            "alerttimeout": validation.is_positive_integer,
            "automaticsolverdelay": validation.is_positive_integer,
            "allowanykey": validation.is_boolean,
            **self._indexed_validators(
                "lights",
                range(1, 3),
                {
                    "name": validation.is_string,
                    "failure": validation.is_boolean,
                    "on": validation.is_boolean,
                    "default": (validation.is_in_list, ["on", "off"]),
                    "oncolor": validation.is_color,
                    "key": validation.is_key,
                    "onfailure": validation.is_boolean,
                },
            ),
            **self._indexed_validators(
                "scales",
                range(1, 5),
                {
                    "name": validation.is_string,
                    "failure": validation.is_boolean,
                    "side": (validation.is_in_list, ["-1", "0", "1"]),
                    "key": validation.is_key,
                    "onfailure": validation.is_boolean,
                },
            ),
        }

        self.keys: set[str] = {"F1", "F2", "F3", "F4", "F5", "F6"}
        self.moving_seed: int = 1  # Useful for pseudorandom generation of
        # multiple values at once (arrows move)

        new_par: dict[str, Any] = dict(
            alerttimeout=10000,
            automaticsolver=False,
            automaticsolverdelay=1000,
            displayautomationstate=True,
            allowanykey=False,
            feedbackduration=1500,
            feedbacks=dict(positive=dict(active=True, color=C["GREEN"]), negative=dict(active=True, color=C["RED"])),
            lights=dict(
                [
                    ("1", dict(name="F5", failure=False, default="on", oncolor=C["GREEN"], key="F5", on=True)),
                    ("2", dict(name="F6", failure=False, default="off", oncolor=C["RED"], key="F6", on=False)),
                ]
            ),
            scales=dict(
                [
                    ("1", dict(name="F1", failure=False, side=0, key="F1")),
                    ("2", dict(name="F2", failure=False, side=0, key="F2")),
                    ("3", dict(name="F3", failure=False, side=0, key="F3")),
                    ("4", dict(name="F4", failure=False, side=0, key="F4")),
                ]
            ),
        )

        self.parameters.update(new_par)

        # Add private parameters
        # to any gauge
        for gauge in self.get_all_gauges():
            gauge.update({"_failuretimer": None, "_onfailure": False, "_response_start": None, "_freezetimer": None})

        # and to scale only
        for gauge in self.get_scale_gauges():
            gauge.update(
                {"_pos": 5, "_zone": 0, "_feedbacktimer": None, "_feedbacktype": None, "_hint_arrow_color": None}
            )

        self.automode_position: tuple[float, float] = (0.5, 0.05)
        self.scale_zones: dict[int, list[int]] = {1: list(range(3)), 0: list(range(3, 8)), -1: list(range(8, 11))}

    def get_response_timers(self) -> list[float]:
        return [self._response_elapsed_ms(g["_response_start"]) for g in self.get_all_gauges()]

    def has_active_fault(self) -> bool:
        return len(self.get_gauges_on_failure()) > 0

    def create_widgets(self) -> None:
        super().create_widgets()
        # Widgets coordinates (the left l coordinate is variable)
        scale_w: float = self.task_container.w * 0.1
        scale_b: float = self.task_container.b + self.task_container.h * 0.15
        scale_h: float = self.task_container.h * 0.5

        light_w: float = self.task_container.w * 0.4
        light_b: float = self.task_container.b + self.task_container.h * 0.75
        light_h: float = self.task_container.h * 0.15

        for scale_n, scale in self.parameters["scales"].items():
            scale_l: float = (
                self.task_container.l
                + (self.task_container.w / 4) * (int(scale_n) - 1)
                + self.task_container.w / 8
                - scale_w / 2
            )
            scale_container: Container = Container(f"scale_{scale_n}", scale_l, scale_b, scale_w, scale_h)

            scale["widget"] = self.add_widget(
                f"scale{scale_n!s}",
                Scale,
                container=scale_container,
                label=scale["name"],
                arrow_position=scale["_pos"],
            )

        for light_n, light in self.parameters["lights"].items():
            light_l: float = (
                self.task_container.l
                + (self.task_container.w / 2) * (int(light_n) - 1)
                + self.task_container.w / 4
                - light_w / 2
            )
            light_container: Container = Container(f"light_{light_n}", light_l, light_b, light_w, light_h)

            light["widget"] = self.add_widget(
                f"light{light_n!s}",
                Light,
                container=light_container,
                label=light["name"],
                color=self.determine_light_color(light),
            )

    def compute_next_plugin_state(self) -> None:
        if not super().compute_next_plugin_state():
            return

        # For the gauges that are on failure
        for gauge in self.get_gauges_on_failure():
            # Decrement their failure timer
            gauge["_failuretimer"] -= self.parameters["taskupdatetime"]

            # If the failure timer has ended by itself, stop failure and trigger a negative feedback
            # if possible (scale gauges)
            if gauge["_failuretimer"] <= 0:
                resolved = "auto" if self.parameters["automaticsolver"] else ""
                self.stop_failure(gauge, success=False, resolved_by=resolved)

        for gauge in self.get_scale_gauges():
            if gauge["_feedbacktimer"] is not None:
                gauge["_feedbacktimer"] -= self.parameters["taskupdatetime"]
                if gauge["_feedbacktimer"] <= 0:
                    gauge["_feedbacktimer"] = None
                    gauge["_feedbacktype"] = None

        # Compute arrows next position
        for _scale_n, scale in self.parameters["scales"].items():
            self.moving_seed += 1
            # Manage the case where the arrow must change its zone
            if scale["_pos"] not in self.scale_zones[scale["_zone"]]:
                scale["_pos"] = sample(
                    self.scale_zones[scale["_zone"]], self.alias, self.scenario_time, self.moving_seed
                )
            else:  # Move into a delimited zone
                direction: int = sample([-1, 1], self.alias, self.scenario_time, self.moving_seed)
                if scale["_pos"] + direction in self.scale_zones[scale["_zone"]]:
                    scale["_pos"] += direction
                else:
                    scale["_pos"] -= direction

            # If the gauge freeze timer is not null, freeze its arrow (pos = )
            if scale["_freezetimer"] is not None and isinstance(scale["_freezetimer"], int):
                scale["_freezetimer"] -= self.parameters["taskupdatetime"]
                if scale["_freezetimer"] > 0:
                    # Here, freeze position
                    scale["_pos"] = 5  # TODO: Check central scale value
                else:
                    scale["_freezetimer"] = None

        # Check for failure
        for gauge in self.get_gauges_key_value("failure", True):
            self.start_failure(gauge)

    def refresh_widgets(self) -> None:
        if not super().refresh_widgets():
            return
        for _scale_n, scale in self.parameters["scales"].items():
            scale["widget"].set_arrow_position(scale["_pos"])

            # Apply agent hint color on arrow if set
            if scale["_hint_arrow_color"] is not None:
                scale["widget"].set_arrow_color(scale["_hint_arrow_color"])
            else:
                scale["widget"].set_arrow_color(C["BLACK"])

            if scale["_feedbacktimer"] is not None:
                color: tuple[int, ...] = self.parameters["feedbacks"][scale["_feedbacktype"]]["color"]
                scale["widget"].set_feedback_color(color)
                scale["widget"].set_feedback_visibility(True)

            # Feedback timer is over and the feedback is yet visible
            # Hide the feedback
            else:
                scale["widget"].set_feedback_visibility(False)

        for _light_n, light in self.parameters["lights"].items():
            light["widget"].set_color(self.determine_light_color(light))

        for gauge in self.get_all_gauges():
            gauge["widget"].set_label(gauge["name"])

    def determine_light_color(self, light: dict[str, Any]) -> tuple[int, ...]:
        color: tuple[int, ...] = light["oncolor"] if light["on"] else C["BACKGROUND"]
        return color

    def start_failure(self, gauge: dict[str, Any]) -> None:
        if gauge["_onfailure"]:
            self.logger.log(f"[{self.alias}] Failure ignored on '{gauge['name']}': already on failure")
        else:
            gauge["_onfailure"] = True
            if "default" in gauge:  # Light case
                gauge["on"] = gauge["default"] != "on"
            else:  # Scale case
                if gauge["side"] not in [-1, 1]:
                    add: str | None = self.get_gauge_key(gauge)  # Specify a gauge integer to generate
                    # a unique seed
                    gauge["side"] = choice([-1, 1], self.alias, self.scenario_time, int(add))
                gauge["_zone"] = gauge["side"]
        gauge["failure"] = False
        self.start_response_timer(gauge)

        # Schedule failure timing (with the automatic solver, the agent resolves the failure after
        # automaticsolverdelay; the alert timeout, or the agent delay, is a safety net)
        delay: int = self.parameters["alerttimeout"]
        if self.parameters["automaticsolver"] and self.agent is not None:
            overrides: dict = self.agent.on_failure_started(self, gauge)
            if "delay" in overrides:
                delay = overrides["delay"]
        gauge["_failuretimer"] = delay

    def stop_failure(self, gauge: dict[str, Any], success: bool = False, resolved_by: str = "") -> None:
        # Reset the gauge failure timer
        gauge["_onfailure"] = False
        gauge["_failuretimer"] = None

        # Set the (potential) feedback type (ft)
        ft: str = "positive" if self.parameters["automaticsolver"] or success else "negative"

        # Does this feedback type (positive or negative) is currently active ?
        # If so, set the feedback type and duration, if the gauge has got one
        # (the feedback widget is refreshed by the refresh_widget method)
        if self.parameters["feedbacks"][ft]["active"] and self._is_scale(gauge):
            self.set_scale_feedback(gauge, ft)

        # Feed the freeze timer with feedback duration (1.5 by default) if the response is good
        if success:
            gauge["_freezetimer"] = self.parameters["feedbackduration"]

        # IDEA: do we need to distinguish manual detection (hit) from automatic detection ?
        # Evaluate performance in terms of signal detection and response time
        if ft == "positive":
            sdt_string: str
            rt: int | float
            sdt_string, rt = "HIT", self.response_time_ms(gauge, human=resolved_by == "human")
        else:
            sdt_string, rt = "MISS", float("nan")
        sdt_string = "HIT" if ft == "positive" else "MISS"

        self.log_performance("name", gauge["name"])
        self.log_performance("signal_detection", sdt_string)
        self.log_performance("response_time", rt)
        self.log_performance("resolved_by", resolved_by)

        # Reset gauge to its nominal (default) state
        if "default" in gauge:  # Light case
            gauge["on"] = gauge["default"] == "on"
        else:  # Scale case
            gauge["_zone"] = 0
        gauge["_response_start"] = None

    def get_gauges_key_value(self, key: str, value: Any) -> list[dict[str, Any]]:
        return self._filter_by(self.get_all_gauges(), key, value)

    def get_gauge_by_key(self, key: str) -> dict[str, Any]:
        return self._filter_by(self.get_all_gauges(), "key", key)[0]

    def get_gauge_key(self, gauge: dict[str, Any]) -> str | None:
        for key in ["lights", "scales"]:
            for k, v in self.parameters[key].items():
                if gauge == v:
                    return k

    def get_gauges_on_failure(self) -> list[dict[str, Any]]:
        return self.get_gauges_key_value("_onfailure", True)

    def get_scale_gauges(self) -> list[dict[str, Any]]:
        return [g for _, g in self.parameters["scales"].items()]

    def get_light_gauges(self) -> list[dict[str, Any]]:
        return [g for _, g in self.parameters["lights"].items()]

    def get_all_gauges(self) -> list[dict[str, Any]]:
        return [g for g in self.get_scale_gauges() + self.get_light_gauges()]

    def _is_scale(self, gauge: dict[str, Any]) -> bool:
        """Only scales own a feedback widget (lights have none)."""
        return any(gauge is g for g in self.get_scale_gauges())

    def set_scale_feedback(self, gauge: dict[str, Any], feedback_type: str) -> None:
        # Set the feedback type and duration, if the gauge has got one
        # (the feedback widget is refreshed by the refresh_widget method)
        gauge["_feedbacktype"] = feedback_type
        gauge["_feedbacktimer"] = self.parameters["feedbackduration"]

    def filter_key(self, keystr: str) -> str | None:
        # allowanykey may be enabled from a scenario (set_parameter): SPACE is accepted too whenever the mode
        # is on. (When the mode is off, a SPACE left in self.keys is ignored by do_on_key.)
        if self.parameters["allowanykey"]:
            self.keys.add("SPACE")
        return super().filter_key(keystr)

    def do_on_key(self, key: str, state: str, emulate: bool) -> None:
        key = super().do_on_key(key, state, emulate)
        if key is None:
            return

        if state == "press":
            resolver: str = "agent" if emulate else "human"

            gauges: list[dict[str, Any]] = self.get_gauges_key_value("key", key)
            failures: list[dict[str, Any]] = self.get_gauges_on_failure()
            if self.parameters["allowanykey"]:
                # Any sysmon key, or SPACE, signals a failure: the one of the key if it is failing, else the first one
                if failures:
                    failing: list[dict[str, Any]] = [g for g in failures if g["key"] == key]
                    self.stop_failure(gauge=(failing or failures)[0], success=True, resolved_by=resolver)
                    return
            elif not gauges:  # An accepted key mapped to no gauge (a SPACE left from allowanykey)
                return
            elif gauges[0] in failures:
                self.stop_failure(gauge=gauges[0], success=True, resolved_by=resolver)
                return

            # False alarm (no failure on this gauge, or none at all with allowanykey)
            self.log_performance("name", gauges[0]["name"] if gauges else key)
            self.log_performance("signal_detection", "FA")
            self.log_performance("response_time", float("nan"))
            self.log_performance("resolved_by", resolver)

            # Set a negative feedback if relevant
            if gauges and self.parameters["feedbacks"]["negative"]["active"] and self._is_scale(gauges[0]):
                self.set_scale_feedback(gauges[0], "negative")

    def do_on_mouse_press(self, x: int, y: int, button: int) -> None:
        if button != winmouse.LEFT:
            return
        for gauge in self.get_all_gauges():
            if gauge["widget"].container.contains_xy(x, y):
                self.logger.record_input("mouse_key", gauge["key"], "press")
                self.do_on_key(gauge["key"], "press", False)
                return
