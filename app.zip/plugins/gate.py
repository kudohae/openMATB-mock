# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): end a tutorial step as soon as the participant succeeds.

"""Gate: when started, waits for a correct communications response (HIT) by the participant, then makes the
scenario jump to `skipto` (seconds). Without success, the scenario simply goes on until `skipto`.

Example (tutorial of the communications task, up to 60 s):
0:01:00;communications;radioprompt;own
0:01:00;gate;skipto;120
0:01:00;gate;start
"""

from __future__ import annotations

from typing import Any, Callable

from core import study_gate, validation
from plugins.abstractplugin import AbstractPlugin


class Gate(AbstractPlugin):
    def __init__(self, label: str = "", taskplacement: str = "invisible", taskupdatetime: int = 50) -> None:
        super().__init__(_("Gate"), taskplacement, taskupdatetime)
        self.validation_dict: dict[str, Callable[..., Any]] = {"skipto": validation.is_natural_integer}
        self.parameters.update(dict(skipto=0))
        self._hits_at_start: int = 0

    def start(self) -> None:
        super().start()
        self._hits_at_start = study_gate.comm_hits

    def compute_next_plugin_state(self) -> bool:
        if not super().compute_next_plugin_state():
            return False
        if self.scenario_time >= float(self.parameters["skipto"]):  # Not passed: the step ends anyway
            self.stop()
        elif study_gate.comm_hits > self._hits_at_start:
            target: float = float(self.parameters["skipto"])
            if target > self.scenario_time:
                study_gate.skip_to = target
                self.logger.log_manual_entry(f"Gate passed at {self.scenario_time:.2f}, skip to {target:.0f}")
            self.stop()
        return True
