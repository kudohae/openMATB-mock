# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

from pathlib import Path
from typing import Any

import pyglet.app
import pyglet.clock

from core import timing
from core.clock import Clock
from core.constants import REPLAY_MODE, SYSTEM_PSEUDO_PLUGIN
from core.error import get_errors
from core.event import Event
from core import study_gate
from core.joystick import joystick
from core.logger import get_logger
from core.platform import IS_WEB, browser_environment, notify_page
from core.scenario import Scenario
from core.window import Window

# Browser: how often the session file is saved to persistent storage (seconds)
WEB_CHECKPOINT_INTERVAL: float = 10
# Browser: updates later than this (seconds) are logged as "freeze" (the browser paused the page, e.g. Firefox GC)
WEB_FREEZE_THRESHOLD: float = 0.1


class Scheduler:
    """
    This class manages events execution.

    It does not block: the pyglet event loop must be started by the caller (pyglet.app.run()).
    """

    def __init__(self, scenario_path: Path | None = None) -> None:
        with open("VERSION", "r", encoding="utf-8") as f:
            get_logger().log_manual_entry(f.read().strip(), key="version")
        for key, value in browser_environment():  # Browser, version and system (timing differs between them)
            get_logger().log_manual_entry(value, key=key)
        # The size of the window (a page in the browser): the replay places the mouse inputs with it
        if Window.MainWindow is not None and not REPLAY_MODE:
            get_logger().log_manual_entry(f"{Window.MainWindow.width}x{Window.MainWindow.height}", key="window")

        self.clock: Clock = Clock("main")
        self.scenario_time: float = 0
        self.scenario_path: Path | None = scenario_path

        self._exited: bool = False
        self.clock.schedule(self.update)
        if IS_WEB:
            pyglet.clock.schedule_interval(get_logger().checkpoint, WEB_CHECKPOINT_INTERVAL)

        self.joystick: Any = joystick
        self.set_scenario()

        Window.MainWindow.display_session_id()

    def set_scenario(self, events: list[str] | None = None) -> None:
        scenario_path: Path | None = self.scenario_path if events is None else None
        self.scenario: Scenario = Scenario(events, scenario_path=scenario_path)

        self.events: list[Event] = self.scenario.events
        self.events.sort(key=lambda e: (e.time_sec, e.line))
        self.plugins: dict[str, Any] = self.scenario.plugins

        # Create a default agent and assign it to plugins
        from agents import DefaultAgent

        self.agent: Any = DefaultAgent()
        for p in self.plugins:
            if "automaticsolver" in self.plugins[p].parameters:
                self.plugins[p].agent = self.agent

        # Push plugin handles to window
        for p in self.plugins:
            self.plugins[p].joystick = self.joystick
            if not REPLAY_MODE:
                Window.MainWindow.push_handlers(self.plugins[p].on_key_press, self.plugins[p].on_key_release)

            self.plugins[p].on_scenario_loaded(self.scenario)

        self.pause_scenario_time: bool = False
        self.mouse_control_enabled: bool = False
        self.scenario_time = 0
        timing.reset()

        # Cursor into the sorted events list — advances monotonically
        self._event_cursor: int = 0

        # We store events in a list in case their execution is delayed by a blocking event
        self.events_queue: list[Event] = list()
        self.blocking_plugin: Any | None = None

        # Store the plugins that could be paused by a *blocking* event
        self.paused_plugins: list[Any] = list()

        # Track whether plugins have been paused due to a modal dialog (e.g. pause prompt)
        self._dialog_paused: bool = False
        # Store the plugins paused by the modal dialog (those which were running when it opened)
        self._dialog_paused_plugins: list[Any] = list()

    def update(self, dt: float) -> None:
        if Window.MainWindow.modal_dialog is not None:
            if not self._dialog_paused:
                # Pause only the running plugins, so that plugins already paused
                # (e.g. by a blocking plugin) are not resumed when the dialog closes
                self._dialog_paused_plugins = self.get_plugins_by_states([("alive", True), ("paused", False)])
                self.execute_plugins_methods(self._dialog_paused_plugins, ["pause"])
                self._dialog_paused = True
            timing.set_tick(self.scenario_time, running=False)
            return

        if self._dialog_paused:
            resumed: list[Any] = [p for p in self._dialog_paused_plugins if p.alive]
            self.execute_plugins_methods(resumed, ["resume"])
            self._dialog_paused_plugins = list()
            self._dialog_paused = False

        if not get_errors().is_empty():
            get_errors().show_errors()

        # Logged before the timers are updated: the row gets the scenario time when the page stopped
        if IS_WEB and dt > WEB_FREEZE_THRESHOLD:
            get_logger().log_manual_entry(f"{dt * 1000:.0f}", key="freeze")

        self.update_timers(dt)
        self.update_joystick()
        self.update_active_plugins()
        self.execute_events()
        self.check_if_must_exit()

    def update_timers(self, dt: float) -> None:
        # Korean adaptation: a tutorial step passed (plugins/gate.py) jumps to the next step
        if study_gate.skip_to is not None:
            self.scenario_time = max(self.scenario_time, study_gate.skip_to)
            study_gate.skip_to = None
        # Update timers with dt
        if not self.is_scenario_time_paused():
            self.scenario_time += dt
            get_logger().set_scenario_time(self.scenario_time)
        timing.set_tick(self.scenario_time, running=not self.is_scenario_time_paused())

    def update_active_plugins(self) -> None:
        for p in self.get_active_plugins():
            p.update(self.scenario_time)

    def update_joystick(self) -> None:
        # Execute the update method of the joystick
        if self.joystick is None:
            return

        self.joystick.update()
        # Check if there are active plugins...
        if len(self.get_active_plugins()) > 0:
            for p in self.get_active_plugins():
                # Send joystick inputs to appropriate plugin (tracking)
                if hasattr(p, "get_joystick_inputs"):
                    p.get_joystick_inputs(self.joystick.x, self.joystick.y)

                # ... if a joystick button has been just pressed/released
                # ... execute the according on_key_press method in active plugins
            if self.joystick.has_any_key_changed():
                for k, v in self.joystick.key_change.items():
                    if v == "press":
                        [p.on_joy_key_press(k) for p in self.get_active_plugins()]
                    elif v == "release":
                        [p.on_joy_key_release(k) for p in self.get_active_plugins()]

                    self.joystick.reset_key_change(k)

    def check_if_must_exit(self) -> None:
        # If no active plugin, and no remaining events (queued or to come), close the OpenMATB
        if (
            len(self.get_active_plugins()) == 0
            and len(self.events_queue) == 0
            and self._event_cursor >= len(self.events)
        ):
            self.exit()

        # If the windows has been killed, exit the program
        if not Window.MainWindow.alive:
            # Be careful to stop all the plugins in case they're not
            # (so we have a stop time for each plugin, in case we must compute this somewhere)
            for p_name, plugin in self.plugins.items():
                if plugin.alive:
                    stop_event: Event = Event(0, int(self.scenario_time), p_name, "stop")
                    self.execute_one_event(stop_event)
            self.exit()

    def execute_events(self) -> None:
        # Detect a potential blocking plugin
        active_blocking_plugin: Any | None = self.get_active_blocking_plugin()

        # Execute scenario events in case the scenario timer is running
        if not self.is_scenario_time_paused():
            if active_blocking_plugin is None:
                event: Event | None = self.get_event_at_scenario_time(self.scenario_time)
                if event is not None:
                    self.execute_one_event(event)

            # Check if a blocking plugin has started so to pause concurrent plugins
            elif active_blocking_plugin.alive:
                # Toggle scenario_time pause only once
                if not self.is_scenario_time_paused():
                    self.pause_scenario()
                    self.paused_plugins = self.get_active_non_blocking_plugins()
                    # A guide (plugins/guide.py) explains the tasks on screen: pause them without masking them
                    keep_visible: bool = getattr(active_blocking_plugin, "keep_tasks_visible", False)
                    methods: list[str] = ["pause"] if keep_visible else ["pause", "hide"]
                    self.execute_plugins_methods(self.paused_plugins, methods=methods)

        # In Replay mode: IT IS the play/pause button that manages the scenario resuming
        elif active_blocking_plugin is None:
            if len(self.paused_plugins) > 0:
                self.execute_plugins_methods(self.paused_plugins, methods=["show", "resume"])
                self.paused_plugins = list()
            self.resume_scenario()

    def is_scenario_time_paused(self) -> bool:
        return self.pause_scenario_time

    def pause_scenario(self) -> bool:
        self.pause_scenario_time = True
        return self.is_scenario_time_paused()

    def resume_scenario(self) -> bool:
        self.pause_scenario_time = False
        return self.is_scenario_time_paused()

    def toggle_scenario(self) -> bool:
        self.pause_scenario_time = not self.pause_scenario_time
        return self.is_scenario_time_paused()

    def get_active_blocking_plugin(self) -> Any | None:
        p: list[Any] = self.get_plugins_by_states([("blocking", True), ("paused", False)])
        if len(p) > 0:
            return p[0]

    def get_active_non_blocking_plugins(self) -> list[Any]:
        return self.get_plugins_by_states([("blocking", False), ("paused", False)])

    def get_active_plugins(self) -> list[Any]:
        return self.get_plugins_by_states([("alive", True)])

    def execute_one_event(self, event: Event) -> None:
        if event.plugin == SYSTEM_PSEUDO_PLUGIN:
            self._execute_system_command(event)
            return

        # Set the plugin corresponding to the event
        plugin: Any = self.plugins[event.plugin]

        # If one argument, assume it is a plugin method to execute
        if len(event.command) == 1:
            getattr(plugin, event.command[0])()

        # If two arguments in the 'command' field, suppose a (parameter, value) to update
        elif len(event.command) == 2:
            plugin.set_parameter(event.command[0], event.command[1])

        event.done = 1

        # The event can be logged whenever inside the method, since self.durations remain
        # constant all along it
        get_logger().record_event(event)

    def _execute_system_command(self, event: Event) -> None:
        command: str = event.command[0]
        if command == "pause":
            Window.MainWindow.pause_prompt()
        elif command == "agent":
            # In replay mode, agent inputs are replayed from the log —
            # do not activate the agent or it would produce double inputs.
            if not REPLAY_MODE:
                from agents import create_agent

                agent_name: str = event.command[1]
                self.agent = create_agent(agent_name)
                for p in self.plugins:
                    if "automaticsolver" in self.plugins[p].parameters:
                        self.plugins[p].agent = self.agent
        elif command == "mousecontrol":
            enabled = event.command[1] in (True, "True", "true")
            self.mouse_control_enabled = enabled  # The replay shows the mouse of the session with it
            if not REPLAY_MODE:
                Window.MainWindow.mouse_control_active = enabled
                if enabled:
                    for p in self.plugins:
                        Window.MainWindow.push_handlers(
                            self.plugins[p].on_mouse_press,
                            self.plugins[p].on_mouse_release,
                            self.plugins[p].on_mouse_drag,
                        )
                else:
                    for p in self.plugins:
                        Window.MainWindow.remove_handlers(
                            self.plugins[p].on_mouse_press,
                            self.plugins[p].on_mouse_release,
                            self.plugins[p].on_mouse_drag,
                        )
        event.done = 1
        get_logger().record_event(event)

    def execute_plugins_methods(self, plugins: list[Any], methods: str | list[str]) -> None:
        if len(plugins) == 0:
            return

        if isinstance(methods, str):
            methods = [methods]

        for m in methods:
            for p in plugins:
                # self.execute_one_event(Event(0, 0, p.alias, m)) DO NOT create new events
                getattr(p, m)()

    def get_plugins_by_states(self, attribute_state_list: list[tuple[str, Any]]) -> list[Any]:
        plugins: dict[str, Any] = {k: p for k, p in self.plugins.items()}
        for attribute, state in attribute_state_list:
            plugins = {k: p for k, p in plugins.items() if getattr(p, attribute) == state}
        return [p for _, p in plugins.items()]

    def get_event_at_scenario_time(self, scenario_time: float) -> Event | None:
        # Advance cursor past events whose time has arrived, enqueuing them.
        # Events are pre-sorted by (time_sec, line) in set_scenario(), so
        # simultaneous events are dispatched in line order. Each event is
        # visited exactly once — O(1) amortized per tick.
        while self._event_cursor < len(self.events):
            event: Event = self.events[self._event_cursor]
            if event.time_sec > scenario_time:
                break
            self._event_cursor += 1
            self.events_queue.append(event)

        return self.unqueue_event()

    def unqueue_event(self) -> Event | None:
        # If some events must be executed, unstack the next event
        if len(self.events_queue) > 0:
            event: Event = self.events_queue[0]
            del self.events_queue[0]
            return event

        return None

    def exit(self) -> None:
        if self._exited:
            return
        self._exited = True
        self.clock.unschedule(self.update)
        pyglet.clock.unschedule(get_logger().checkpoint)
        get_logger().log_manual_entry("end")
        get_logger().end_session()
        Window.MainWindow.close()  # needed for windows clean exit
        pyglet.app.exit()
        notify_page("openmatb-exit")
