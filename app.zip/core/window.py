# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from pyglet import image
from pyglet.display import get_display
from pyglet.graphics import Batch
from pyglet.shapes import Rectangle
from pyglet.text.formats.html import HTMLDecoder
from pyglet.text.layout import TextLayout
from pyglet.window import Window
from pyglet.window import key as winkey

from core import pyglet_compat, timing
from core.constants import COLORS as C
from core.constants import (
    HEADLESS_MODE,
    PLUGIN_TITLE_HEIGHT_PROPORTION,
    REPLAY_MODE,
    REPLAY_PERF_STRIP_PROPORTION,
    REPLAY_STRIP_PROPORTION,
)
from core.constants import PATHS as P
from core.constants import Group as G
from core.container import Container
from core.logger import get_logger
from core.modaldialog import ModalDialog
from core.platform import IS_WEB, download_file, on_page_resize, on_visibility_change, viewport_size
from core.utils import get_conf_value


def _set_html_default_font() -> None:
    # HTML labels default to "Times New Roman": use the configured font, or the platform default one
    font_name: str | None = get_conf_value("Openmatb", "font_name") or pyglet_compat.default_font_name()
    HTMLDecoder.default_style["font_name"] = font_name


def _snap_text_to_pixels() -> None:
    # Text drawn at a fractional position (e.g. centered in a container) falls between two pixels:
    # glyphs are sampled unevenly and look jagged with GPU rendering. Round the text positions.
    if getattr(TextLayout, "_openmatb_snapped", False):
        return
    init, set_x, set_y, set_position = (
        TextLayout.__init__,
        TextLayout._set_x,
        TextLayout._set_y,
        TextLayout._set_position,
    )

    def snapped_init(self: TextLayout, *args: Any, **kwargs: Any) -> None:
        init(self, *args, **kwargs)
        if (self._x, self._y) != (round(self._x), round(self._y)):
            self._x, self._y = round(self._x), round(self._y)
            self._update_translation()

    TextLayout.__init__ = snapped_init
    TextLayout._set_x = lambda self, x: set_x(self, round(x))
    TextLayout._set_y = lambda self, y: set_y(self, round(y))
    TextLayout._set_position = lambda self, p: set_position(self, (round(p[0]), round(p[1]), p[2]))
    TextLayout._openmatb_snapped = True


class Window(Window):
    # Static variable
    MainWindow: Window | None = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        Window.MainWindow = self  # correct way to set it as a static
        _set_html_default_font()
        _snap_text_to_pixels()

        if IS_WEB:
            # In the browser, the canvas fills the viewport; fullscreen requires a user gesture
            screen: Any = None
            self._width, self._height = viewport_size()
            self._fullscreen: bool = False
        else:
            screen = self.get_screen()
            self._width: int = int(screen.width)
            self._height: int = int(screen.height)
            self._fullscreen = False if HEADLESS_MODE else get_conf_value("Openmatb", "fullscreen")

        super().__init__(
            fullscreen=self._fullscreen,
            width=self._width,
            height=self._height,
            vsync=True,
            config=pyglet_compat.window_config(screen),
            *args,
            **kwargs,
        )
        pyglet_compat.set_clear_color(self, 0, 0, 0, 1)

        if not IS_WEB:
            img_path: Any = P["IMG"]
            logo16: Any = image.load(str(img_path.joinpath("logo16.png")))
            logo32: Any = image.load(str(img_path.joinpath("logo32.png")))
            self.set_icon(logo16, logo32)
            self.set_size_and_location(screen)  # Postpone multiple monitor support
            if not self._fullscreen and not HEADLESS_MODE and sys.platform == "win32":
                # A window, not the fullscreen: with the size of the screen, its bottom was under the taskbar
                self.fit_to_work_area()

        pyglet_compat.set_mouse_cursor_visible(self, REPLAY_MODE)

        if HEADLESS_MODE:
            self.set_visible(False)

        self.batch: Batch = Batch()
        self.keyboard: dict[str, bool] = dict()  # Reproduce a simple KeyStateHandler

        self.create_MATB_background()
        self.alive: bool = True
        self.modal_dialog: ModalDialog | None = None
        self.slider_visible: bool = False
        self.selector_visible: bool = False
        self.mouse_control_active: bool = False
        self.on_key_press_replay: Any | None = None  # used by the replay

        # In the browser, timers are throttled in hidden tabs: pause the scenario
        on_visibility_change(self.on_visibility_change)

        # In the browser, the page can be resized (e.g. leaving fullscreen): scale the display to it
        self._device_pixel_ratio: float | None = self.scale if IS_WEB else None
        on_page_resize(self.fit_to_page)

    @property
    def scale(self) -> float:
        # Browser: pyglet also converts the mouse positions with _scale, which fit_to_page() adapts
        return getattr(self, "_device_pixel_ratio", None) or super().scale

    @property
    def dpi(self) -> int:
        ratio: float | None = getattr(self, "_device_pixel_ratio", None)
        return int(ratio * 96) if ratio else super().dpi

    def fit_to_page(self) -> None:
        """Browser: scale the display of the canvas to the page, centered (see web/index.html), keeping the
        resolution and the layout computed at startup: everything stays visible when leaving fullscreen."""
        page_width, page_height = viewport_size()
        factor: float = min(page_width / self._width, page_height / self._height)
        self._canvas.style.width = f"{self._width * factor}px"
        self._canvas.style.height = f"{self._height * factor}px"
        # pyglet converts mouse positions (CSS pixels) to framebuffer pixels by multiplying them by _scale
        self._scale = self._device_pixel_ratio / factor

    def on_visibility_change(self, hidden: bool) -> None:
        get_logger().log_manual_entry("hidden" if hidden else "visible", key="visibility")
        if hidden and not REPLAY_MODE and not self.selector_visible and self.modal_dialog is None:
            self.pause_prompt()

    def display_session_id(self) -> None:
        # Display the session ID if needed at window instanciation
        if HEADLESS_MODE:
            return
        if not REPLAY_MODE and get_conf_value("Openmatb", "display_session_number"):
            msg: str = _("Session ID: %s") % get_logger().session_id
            title: str = "OpenMATB"

            self.modal_dialog = ModalDialog(self, msg, title)

    def get_screen(self) -> Any:
        # Screen definition
        try:
            screen_index: int = get_conf_value("Openmatb", "screen_index")
        except (KeyError, TypeError):
            screen_index = 0

        screens: list[Any] = get_display().get_screens()
        if screen_index + 1 > len(screens):
            screen: Any = screens[-1]
            from core.error import get_errors

            get_errors().add_error(
                _(
                    "In config.ini, the specified screen index exceeds the number of"
                    " available screens (%s). Last screen selected."
                )
                % len(get_display().get_screens())
            )
        else:
            screen = screens[screen_index]

        return screen

    def fit_to_work_area(self) -> None:
        """Windows: fit the window, its frame included, in the work area of its screen (without the taskbar); the
        tasks are then laid out in its client area. (maximize() kept the size of the screen with pyglet.)"""
        import ctypes
        from ctypes import wintypes

        class MONITORINFO(ctypes.Structure):
            _fields_ = (
                ("cbSize", wintypes.DWORD),
                ("rcMonitor", wintypes.RECT),
                ("rcWork", wintypes.RECT),
                ("dwFlags", wintypes.DWORD),
            )

        user32: Any = ctypes.windll.user32
        info: MONITORINFO = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        monitor: Any = user32.MonitorFromWindow(self._hwnd, 2)  # MONITOR_DEFAULTTONEAREST
        outer, client = wintypes.RECT(), wintypes.RECT()
        if not (
            user32.GetMonitorInfoW(monitor, ctypes.byref(info))
            and user32.GetWindowRect(self._hwnd, ctypes.byref(outer))
            and user32.GetClientRect(self._hwnd, ctypes.byref(client))
        ):
            return
        frame_width: int = (outer.right - outer.left) - client.right  # The two borders
        frame_height: int = (outer.bottom - outer.top) - client.bottom  # The title bar and the two borders
        work: wintypes.RECT = info.rcWork
        width: int = (work.right - work.left) - frame_width
        height: int = (work.bottom - work.top) - frame_height
        if width <= 0 or height <= 0:
            return
        self.set_size(width, height)
        # The location is the one of the client area: under the title bar and the top border
        self.set_location(work.left + frame_width // 2, work.top + frame_height - frame_width // 2)
        self.dispatch_events()  # The new size, before the tasks are laid out
        self._width, self._height = self.width, self.height

    def set_size_and_location(self, screen: Any) -> None:
        self.switch_to()  # The Window must be active before setting the location
        target_x: float = (screen.x + screen.width / 2) - screen.width / 2
        target_y: float = (screen.y + screen.height / 2) - screen.height / 2
        self.set_location(int(target_x), int(target_y))

    def create_MATB_background(self) -> None:
        MATB_container: Container = self.get_container("fullscreen")
        l, b, w, h = MATB_container.get_lbwh()
        container_title_h: float = PLUGIN_TITLE_HEIGHT_PROPORTION / 2

        # Main background
        bg = Rectangle(x=l, y=b, width=w, height=h, color=C["BACKGROUND"][:3], batch=self.batch, group=G(-1))
        bg.opacity = C["BACKGROUND"][3]

        # Upper band
        upper_h: float = h * container_title_h
        upper_y: float = b + h - upper_h
        upper = Rectangle(x=l, y=upper_y, width=w, height=upper_h, color=C["BLACK"][:3], batch=self.batch, group=G(-1))
        upper.opacity = C["BLACK"][3]

        # Middle band
        mid_h: float = h * container_title_h
        mid_y: float = b + h * (0.5 - container_title_h)
        mid = Rectangle(x=l, y=mid_y, width=w, height=mid_h, color=C["BLACK"][:3], batch=self.batch, group=G(0))
        mid.opacity = C["BLACK"][3]

        self.bg_shapes: list[Rectangle] = [bg, upper, mid]

    def set_bg_bands_visible(self, visible: bool) -> None:
        for band in self.bg_shapes[1:]:
            band.visible = visible

    def take_screenshot(self) -> None:
        """Capture the framebuffer at the end of the next draw (bypasses DWM cache issues).

        Not at once: in the browser, the WebGL drawing buffer is cleared once it has been displayed."""
        self._screenshot_requested = True

    def save_screenshot(self) -> None:
        timestamp: str = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = Path(f"screenshot_{timestamp}.png")
        pyglet_compat.get_screenshot().save(str(filepath))
        get_logger().log_manual_entry(str(filepath), key="screenshot")
        download_file(filepath, "image/png")  # Browser: the file is in the page storage, hand it to the user

    def on_draw(self) -> None:
        timing.flip()  # This frame displays the stimuli started since the last one
        pyglet_compat.set_mouse_cursor_visible(self, self.is_mouse_necessary())
        self.clear()
        self.batch.draw()
        if getattr(self, "_screenshot_requested", False):
            self._screenshot_requested = False
            self.save_screenshot()

    def is_mouse_necessary(self) -> bool:
        return self.slider_visible or self.selector_visible or REPLAY_MODE or self.mouse_control_active

    # Log any keyboard input, either plugins accept it or not
    # is subclassed in replay mode
    def on_key_press(self, symbol: int, modifiers: int) -> None:
        if symbol == winkey.F12:
            self.take_screenshot()
            return

        if REPLAY_MODE:
            return

        if self.modal_dialog is None:
            keystr: str = winkey.symbol_string(symbol)
            self.keyboard[keystr] = True  # KeyStateHandler

            if keystr == "ESCAPE":
                self.exit_prompt()
            elif keystr == "P":
                self.pause_prompt()

            get_logger().record_input("keyboard", keystr, "press")

    def on_key_release(self, symbol: int, modifiers: int) -> None:
        if self.modal_dialog is not None:
            self.modal_dialog.on_key_release(symbol, modifiers)
            return

        if REPLAY_MODE:
            return

        keystr: str = winkey.symbol_string(symbol)
        self.keyboard[keystr] = False  # KeyStateHandler
        get_logger().record_input("keyboard", keystr, "release")

    def on_deactivate(self) -> None:
        # In the browser, a key released while the page does not have the focus (tab change, click outside the
        # page) sends no key up: pyglet keeps it pressed and ignores the next press of that key (a lost response).
        # Release the held keys when the focus is lost. (Only the browser window has _keys_down.)
        keys_down: set[int] | None = getattr(self, "_keys_down", None)
        if not keys_down:
            return
        held: list[int] = list(keys_down)
        keys_down.clear()
        if self.modal_dialog is None:  # A key release would answer the dialog
            for symbol in held:
                self.dispatch_event("on_key_release", symbol, 0)

    def on_mouse_motion(self, x: int, y: int, dx: int, dy: int) -> None:
        if REPLAY_MODE:
            return
        get_logger().record_input("mouse", "x", x)
        get_logger().record_input("mouse", "y", y)

    def on_mouse_drag(self, x: int, y: int, dx: int, dy: int, buttons: int, modifiers: int) -> None:
        if REPLAY_MODE:
            return
        get_logger().record_input("mouse", "x", x)
        get_logger().record_input("mouse", "y", y)

    def on_mouse_press(self, x: int, y: int, button: int, modifiers: int) -> None:
        if REPLAY_MODE:
            return
        get_logger().record_input("mouse", "click", f"press;{x};{y};{button}")

    def on_mouse_release(self, x: int, y: int, button: int, modifiers: int) -> None:
        if REPLAY_MODE:
            return
        get_logger().record_input("mouse", "click", f"release;{x};{y};{button}")

    def exit_prompt(self) -> None:
        if HEADLESS_MODE:
            return
        # Korean adaptation: P to exit (Q is the key of pump 1, pressed all along task 2)
        self.modal_dialog = ModalDialog(self, _("You hit the Escape key"), title=_("Exit OpenMATB?"), exit_key="p")

    def pause_prompt(self) -> None:
        if HEADLESS_MODE:
            return
        self.modal_dialog = ModalDialog(self, _("Pause"))

    def exit(self) -> None:
        self.alive = False

    def get_container_list(self) -> list[Container]:
        mar: float = REPLAY_STRIP_PROPORTION if REPLAY_MODE else 0
        perf_mar: float = REPLAY_PERF_STRIP_PROPORTION if REPLAY_MODE else 0
        w: float = (1 - mar) * self.width
        h: float = (1 - mar - perf_mar) * self.height
        b: float = self.height * mar

        # Vertical bounds
        x1, x2 = (int(w * bound) for bound in get_conf_value("Openmatb", "top_bounds"))  # Top row
        x3, x4 = (int(w * bound) for bound in get_conf_value("Openmatb", "bottom_bounds"))  # Bottom row

        # Horizontal bound
        y1: float = b + h / 2

        return [
            Container("invisible", 0, 0, 0, 0),
            Container("fullscreen", 0, b, w, h),
            Container("topleft", 0, y1, x1, h / 2),
            Container("topmid", x1, y1, x2 - x1, h / 2),
            Container("topright", x2, y1, w - x2, h / 2),
            Container("bottomleft", 0, b, x3, h / 2),
            Container("bottommid", x3, b, x4 - x3, h / 2),
            Container("bottomright", x4, b, w - x4, h / 2),
            # The strips of the replay span the whole window (they were 8 % wider: their end was off-screen)
            Container("mediastrip", 0, 0, self._width, b),
            Container("inputstrip", w, b, self._width * mar, h),
            Container("perfstrip", 0, b + h, self._width, self.height * perf_mar),
        ]

    def get_container(self, placement_name: str) -> Container | None:
        container: list[Container] = [c for c in self.get_container_list() if c.name == placement_name]
        if len(container) > 0:
            return container[0]
        else:
            print(_("Error. No placement found for the [%s] alias") % placement_name)

    def open_modal_window(self, pass_list: list[str], title: str, continue_key: str | None, exit_key: str) -> None:
        self.modal_dialog = ModalDialog(self, pass_list, title=title, continue_key=continue_key, exit_key=exit_key)
