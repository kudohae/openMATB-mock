# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): communications prompts read in Korean by the browser speech synthesis.

"""Korean voice for the communications task (browser only).

The recorded voices of OpenMATB are English or French. With voiceidiom=korean, the prompt is read by the browser
speech synthesis (web/korean_tts.js) with a Korean voice. TTSPlayer has the subset of the player API used by the
communications plugin: the prompt is over when `source` becomes None (so the response timer starts at the end of the
spoken message, as with the recorded voices).
"""

from __future__ import annotations

from typing import Any

import pyglet.clock

from core.platform import IS_WEB

KOREAN_IDIOM: str = "korean"
SPEECH_RATE: float = 1.0
LEAD_SILENCE: float = 2.0  # The recorded prompts start with 20 "empty" samples of 0.1 s

LETTERS: dict[str, str] = dict(
    zip(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "에이 비 씨 디 이 에프 지 에이치 아이 제이 케이 엘 엠 엔 오 피 큐 알 에스 티 유 브이 더블유 엑스 와이 제트".split(),
    )
)
DIGITS: dict[str, str] = dict(zip("0123456789", "공 하나 둘 삼 넷 오 여섯 칠 팔 아홉".split()))
RADIOS: dict[str, str] = {"NAV_1": "내브, 원", "NAV_2": "내브, 투", "COM_1": "컴, 원", "COM_2": "컴, 투"}


def say_chars(text: str) -> list[str]:
    return [LETTERS.get(c.upper(), DIGITS.get(c, c)) for c in text if not c.isspace()]


def prompt_text(callsign: str, radio_name: str, freq: float) -> str:
    """Every character is a separate word, so the voice pauses after each one, e.g.
    "에이치, 에스, 알, 둘, 오, 아홉, 에이치, 에스, 알, 둘, 오, 아홉, 무전기, 컴, 원, 주파수, 하나, 공, 아홉, 쩜, 삼." """
    call: list[str] = say_chars(callsign)
    digits: list[str] = ["쩜" if c == "." else DIGITS.get(c, c) for c in str(freq)]
    words: list[str] = call + call + ["무전기", RADIOS.get(radio_name.upper(), radio_name), "주파수"] + digits
    return ", ".join(words) + "."


def _tts() -> Any:
    import js  # type: ignore[import-not-found]

    return getattr(js.window, "KoreanTTS", None)


def voice_name() -> str:
    if not IS_WEB or _tts() is None:
        return ""
    return str(_tts().voiceName())


class TTSPlayer:
    def __init__(self, text: str, delay: float = LEAD_SILENCE) -> None:
        self.text: str = text
        self.delay: float = delay
        self.volume: float = 1.0
        self._id: Any = None
        self._playing: bool = False
        self._finished: bool = not IS_WEB or _tts() is None  # No speech synthesis: the prompt is over at once

    @property
    def source(self) -> Any:
        if self._finished:
            return None
        if self._id is not None and bool(_tts().isDone(self._id)):
            self._finished = True
            self._playing = False
            return None
        return self

    def play(self) -> None:
        if self._finished or self._playing:
            return
        self._playing = True
        pyglet.clock.schedule_once(self._speak, self.delay)

    def _speak(self, dt: float) -> None:
        if self._playing and not self._finished:
            self._id = _tts().speak(self.text, SPEECH_RATE)

    def pause(self) -> None:
        if self.source is None:  # Already spoken (nobody asked yet): nothing to read again
            return
        # Like the recorded prompts, a paused message is read again from its beginning
        self._playing = False
        pyglet.clock.unschedule(self._speak)
        if self._id is not None:
            self._id = None
            _tts().cancel()

    def delete(self) -> None:
        self.pause()
        self._finished = True
