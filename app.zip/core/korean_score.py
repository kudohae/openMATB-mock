# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): summary scores of the study session, shown as a result code to paste in a survey.

"""Score a session of includes/scenarios/korean/study.txt.

The scoring windows (scenario seconds) are read from the "# PHASES {...}" line of the scenario. Measures:
- Task 1 (A_main, tracking + communications) and task 2 (B_main): tracking, % of updates with the cursor in the target, and the
  RMS distance to the center (pixels, with the window height to normalise it)
- System monitoring (B_main): malfunctions handled by the participant (HIT by a human), by the automation, misses,
  false alarms, mean response time (ms); main criterion: the malfunctions the automation misses (B_sm_man_*)
- Communications (A_main and B_main): counts of each signal detection value and mean response time of the hits (ms,
  from the end of the spoken message)
- Resources management (B_main): % of time tanks A and B are within tolerance

result_code() returns "OM1-" + base64 of {"j": json, "c": checksum}: web/decode.html turns codes into a table.
"""

from __future__ import annotations

import base64
import csv
import json
import math
from pathlib import Path
from statistics import mean
from typing import Any

SCENARIO: Path = Path("includes/scenarios/korean/study.txt")
CODE_PREFIX: str = "OM1-"


def read_phases(scenario: Path = SCENARIO) -> dict[str, list[float]]:
    for line in scenario.read_text(encoding="utf-8").splitlines():
        if line.startswith("# PHASES "):
            return json.loads(line[len("# PHASES ") :])
    raise ValueError("No PHASES line in the scenario")


def read_failures(scenario: Path = SCENARIO) -> list[tuple[float, str, bool]]:
    """System monitoring malfunctions of the scenario: (onset in s, gauge name as displayed, automated or not)."""
    names: dict[str, str] = {}
    auto: bool = False
    failures: list[tuple[float, str, bool]] = []
    for line in scenario.read_text(encoding="utf-8").splitlines():
        parts: list[str] = line.split(";")
        if line.startswith("#") or len(parts) < 4 or parts[1] != "sysmon":
            continue
        h, m, sec = (int(x) for x in parts[0].split(":"))
        t: float = h * 3600 + m * 60 + sec
        if parts[2].endswith("-name"):
            names[parts[2][: -len("-name")]] = parts[3]
        elif parts[2] == "automaticsolver":
            auto = parts[3] == "True"
        elif parts[2].endswith("-failure"):
            gauge: str = parts[2][: -len("-failure")]
            failures.append((t, names.get(gauge, gauge), auto))
    return failures


def _float(value: str) -> float:
    try:
        return float(value)
    except ValueError:
        return float("nan")


def _r(x: float | None, digits: int = 2) -> float | None:
    return None if x is None or (isinstance(x, float) and math.isnan(x)) else round(x, digits)


def _mean(values: list[float]) -> float | None:
    values = [v for v in values if not math.isnan(v)]
    return mean(values) if values else None


def score_rows(
    rows: list[dict[str, str]], phases: dict[str, list[float]], failures: list[tuple[float, str, bool]]
) -> dict[str, Any]:
    def window(name: str) -> list[dict[str, str]]:
        start, end = phases[name]
        return [r for r in rows if start <= _float(r["scenario_time"]) < end]

    out: dict[str, Any] = {}
    env: dict[str, str] = {r["address"] or r["type"]: r["value"] for r in rows if r["type"] in ("browser", "os")}
    out["browser"] = env.get("browser", "")[:40]
    manual: list[str] = [r["value"] for r in rows if r["type"] == "manual"]
    out["voice"] = next((m.split(": ", 1)[1] for m in manual if m.startswith("Korean voice: ")), "")[:40]
    sizes = [r["value"].split("x") for r in rows if r["type"] == "window"]  # "1366x768"
    out["win_h"] = _r(_float(sizes[-1][-1]), 0) if sizes else None

    for phase, prefix in (("A_main", "A"), ("B_main", "B")):
        perf = [r for r in window(phase) if r["type"] == "performance" and r["module"] == "track"]
        inside = [r["value"] == "True" for r in perf if r["address"] == "cursor_in_target" and r["value"] in ("True", "False")]
        dev = [_float(r["value"]) for r in perf if r["address"] == "center_deviation"]
        dev = [d for d in dev if not math.isnan(d)]
        out[f"{prefix}_trk_in"] = _r(100 * sum(inside) / len(inside)) if inside else None
        out[f"{prefix}_trk_rms"] = _r(math.sqrt(sum(d * d for d in dev) / len(dev))) if dev else None

    block = window("B_main")

    # System monitoring: rows come by groups (name, signal_detection, response_time, resolved_by)
    sys_rows = [r for r in block if r["type"] == "performance" and r["module"] == "sysmon"]
    events: list[dict[str, str]] = []
    for r in sys_rows:
        if r["address"] == "name" or not events:
            events.append({"_time": r["scenario_time"]})
        events[-1][r["address"]] = r["value"]
    hits = [e for e in events if e.get("signal_detection") == "HIT" and e.get("resolved_by") == "human"]
    out["B_sm_hit"] = len(hits)
    out["B_sm_auto"] = sum(1 for e in events if e.get("signal_detection") == "HIT" and e.get("resolved_by") != "human")
    out["B_sm_miss"] = sum(1 for e in events if e.get("signal_detection") == "MISS")
    out["B_sm_fa"] = sum(1 for e in events if e.get("signal_detection") == "FA")
    out["B_sm_rt"] = _r(_mean([_float(e.get("response_time", "nan")) for e in hits]), 0)

    # Main criterion: the malfunctions the automation misses (automaticsolver off), handled by the participant.
    # The onset of a logged malfunction is its end minus its response time (or minus the 10 s timeout if missed).
    start, end = phases["B_main"]
    manual = [(t, name) for t, name, auto in failures if start <= t < end and not auto]
    man_hits: list[float] = []
    for e in events:
        if e.get("signal_detection") != "HIT" or e.get("resolved_by") != "human":
            continue
        rt = _float(e.get("response_time", "nan"))
        onset = _float(e.get("_time", "nan")) - rt / 1000
        if any(name == e.get("name") and abs(t - onset) < 1.5 for t, name in manual):
            man_hits.append(rt)
    out["B_sm_man_n"] = len(manual)
    out["B_sm_man_hit"] = len(man_hits)
    out["B_sm_man_rt"] = _r(_mean(man_hits), 0)

    # Communications: one sdt_value and one response_time per response or miss (task 1 and task 2)
    for phase, prefix in (("A_main", "A"), ("B_main", "B")):
        com = [r for r in window(phase) if r["type"] == "performance" and r["module"] == "communications"]
        sdt = [r["value"] for r in com if r["address"] == "sdt_value"]
        rts = [r["value"] for r in com if r["address"] == "response_time"]
        for value in ("HIT", "MISS", "FA", "BAD_RADIO", "BAD_FREQ", "BAD_RADIO_FREQ"):
            out[f"{prefix}_cm_{value.lower()}"] = sdt.count(value)
        out[f"{prefix}_cm_rt"] = _r(_mean([_float(rt) for s, rt in zip(sdt, rts) if s == "HIT"]), 0)

    # Resources management
    res = [r for r in block if r["type"] == "performance" and r["module"] == "resman"]
    for tank in ("a", "b"):
        flags = [r["value"] == "True" for r in res if r["address"] == f"{tank}_in_tolerance" and r["value"] in ("True", "False")]
        out[f"B_rm_{tank}"] = _r(100 * sum(flags) / len(flags)) if flags else None
    both = [x for x in (out["B_rm_a"], out["B_rm_b"]) if x is not None]
    out["B_rm"] = _r(mean(both)) if both else None

    # Pauses of the page (tab change) and freezes during the scored windows
    out["hidden"] = sum(1 for r in rows if r["type"] == "visibility" and r["value"] in ("hidden", "False"))
    out["pointer_lost"] = sum(1 for r in rows if r["type"] == "pointerlock_lost")
    out["freeze_ms"] = _r(sum(_float(r["value"]) for r in rows if r["type"] == "freeze"), 0)
    return out


def score_file(path: str | Path, scenario: Path = SCENARIO) -> dict[str, Any]:
    with open(path, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    result = score_rows(rows, read_phases(scenario), read_failures(scenario))
    result["file"] = Path(path).name
    return result


def fnv1a(text: str) -> str:
    h = 0x811C9DC5
    for ch in text:
        h ^= ord(ch)
        h = (h * 0x01000193) & 0xFFFFFFFF
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    out = ""
    while True:
        h, r = divmod(h, 36)
        out = digits[r] + out
        if h == 0:
            return out


def result_code(result: dict[str, Any]) -> str:
    text = json.dumps(result, ensure_ascii=True, separators=(",", ":"))
    payload = json.dumps({"j": text, "c": fnv1a(text)}, ensure_ascii=True, separators=(",", ":"))
    return CODE_PREFIX + base64.b64encode(payload.encode("ascii")).decode("ascii")
