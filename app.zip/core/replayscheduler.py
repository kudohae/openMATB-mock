# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

from bisect import bisect_right
from time import gmtime, strftime
from typing import Any

from pyglet.shapes import Circle, Line, Rectangle, Triangle
from pyglet.window import key

from core.constants import BFLIM, REPLAY_PERF_STRIP_PROPORTION, REPLAY_STRIP_PROPORTION
from core.constants import COLORS as C
from core.constants import FONT_SIZES as F
from core.constants import Group as G
from core.container import Container
from core.logger import get_logger
from core.logreader import LogReader
from core.perfoverlay import PerfOverlay
from core.scheduler import Scheduler
from core.utils import clamp, get_replay_session_id
from core.widgets import Frame, MuteButton, PlayPause, Reticle, SimpleHTML, Simpletext, Slider
from core.window import Window

CLOCK_STEP: float = 0.1

# Browser sessions: marks on the timeline where the page was hidden (scenario paused) or paused by the browser
HIDDEN_MARK_COLOR: tuple[int, int, int, int] = (240, 160, 60, 200)
FREEZE_MARK_COLOR: tuple[int, int, int, int] = (220, 50, 50, 230)


# The classic mouse pointer (an arrow), in pixels, y downwards from its tip; drawn 1.3 times larger
POINTER_OUTLINE: tuple[tuple[int, int], ...] = ((0, 0), (0, 17), (4, 13), (7, 20), (9, 19), (6, 12), (12, 12))
POINTER_TRIANGLES: tuple[tuple[int, int, int], ...] = ((0, 1, 2), (0, 2, 5), (0, 5, 6), (2, 3, 4), (2, 4, 5))
POINTER_SCALE: float = 1.3


class MousePointer:
    """The mouse pointer of the session, drawn in the replay (white arrow, black outline), its tip at (x, y)."""

    def __init__(self, x: float, y: float, batch: Any) -> None:
        self._fill: list[Any] = [
            Triangle(0, 0, 0, 0, 0, 0, color=(255, 255, 255), batch=batch, group=G(99)) for _ in POINTER_TRIANGLES
        ]
        n: int = len(POINTER_OUTLINE)
        self._outline: list[Any] = [
            Line(0, 0, 0, 0, thickness=1.2, color=(0, 0, 0), batch=batch, group=G(100)) for _ in range(n)
        ]
        self.x: float = x
        self.y: float = y
        self.move_to(x, y)

    def _points(self) -> list[tuple[float, float]]:
        return [(self.x + px * POINTER_SCALE, self.y - py * POINTER_SCALE) for px, py in POINTER_OUTLINE]

    @property
    def visible(self) -> bool:
        return self._fill[0].visible

    @visible.setter
    def visible(self, visible: bool) -> None:
        for shape in self._fill + self._outline:
            shape.visible = visible

    def move_to(self, x: float, y: float) -> None:
        self.x, self.y = x, y
        points: list[tuple[float, float]] = self._points()
        for triangle, (a, b, c) in zip(self._fill, POINTER_TRIANGLES):
            (triangle.x, triangle.y), (triangle.x2, triangle.y2), (triangle.x3, triangle.y3) = (
                points[a],
                points[b],
                points[c],
            )
        for i, line in enumerate(self._outline):
            (line.x, line.y), (line.x2, line.y2) = points[i], points[(i + 1) % len(points)]


class ReplayScheduler(Scheduler):
    """
    This class manages events execution in the context of the OpenMATB replay.
    """

    def __init__(self, session_path: str | None = None) -> None:
        self.logreader: LogReader | None = None
        self._session_path: str | None = session_path
        self.target_time: float = 0
        self.replay_time: float = 0
        self._executed_key_indices: set[int] = set()
        self.keys_history: list[str] = []
        self._muted: bool = True
        self._click_marker: Circle | None = None
        self._click_held: bool = False
        self._pointer_marker: MousePointer | None = None  # The mouse pointer of the session
        self._last_mouse_x: int | None = None
        self._last_mouse_y: int | None = None
        self._perf_overlay: PerfOverlay | None = None

        self.set_media_buttons()

        self.set_inputs_buttons()

        Window.MainWindow.on_key_press = self.on_key_press_replay

        # Init is done after UX is set
        super().__init__()

        self.is_paused: bool = True

    def set_scenario(self) -> None:
        need_new_logreader: bool = False

        if self._session_path is not None:
            # Direct path from file selector
            need_new_logreader = self.logreader is None
        else:
            # Legacy: look up by session ID
            replay_session_id: int = get_replay_session_id()
            need_new_logreader = self.logreader is None or replay_session_id != self.logreader.replay_session_id

        if need_new_logreader:
            if self._session_path is not None:
                self.logreader = LogReader(session_path=self._session_path)
            else:
                self.logreader = LogReader(replay_session_id)
            # Pre-compute sorted time arrays for O(log n) bisect lookup
            self._key_times: list[float] = [float(i["scenario_time"]) for i in self.logreader.keyboard_inputs]
            self._joy_times: list[float] = [float(i["scenario_time"]) for i in self.logreader.joystick_inputs]
            self._state_times: list[float] = [float(i["scenario_time"]) for i in self.logreader.states]
            # Logtime-based arrays for replay_time lookup
            self._key_logtimes: list[float] = [i["normalized_logtime"] for i in self.logreader.keyboard_inputs]
            self._joy_logtimes: list[float] = [i["normalized_logtime"] for i in self.logreader.joystick_inputs]
            self._mouse_logtimes: list[float] = [i["normalized_logtime"] for i in self.logreader.mouse_inputs]
            self._state_logtimes: list[float] = [i["normalized_logtime"] for i in self.logreader.states]

        super().set_scenario(self.logreader.contents)

        # Create performance overlay if data is available
        if self._perf_overlay is None:
            perfstrip_container: Container | None = Window.MainWindow.get_container("perfstrip")
            if perfstrip_container is not None and self.logreader.perf_series:
                self._perf_overlay = PerfOverlay(
                    perfstrip_container,
                    Window.MainWindow.batch,
                    self.logreader.perf_series,
                    self.logreader.duration_sec,
                )

        self.sliding: bool = False

        self.slider.value_max = self.logreader.session_duration
        if need_new_logreader:
            self.set_page_events_display()

        self.pause_playback()

    # ---- Browser sessions: browser, page hidden (scenario paused), pauses of the page ----

    def set_page_events_display(self) -> None:
        """Show the browser of the session, mark on the timeline when the page was hidden or paused by the
        browser, and prepare the notice displayed over the tasks while the page was hidden."""
        environment: dict[str, str] = self.logreader.environment
        browser: str = environment.get("browser", "").split(".")[0]  # "Chrome 153.0.0.0" -> "Chrome 153"
        text: str = "\n".join(v for v in (browser, environment.get("os")) if v)
        if text:
            input_container: Container = Window.MainWindow.get_container("inputstrip")
            label_container: Container = input_container.reduce_and_translate(width=0.9, height=0.07, y=0.73, x=0.5)
            self.environment_label: Simpletext = Simpletext(
                "replay_environment", label_container, text=text, font_size=F["SMALL"], color=C["BLACK"]
            )
            self.environment_label.show()

        self.timeline_marks: list[Any] = self.create_timeline_marks()

        notice_container: Container = Window.MainWindow.get_container("fullscreen").reduce_and_translate(
            width=0.6, height=0.08, x=0.5, y=0.92
        )
        self.page_notice_back: Frame = Frame(
            "page_notice_back",
            notice_container,
            fill_color=C["WHITE"],
            border_color=C["RED"],
            border_thickness=0.05,
            draw_order=BFLIM + 20,
        )
        self.page_notice: Simpletext = Simpletext(
            "page_notice", notice_container, text="", draw_order=BFLIM + 21, color=C["RED"], bold=True
        )
        self._page_notice_text: str | None = None

    def create_timeline_marks(self) -> list[Any]:
        """Rectangles over the timeline: page hidden (until the scenario resumed) and pauses of the page."""
        duration: float = self.logreader.session_duration
        if duration <= 0:
            return []
        groove: Container = self.slider.containers["allgroove"]
        height: float = groove.h * 2.5
        y: float = groove.cy - height / 2

        def x_of(replay_time: float) -> float:
            return groove.l + clamp(replay_time / duration, 0, 1) * groove.w

        periods: list[tuple[float, float, tuple[int, int, int, int]]] = [
            (hidden, resumed, HIDDEN_MARK_COLOR) for hidden, _visible, resumed in self.logreader.hidden_periods
        ] + [(start, start + length, FREEZE_MARK_COLOR) for start, length in self.logreader.freezes]
        marks: list[Any] = []
        for start, end, color in periods:
            mark = Rectangle(
                x=x_of(start),
                y=y,
                width=max(x_of(end) - x_of(start), 2),
                height=height,
                color=color,
                batch=Window.MainWindow.batch,
                group=G(self.slider.draw_order + self.slider.rank - 0.5),  # Under the slider handle
            )
            marks.append(mark)
        return marks

    def page_notice_at(self, replay_time: float) -> str | None:
        for hidden, visible, resumed in self.logreader.hidden_periods:
            if hidden <= replay_time < visible:
                return _("Page hidden (tab change or minimized window): session paused")
            if visible <= replay_time < resumed:
                return _("Session paused (pause dialog after the page was hidden)")
        return None

    def update_page_notice(self) -> None:
        if not hasattr(self, "page_notice"):
            return
        text: str | None = self.page_notice_at(self.replay_time)
        if text == self._page_notice_text:
            return
        self._page_notice_text = text
        if text is None:
            self.page_notice.hide()
            self.page_notice_back.hide()
        else:
            self.page_notice.set_text(text)
            self.page_notice_back.show()
            self.page_notice.show()

    def set_inputs_buttons(self) -> None:
        # Plot the keyboard keys that are available in the present plugins
        input_container: Container = Window.MainWindow.get_container("inputstrip")
        # Under the joystick view (top), the mouse position and the browser of the session (0.70 to 0.76)
        key_container: Container = input_container.reduce_and_translate(width=0.9, height=0.66, y=0, x=0.5)
        # The text is centered in its area: keep the lines that fit in it (about 24 px each), whatever the screen
        self._max_keys_history: int = max(5, int(key_container.h / 24) - 1)
        self.key_widget: SimpleHTML = SimpleHTML("replay_keys", key_container, "<strong>Keyboard history:\n</strong>")
        self.key_widget.show()

    def set_media_buttons(self) -> None:
        # Media strip
        media_container: Container = Window.MainWindow.get_container("mediastrip")
        self.media_back: Frame = Frame("media_background", media_container, fill_color=C["DARKGREY"], draw_order=1)
        self.media_back.show()
        pp_container: Container = media_container.reduce_and_translate(width=0.06, height=1, x=0)
        time_container: Container = media_container.reduce_and_translate(width=0.03, height=1, x=0.78)

        self.playpause: PlayPause = PlayPause("Play_pause_button", pp_container, self.toggle_playpause)
        self.time: Simpletext = Simpletext(
            "elapsed_time", time_container, text="", font_size=F["LARGE"], color=C["WHITE"]
        )

        margin: int = 10
        btn_w: float = media_container.h * 1.8
        pad_b: int = 4
        mute_container: Container = Container(
            "mute_btn",
            Window.MainWindow.width - margin - btn_w,
            media_container.b + pad_b,
            btn_w,
            media_container.h - 2 * pad_b,
        )
        self.mute_button: MuteButton = MuteButton("mute_button", mute_container, self.toggle_mute)

        self.slider: Slider = Slider("timeline", media_container, None, "", "", 0, 1, 0, 1)
        self.time.show()

        # Inputs strip
        input_container: Container = Window.MainWindow.get_container("inputstrip")
        self.inputs_back: Frame = Frame("inputs_background", input_container, fill_color=C["LIGHTGREY"], draw_order=1)
        self.inputs_back.show()

        # Manually compute the joystick container to ensure it is a square
        w: float = input_container.w * 0.8
        h: float = w
        l: float = input_container.l + 0.1 * input_container.w
        b: float = input_container.b + 0.85 * input_container.h
        joy_container: Container = Container("replay_reticle", l, b, w, h)
        self.replay_reticle: Reticle = Reticle(
            "replay_reticle", joy_container, C["BLACK"], target_proportion=0, m_draw=5
        )
        self.replay_reticle.show()

        mouse_container: Container = input_container.reduce_and_translate(width=0.9, height=0.05, y=0.82, x=0.5)
        self.mouse_label: Simpletext = Simpletext(
            "replay_mouse", mouse_container, text="Mouse: --", font_size=F["SMALL"], color=C["BLACK"]
        )
        self.mouse_label.show()

    def on_key_press_replay(self, symbol: int, modifier: int) -> None:
        if symbol == key.F12:
            Window.MainWindow.take_screenshot()
            return
        elif symbol == key.ESCAPE:
            Window.MainWindow.exit_prompt()
        elif symbol == key.SPACE:
            self.toggle_playpause()
        elif symbol == key.HOME:
            self.set_target_time(0)
        elif symbol == key.END:
            self.set_target_time(self.logreader.session_duration)
        elif symbol == key.LEFT:
            self.set_target_time(self.replay_time - 0.1)
        elif symbol == key.RIGHT:
            self.set_target_time(self.replay_time + 0.1)
        elif symbol == key.UP:
            self.clock.increase_speed()
        elif symbol == key.DOWN:
            self.clock.decrease_speed()
        elif symbol == key.M:
            self.toggle_mute()

    def update_timers(self, dt: float) -> None:
        # Derive scenario_time from the replay_time -> scenario_time mapping.
        # The mapping handles blocking segments (slope=0) automatically.
        self.scenario_time = self.logreader.replay_to_scenario_time(self.replay_time)
        get_logger().set_scenario_time(self.scenario_time)

        # In the session, a key logged before this update was handled before the plugin steps of this update
        # (a key pressed between two updates, or an agent key sent at the start of a plugin step): replay it
        # before them too, not after (a resman step lasts 2 s: a pump toggled after it missed a whole step).
        # Same deferral as in update(): the events still queued come first.
        if not (len(self.events_queue) > 0 and not self.is_scenario_time_paused()):
            self.emulate_keyboard_inputs()

    def update(self, dt: float) -> None:
        self.pause_if_end_reached()
        self.update_time_string()
        self.slider_control_update()
        self.update_page_notice()

        if not self.is_paused:
            dt = min(dt, self.target_time - self.replay_time)

            if dt > 0:
                self.replay_time += dt
                super().update(dt)  # update_timers (mapping) + execute_events
                if self.clock.isFastForward:
                    self.execute_due_events()
        else:
            # Required: check exit while paused (super().update is not called)
            self.check_if_must_exit()

        # Defer input emulation while queued events can still be processed.
        # When scenario_time is paused (blocking plugin active), events in the
        # queue cannot fire, so we must allow keyboard emulation to proceed
        # (e.g. SPACE to advance instruction slides).
        if len(self.events_queue) > 0 and not self.is_scenario_time_paused():
            return

        self.emulate_keyboard_inputs()
        self.display_joystick_inputs()
        self.display_mouse_inputs()
        self.process_states()
        self._enforce_mute()

        if self._perf_overlay is not None:
            st: float = self.logreader.replay_to_scenario_time(self.replay_time)
            self._perf_overlay.update_cursor(st)

    def execute_due_events(self) -> None:
        """Fast-forward (seek): execute all the events due at the reached time.

        An update executes one event, and a fast-forward step lasts 0.1 s: events at the same time
        (e.g. the stop of every task at the end of the session) were not all executed by a seek.
        Stops when a blocking plugin (instructions, questionnaire) pauses the scenario, as in playback.
        """
        for _ in range(len(self.events_queue) + len(self.events)):
            if len(self.events_queue) == 0 or self.is_scenario_time_paused():
                return
            self.execute_events()

    def check_plugins_alive(self) -> bool:
        return all([p.alive for _, p in self.plugins.items()])

    def check_if_must_exit(self) -> None:
        # In replay mode, exit conditions are differents. Exit only if the Window is killed.
        if not Window.MainWindow.alive:
            self.exit()

    def update_time_string(self) -> None:
        time_str: str = self.get_time_hms_str()
        self.time.set_text(time_str)

    def get_time_hms_str(self) -> str:
        # round to prevent displaying time as 0.099 instead of 0.1
        timesec: float = round(self.replay_time, 2)

        t: str = strftime("%H:%M:%S", gmtime(timesec))
        ms: float = timesec % 1 * 1000

        return "%s.%03d" % (t, ms)

    def pause_if_end_reached(self) -> None:
        if self.replay_time >= self.logreader.session_duration and not self.is_paused:
            # An update executes one event: at a faster speed, the end is reached before the last simultaneous
            # events (e.g. the stop of every task) were all executed
            self.execute_due_events()
            self.pause_playback()

    def pause_playback(self) -> None:
        self.is_paused = True
        self.playpause.update_button_sprite(True)

    def resume_playback(self) -> None:
        self.is_paused = False
        self.playpause.update_button_sprite(False)

    def toggle_mute(self) -> None:
        self._muted = not self._muted
        self.mute_button.update_mute_state(self._muted)
        self._enforce_mute()

    def _enforce_mute(self) -> None:
        if "communications" in self.plugins:
            player: Any = getattr(self.plugins["communications"], "player", None)
            if player is not None:
                player.volume = 0.0 if self._muted else 1.0

    def toggle_playpause(self) -> None:
        if self.is_paused:
            # If at the end, restart from beginning
            if self.replay_time >= self.logreader.session_duration:
                self.set_target_time(0)
            self.resume_playback()
            self.target_time = self.logreader.session_duration
        else:
            self.pause_playback()
            self.target_time = self.replay_time

    def slider_control_update(self) -> None:
        # At THE FIRST slider mouse press, save the play/pause state, then pause
        if self.slider.hover and not self.sliding:
            self.sliding = True
            self._was_paused_before_slide: bool = self.is_paused
            self.pause_playback()

        # Update the position of the slider if replay time changed (only when not interacting)
        if self.slider.groove_value != self.replay_time and not self.sliding:
            self.slider.groove_value = self.replay_time
            self.slider.set_groove_position()

        # At THE FIRST slider mouse release, navigate to the selected time
        # then restore the previous play/pause state
        if not self.slider.hover and self.sliding:
            self.sliding = False
            self.set_target_time(self.slider.groove_value)
            if not self._was_paused_before_slide:
                self.resume_playback()
                self.target_time = self.logreader.session_duration

    def pause_if_clock_target_reached(self) -> None:
        # Soon as the clock target is reached, control if the scenario must switch back to pause
        if self.clock.is_target_time_reached():
            self.clock.remove_target_time()
            self.pause_playback()

    def set_target_time(self, target_time: float) -> None:
        # We are already changing time, do not reenter this method
        if self.clock.isFastForward:
            return

        # clamp desired time
        self.target_time = clamp(target_time, 0, self.logreader.session_duration)

        # already on the right time
        if self.target_time == self.replay_time:
            self.pause_playback()
            return

        # backward in time, we reload everything, reset, and move forward
        if self.target_time < self.replay_time:
            self.restart_scenario()
            self.replay_time = 0

        forward_time: float = self.target_time - self.replay_time

        # Resuming is required as we want the clock to update the scheduler
        if forward_time > 0:
            self.resume_playback()
            self.clock.fastforward_time(forward_time)

        # After seeking: clean up blocking plugins/dialogs past their segment
        self._cleanup_after_seek()

        self.slider.set_groove_position()
        self.pause_playback()

    def _cleanup_after_seek(self) -> None:
        """Clean up stale blocking state after a seek (fastforward).

        Handles two cases:
        1. A BlockingPlugin (instructions, genericscales) still active after
           replay_time has moved past its blocking segment.
        2. A ModalDialog (system;pause) still showing after a seek.
        """
        # Case 1: stale blocking plugin
        active_blocking: Any = self.get_active_blocking_plugin()
        if active_blocking is not None:
            if not self.logreader.is_in_blocking_segment(self.replay_time):
                active_blocking.stop()
                if self.is_scenario_time_paused():
                    if len(self.paused_plugins) > 0:
                        self.execute_plugins_methods(self.paused_plugins, methods=["show", "resume"])
                        self.paused_plugins = list()
                    self.resume_scenario()

        # Case 2: stale modal dialog (system;pause)
        if Window.MainWindow.modal_dialog is not None:
            Window.MainWindow.modal_dialog.on_delete()

    def restart_scenario(self) -> None:
        # we need to suspend the clock as it schedules old events
        self.clock.unschedule(self.update)

        self._executed_key_indices = set()
        self.keys_history = []
        self._last_mouse_x = None
        self._last_mouse_y = None
        self._click_held = False
        self._last_joy_x = None
        self._last_joy_y = None
        self.mouse_control_enabled = False  # The events are executed again from the start
        if self._click_marker is not None:
            self._click_marker.visible = False
            self._click_marker = None
        self.clock.set_time(0)
        self.clock.tick()
        self.scenario_time = 0
        self.replay_time = 0
        self.slider.groove_value = 0
        self.slider.set_groove_position()
        self.scenario.reload_plugins()
        self.set_scenario()

        self.clock.schedule(self.update)

    def emulate_keyboard_inputs(self) -> None:
        lo: int = bisect_right(self._key_logtimes, self.replay_time - CLOCK_STEP)
        hi: int = bisect_right(self._key_logtimes, self.replay_time)

        for idx in range(lo, hi):
            if idx not in self._executed_key_indices:
                self._executed_key_indices.add(idx)
                input: dict[str, Any] = self.logreader.keyboard_inputs[idx]
                human: bool = input.get("module") != "agent"
                for _plugin_name, plugin in self.plugins.items():
                    # In the session, the keys of a human did nothing on a task under the automatic solver
                    # (unless its agent accepts them): the replay must not execute them either
                    if human and plugin.parameters.get("automaticsolver"):
                        if not getattr(getattr(plugin, "agent", None), "allows_human_input", False):
                            continue
                    plugin.do_on_key(input["address"], input["value"], True)

                cmd: str = f"{input['address']} ({input['value']})"
                if len(self.keys_history) == 0 or cmd != self.keys_history[-1]:
                    self.keys_history.append(cmd)
                if len(self.keys_history) > getattr(self, "_max_keys_history", 30):
                    del self.keys_history[0]

        history_str: str = "<strong>Keyboard history:\n</strong>" + "<br>".join(self.keys_history)
        self.key_widget.set_text(history_str)

    def process_states(self) -> None:
        # States are displayed as a function of replay time (logtime-based).
        # It does not matter to display each and every states. Better is to catch
        # the most current one. The following states are manually handled:
        #   - 1. The cursor position in the tracking task
        #   - 2. The frequency of each communications radio
        #   - 3. The value of each slider, in genericscales
        #   - 4. The level of each resman tank (the replay simulates the tanks, but its plugin steps are not at
        #        the same times as in the session: a pump toggled just before a step of the session may come
        #        just after the step of the replay, and change a whole step of flow)

        lo: int = bisect_right(self._state_logtimes, self.replay_time - CLOCK_STEP)
        hi: int = bisect_right(self._state_logtimes, self.replay_time)

        for idx in range(lo, hi):
            state: dict[str, Any] = self.logreader.states[idx]

            # 1. Cursor position
            if "cursor_proportional" in state["address"] and "track" in self.plugins:
                track = self.plugins["track"]
                if not hasattr(track, "reticle"):
                    continue
                cursor_relative: tuple[float, float] = track.reticle.proportional_to_relative(state["value"])
                track.cursor_position = cursor_relative

            # 2. Radio frequencies
            elif "radio_frequency" in state["address"] and "communications" in self.plugins:
                radio_name: str = state["address"].replace(", radio_frequency", "").replace("radio_", "")
                radio: dict[str, Any] = self.plugins["communications"].get_radios_by_key_value("name", radio_name)[0]
                radio["currentfreq"] = state["value"]

            # 3. Genericscales slider values
            elif "slider_" in state["address"] and "genericscales" in self.plugins:
                slider_name: str = state["address"].replace(", value", "")
                slider: Any = self.plugins["genericscales"].sliders[slider_name]
                slider.groove_value = state["value"]
                slider.set_groove_position()

            # 4. Resources management tank levels
            elif "fluid_level" in state["address"] and "resman" in self.plugins:
                letter: str = state["address"].split(",")[0].replace("tank_", "")
                tank: dict[str, Any] | None = self.plugins["resman"].parameters["tank"].get(letter)
                if tank is not None:
                    tank["level"] = state["value"]

    def session_mouse_visible(self) -> bool:
        """The mouse was shown in the session only with a scale slider or under mouse control (is_mouse_necessary):
        the replay window, which always needs the mouse (and has its own slider), cannot say it"""
        if self.mouse_control_enabled:
            return True
        return any(
            isinstance(widget, Slider) and widget.visible
            for plugin in self.plugins.values()
            for widget in plugin.widgets.values()
        )

    def _remap_mouse(self, x: int, y: int) -> tuple[int, int]:
        """Remap the coordinates of the session window to the reduced replay area. The session window may have
        another size than the replay one (e.g. a page of the browser, without its toolbars)."""
        width, height = Window.MainWindow.width, Window.MainWindow.height
        size: Any = getattr(getattr(self, "logreader", None), "window_size", None)
        session_width, session_height = size if isinstance(size, tuple) else (width, height)
        area_width: float = width * (1 - REPLAY_STRIP_PROPORTION)
        area_height: float = height * (1 - REPLAY_STRIP_PROPORTION - REPLAY_PERF_STRIP_PROPORTION)
        replay_x: int = int(x / session_width * area_width)
        replay_y: int = int(y / session_height * area_height + height * REPLAY_STRIP_PROPORTION)
        return replay_x, replay_y

    def display_mouse_inputs(self) -> None:
        lo: int = bisect_right(self._mouse_logtimes, self.replay_time - CLOCK_STEP)
        hi: int = bisect_right(self._mouse_logtimes, self.replay_time)

        for idx in range(lo, hi):
            mouse_input: dict[str, Any] = self.logreader.mouse_inputs[idx]
            if mouse_input["address"] == "x":
                self._last_mouse_x = int(float(mouse_input["value"]))
            elif mouse_input["address"] == "y":
                self._last_mouse_y = int(float(mouse_input["value"]))
            elif mouse_input["address"] == "click":
                parts: list[str] = mouse_input["value"].split(";")
                action: str = parts[0]
                cx, cy = int(float(parts[1])), int(float(parts[2]))
                rx, ry = self._remap_mouse(cx, cy)
                if action == "press":
                    self._click_held = True
                    if self._click_marker is not None:
                        self._click_marker.visible = False
                    self._click_marker = Circle(
                        x=rx,
                        y=ry,
                        radius=12,
                        color=(40, 180, 40),
                        batch=Window.MainWindow.batch,
                        group=G(99),
                    )
                    self._click_marker.opacity = 180
                else:
                    self._click_held = False
                    if self._click_marker is not None:
                        self._click_marker.visible = False
                        self._click_marker = None

        # Move the marker with the cursor while held
        if self._click_held and self._click_marker is not None:
            if self._last_mouse_x is not None and self._last_mouse_y is not None:
                rx, ry = self._remap_mouse(self._last_mouse_x, self._last_mouse_y)
                self._click_marker.x = rx
                self._click_marker.y = ry

        # Update cursor position when we have coordinates
        if self._last_mouse_x is not None and self._last_mouse_y is not None:
            rx, ry = self._remap_mouse(self._last_mouse_x, self._last_mouse_y)
            # The pointer of the session is drawn: moving the real mouse pointer kept it in the replay (the user
            # could not use the play bar), and a page cannot move it (no set_mouse_position in the browser)
            if self._pointer_marker is None:
                self._pointer_marker = MousePointer(rx, ry, Window.MainWindow.batch)
            elif (self._pointer_marker.x, self._pointer_marker.y) != (rx, ry):
                self._pointer_marker.move_to(rx, ry)
            visible: bool = self.session_mouse_visible()
            if self._pointer_marker.visible != visible:
                self._pointer_marker.visible = visible

        label: str = "Mouse: "
        if self._last_mouse_x is not None and self._last_mouse_y is not None:
            label += f"{self._last_mouse_x}, {self._last_mouse_y}"
        else:
            label += "--"

        if self._click_held:
            label += " [held]"

        self.mouse_label.set_text(label)

    def display_joystick_inputs(self) -> None:
        # The last position is kept: the joystick logs an axis only when it changes
        x: float | None = getattr(self, "_last_joy_x", None)
        y: float | None = getattr(self, "_last_joy_y", None)
        lo: int = bisect_right(self._joy_logtimes, self.replay_time - CLOCK_STEP)
        hi: int = bisect_right(self._joy_logtimes, self.replay_time)

        for idx in range(lo, hi):
            joy_input: dict[str, Any] = self.logreader.joystick_inputs[idx]
            address: str = joy_input["address"]

            if address == "joystick":  # An agent: "x,y"
                x, y = (float(v) for v in str(joy_input["value"]).split(","))
            elif address in ("x", "joystick_x") or address.endswith("_x"):
                x = float(joy_input["value"])
            elif address in ("y", "joystick_y") or address.endswith("_y"):
                y = float(joy_input["value"])

        self._last_joy_x, self._last_joy_y = x, y
        if x is not None and y is not None:
            # The axes are in [-1, 1], y downwards (as the tracking task reads them): the view expects a position
            # proportional to its size, in [-0.5, 0.5], y upwards (a full axis put the cursor out of the view)
            proportional: tuple[float, float] = (clamp(x, -1, 1) / 2, -clamp(y, -1, 1) / 2)
            rel_x, rel_y = self.replay_reticle.proportional_to_relative(proportional)
            self.replay_reticle.set_cursor_position(rel_x, rel_y)
