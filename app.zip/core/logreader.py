# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)

from __future__ import annotations

import ast
import csv
from bisect import bisect_right
from pathlib import Path
from typing import Any

from core.constants import PATHS as P
from core.error import get_errors
from core.event import Event

# Some plugins must not be replayed for now
IGNORE_PLUGINS: list[str] = ["labstreaminglayer", "parallelport"]

# Minimum logtime span (seconds) for a frozen scenario_time group to be
# considered a blocking segment (filters out simultaneous events).
BLOCKING_THRESHOLD: float = 0.5


class LogReader:
    """
    The log reader takes a session file as input and is able to return its entries depending on
    their onset time. Relevant entries are scenario events and user inputs, which are combined to
    simulate what happened during the session.
    """

    def __init__(self, replay_session_id: int | None = None, session_path: str | None = None) -> None:
        self.session_file_path: Path | None = None
        self.replay_session_id: int | None = replay_session_id

        if session_path is not None:
            # Direct path provided (from file selector)
            self.session_file_path = Path(session_path)
            try:
                self.replay_session_id = int(self.session_file_path.stem.split("_")[0])
            except (ValueError, IndexError):
                pass
        else:
            # Look up by session ID
            session_file_list: list[Path] = [f for f in P["SESSIONS"].glob(f"**/{replay_session_id}_*.csv")]

            if len(session_file_list) == 0:
                msg = _("The desired session file (ID=%s) does not exist") % replay_session_id
                get_errors().add_error(msg, fatal=True)
            elif len(session_file_list) > 1:
                get_errors().add_error(
                    _("Multiple session files match the desired session ID (%s)") % replay_session_id, fatal=True
                )
            elif len(session_file_list) == 1:
                self.session_file_path = session_file_list[0]

        self.contents: list[str] = []
        self.inputs: list[dict[str, Any]] = []
        self.states: list[dict[str, Any]] = []
        self.start_sec: float = 0
        self.end_sec: float = 0
        self.duration_sec: float = 0
        self.session_duration: float = 0
        self.line_n: int = 0
        self.keyboard_inputs: list[dict[str, Any]] = []
        self.joystick_inputs: list[dict[str, Any]] = []
        self.mouse_inputs: list[dict[str, Any]] = []
        self.blocking_segments: list[tuple[float, float, float]] = []
        self._bp_replay_times: list[float] = [0.0]
        self._bp_scenario_times: list[float] = [0.0]
        self.perf_rows: list[dict[str, Any]] = []
        self.perf_series: dict[str, list[tuple[float, dict[str, str]]]] = {}
        # Browser sessions only (see _read_page_events)
        self.environment: dict[str, str] = {}
        self.window_size: tuple[float, float] | None = None
        self.hidden_periods: list[tuple[float, float, float]] = []
        self.freezes: list[tuple[float, float]] = []

        self.reload_session()

    def reload_session(self) -> None:
        if self.session_file_path is None:
            return

        self.contents, self.inputs, self.states = [], [], []
        self.start_sec, self.end_sec, self.duration_sec = 0, 0, 0
        self.session_duration = 0
        self.line_n = 0
        self.keyboard_inputs = []
        self.joystick_inputs = []
        self.mouse_inputs = []
        self.blocking_segments = []
        self._bp_replay_times = [0.0]
        self._bp_scenario_times = [0.0]
        self.perf_rows = []
        self.perf_series = {}
        self.environment = {}
        self.hidden_periods = []
        self.freezes = []

        # First pass: read all rows
        all_rows: list[dict[str, Any]] = []
        with open(self.session_file_path, newline="", encoding="utf-8") as csvfile:
            reader: csv.DictReader = csv.DictReader(csvfile)
            for row in reader:
                # Skip a row without valid times (e.g. the last row of a session that crashed while writing it)
                try:
                    row["logtime"] = float(row["logtime"])
                    row["scenario_time"] = float(row["scenario_time"])
                except (TypeError, ValueError):
                    continue
                all_rows.append(row)

        if not all_rows:
            return

        # Capture first logtime for normalization
        first_logtime: float = all_rows[0]["logtime"]
        for row in all_rows:
            row["normalized_logtime"] = row["logtime"] - first_logtime

        # Detect blocking segments and build replay-to-scenario mapping
        self._detect_blocking_segments(all_rows)
        self._build_replay_mapping(all_rows)

        # Session duration based on logtime (includes blocking periods)
        self.session_duration = all_rows[-1]["normalized_logtime"]
        self._read_page_events(all_rows)
        self.window_size = self._read_window_size(all_rows)

        # Second pass: process rows (skip first row as before)
        for row in all_rows[1:]:
            if row["module"] in IGNORE_PLUGINS:
                continue

            # Event case
            if row["type"] == "event":
                self.contents.append(self.session_event_to_str(row))

            # Input case
            elif row["type"] == "input":
                self.inputs.append(row)
                # The joystick axes: of the joystick (x, y), or of an agent (address "joystick", value "x,y")
                if row["module"] == "joystick" or "joystick" in row["address"]:
                    self.joystick_inputs.append(row)
                # The keys: keyboard, agent, mouse clicks on a task, joystick buttons (module "Joystick")
                elif row["module"] in ("keyboard", "agent", "mouse_key", "Joystick"):
                    self.keyboard_inputs.append(row)
                elif row["module"] == "mouse":
                    self.mouse_inputs.append(row)

            # State case
            elif row["type"] == "state":
                # Record communications radio frequencies, track cursor positions, questionnaire sliders
                # AND resman tank levels
                if (
                    "radio_frequency" in row["address"]
                    or "cursor_proportional" in row["address"]
                    or "slider_" in row["address"]
                    or "fluid_level" in row["address"]
                ):
                    row["value"] = ast.literal_eval(row["value"])
                    self.states.append(row)

            # Performance case
            elif row["type"] == "performance":
                self.perf_rows.append(row)

        # The last row browsed contains the ending time
        self.end_sec = all_rows[-1]["scenario_time"]
        self.duration_sec = self.end_sec - self.start_sec
        self._index_performance_data()

    def _index_performance_data(self) -> None:
        """Group performance rows by module and scenario_time into sorted series."""
        from collections import defaultdict

        # Group by (module, scenario_time) → {address: value}
        grouped: dict[str, dict[float, dict[str, str]]] = defaultdict(lambda: defaultdict(dict))
        for row in self.perf_rows:
            module: str = row["module"]
            t: float = row["scenario_time"]
            grouped[module][t][row["address"]] = row["value"]

        # Convert to sorted lists
        self.perf_series = {}
        for module, time_dict in grouped.items():
            self.perf_series[module] = sorted(time_dict.items(), key=lambda x: x[0])

    def _detect_blocking_segments(self, all_rows: list[dict[str, Any]]) -> None:
        """Identify periods where scenario_time is frozen while logtime advances."""
        self.blocking_segments = []

        if len(all_rows) < 2:
            return

        # Group consecutive rows with the same scenario_time
        current_st: float = all_rows[0]["scenario_time"]
        current_start_lt: float = all_rows[0]["normalized_logtime"]
        current_end_lt: float = all_rows[0]["normalized_logtime"]

        for row in all_rows[1:]:
            if abs(row["scenario_time"] - current_st) < 0.01:
                current_end_lt = row["normalized_logtime"]
            else:
                if current_end_lt - current_start_lt > BLOCKING_THRESHOLD:
                    self.blocking_segments.append((current_start_lt, current_end_lt, current_st))
                current_st = row["scenario_time"]
                current_start_lt = row["normalized_logtime"]
                current_end_lt = row["normalized_logtime"]

        # Handle the last group
        if current_end_lt - current_start_lt > BLOCKING_THRESHOLD:
            self.blocking_segments.append((current_start_lt, current_end_lt, current_st))

    def _build_replay_mapping(self, all_rows: list[dict[str, Any]] | None = None) -> None:
        """Build breakpoints (replay_time, scenario_time) for the replay_time -> scenario_time mapping.

        The breakpoints are the start and end of the blocking segments, and the first row logged at each scenario
        time: the scenario time does not start with the log (the first rows are written before the scenario
        starts, while the tasks are created), and it stops for pauses shorter than BLOCKING_THRESHOLD. Without
        these anchors, the replayed inputs (placed by logtime) were shifted from the events (placed by
        scenario_time), e.g. by the ~0.2 s of the start.
        """
        points: list[tuple[float, float]] = [(0.0, 0.0)]
        for lt_start, lt_end, frozen_st in self.blocking_segments:
            points += [(lt_start, frozen_st), (lt_end, frozen_st)]
        last_st: float | None = None
        for row in all_rows or []:
            if row["scenario_time"] != last_st:
                points.append((row["normalized_logtime"], row["scenario_time"]))
                last_st = row["scenario_time"]
        points.sort()
        self._bp_replay_times = [lt for lt, _st in points]
        self._bp_scenario_times = [st for _lt, st in points]

    def replay_to_scenario_time(self, replay_time: float) -> float:
        """Convert replay_time (normalized logtime) to scenario_time.

        From a breakpoint the scenario time advances with the replay time (slope 1), up to the scenario time of
        the next breakpoint (slope 0 in a blocking segment, whose two ends have the same scenario time).
        Uses an O(log k) bisect lookup, k being the number of breakpoints.
        """
        idx: int = bisect_right(self._bp_replay_times, replay_time) - 1
        if idx < 0:
            return 0.0

        scenario_time: float = self._bp_scenario_times[idx] + (replay_time - self._bp_replay_times[idx])
        if idx + 1 < len(self._bp_replay_times):
            scenario_time = min(scenario_time, self._bp_scenario_times[idx + 1])
        return scenario_time

    @staticmethod
    def _read_window_size(all_rows: list[dict[str, Any]]) -> tuple[float, float] | None:
        """Size (width, height) of the window of the session, where its mouse inputs were: logged ("window": "WxH"),
        or, in older sessions, the extent of the areas of interest of the tasks (each one is (x1, y1, x2, y2))."""
        width: float = 0
        height: float = 0
        for row in all_rows:
            if row["type"] == "window":
                try:
                    w, h = (float(v) for v in str(row["value"]).split("x"))
                    return w, h
                except ValueError:
                    continue
            if row["type"] == "aoi":
                try:
                    x1, y1, x2, y2 = ast.literal_eval(row["value"])
                except (ValueError, SyntaxError, TypeError):
                    continue
                width, height = max(width, x1, x2), max(height, y1, y2)
        return (width, height) if width > 0 and height > 0 else None

    def _read_page_events(self, all_rows: list[dict[str, Any]]) -> None:
        """Browser sessions: the browser and its system, the periods when the page was hidden (the scenario is
        paused), and the pauses of the page (freeze, e.g. garbage collection), in replay time (seconds).

        hidden_periods: (hidden, visible, resumed): the page was hidden from `hidden` to `visible`, and the
        scenario resumed at `resumed` (after the pause dialog). freezes: (start, duration in seconds)."""
        hidden_since: float | None = None
        for row in all_rows:
            kind: str = row["type"]
            if kind in ("browser", "os"):
                self.environment[kind] = row["value"]
            elif kind == "freeze":
                duration: float = float(row["value"]) / 1000  # Logged when the page runs again
                self.freezes.append((max(row["normalized_logtime"] - duration, 0), duration))
            elif kind == "visibility" and row["value"] == "hidden" and hidden_since is None:
                hidden_since = row["normalized_logtime"]
            elif kind == "visibility" and row["value"] == "visible" and hidden_since is not None:
                self.hidden_periods.append(self._hidden_period(hidden_since, row["normalized_logtime"]))
                hidden_since = None
        if hidden_since is not None:  # Still hidden at the end of the session
            self.hidden_periods.append(self._hidden_period(hidden_since, self.session_duration))

    def _hidden_period(self, hidden: float, visible: float) -> tuple[float, float, float]:
        # The scenario time is frozen from when the page is hidden until the pause dialog is closed
        resumed: float = visible
        for lt_start, lt_end, _frozen_st in self.blocking_segments:
            if lt_start - 0.5 <= hidden <= lt_end:
                resumed = max(resumed, lt_end)
        return hidden, visible, resumed

    def is_in_blocking_segment(self, replay_time: float) -> bool:
        """Check if replay_time falls inside a blocking segment."""
        for lt_start, lt_end, _frozen_st in self.blocking_segments:
            if lt_start <= replay_time <= lt_end:
                return True
        return False

    def session_event_to_str(self, event_row: dict[str, Any]) -> str:
        time_sec: int = int(float(event_row["scenario_time"]))
        plugin: str = event_row["module"]
        if event_row["address"] == "self":
            command: str = event_row["value"]
        else:
            command = ";".join([event_row["address"], event_row["value"]])

        event: Event = Event(self.line_n, time_sec, plugin, command)
        self.line_n += 1
        return event.get_line_str()
