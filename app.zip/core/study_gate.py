# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): lets a tutorial step end as soon as the participant succeeds (plugins/gate.py).

"""Shared state between the communications plugin, the gate plugin and the scheduler.

comm_hits: number of correct communications responses (HIT) by the participant so far.
skip_to: scenario time (s) the scheduler jumps to at its next update (the events in between are executed at once).
"""

from __future__ import annotations

comm_hits: int = 0
skip_to: float | None = None
