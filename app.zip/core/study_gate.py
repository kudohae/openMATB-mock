# Copyright 2023-2026, by Julien Cegarra & Benoît Valéry. All rights reserved.
# Institut National Universitaire Champollion (Albi, France).
# License : CeCILL, version 2.1 (see the LICENSE file)
#
# Korean adaptation (2026): lets a tutorial step end as soon as the participant succeeds (plugins/gate.py).

"""Shared state between the communications plugin, the gate plugin and the scheduler.

comm_hits: number of correct communications responses (HIT) by the participant so far.
skip_to: scenario time (s) the scheduler jumps to at its next update (the events in between are executed at once).
time_factor: speed of the scenario time (10 with ?fast=1 in the web page address, to check the study end quickly).
pointer_paused(): the mouse pointer lock was lost while the tracking task needs it (web/mouse_tracking.js): the
scheduler pauses the tasks, as with a dialog, until the pointer is locked again.
"""

from __future__ import annotations

import os
import sys
from typing import Any

comm_hits: int = 0
skip_to: float | None = None
time_factor: float = float(os.environ.get("OPENMATB_TIME_FACTOR", "1"))

_mouse_tracking: Any = None


def pointer_paused() -> bool:
    global _mouse_tracking
    if sys.platform != "emscripten":
        return False
    if _mouse_tracking is None:
        import js  # type: ignore[import-not-found]

        _mouse_tracking = getattr(js.window, "MouseTracking", None)
        if _mouse_tracking is None:
            return False
    return bool(_mouse_tracking.isSuspended())
